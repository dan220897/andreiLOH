create policy "matches_insert_own" on matches for insert
with check (auth.uid() = user_a_id or auth.uid() = user_b_id);
