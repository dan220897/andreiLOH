-- Adds the messages table to the supabase_realtime publication so that
-- postgres_changes subscriptions (see app/chat/[id].tsx) actually fire on INSERT.
--
-- NOTE: this environment has no Supabase CLI / service-role access to apply
-- migrations directly. Apply this manually via the Supabase SQL editor, or
-- run `supabase db push` from a machine with the CLI configured.

alter publication supabase_realtime add table messages;
