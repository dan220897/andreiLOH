-- =========================================================
-- Dating app schema
-- =========================================================

create extension if not exists pgcrypto;
create extension if not exists postgis;

-- ---------- ENUMS ----------
create type gender_type as enum ('male', 'female', 'other');
create type verification_status_type as enum ('none', 'pending', 'verified', 'rejected');
create type swipe_action_type as enum ('like', 'dislike', 'superlike');
create type swipe_context_type as enum ('dating', 'business');
create type match_status_type as enum ('active', 'unmatched');
create type message_type as enum ('text', 'photo', 'date_proposal', 'date_confirmation', 'question_36', 'tonight_status');
create type date_proposal_status_type as enum ('pending', 'accepted', 'declined');
create type date_status_type as enum ('confirmed', 'completed_both_confirmed', 'completed_disputed', 'no_show', 'cancelled');
create type subscription_tier_type as enum ('week', 'month', 'half_year', 'year');
create type subscription_status_type as enum ('active', 'expired', 'cancelled');
create type report_status_type as enum ('open', 'reviewed', 'dismissed');

-- ---------- PROFILES ----------
create table profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null,
  birth_date date not null,
  gender gender_type not null,
  orientation text[] not null default '{}',
  height_cm smallint not null check (height_cm between 100 and 250),
  bio text,
  city text,
  location geography(point, 4326),
  is_business boolean not null default false,
  verification_status verification_status_type not null default 'none',
  verification_selfie_url text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index profiles_location_idx on profiles using gist (location);

create table photos (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references profiles(id) on delete cascade,
  url text not null,
  position smallint not null default 0,
  is_main boolean not null default false,
  created_at timestamptz not null default now()
);
create index photos_profile_idx on photos(profile_id);

create table appearance_tags (
  id uuid primary key default gen_random_uuid(),
  category text not null, -- hair_color, body_type, etc.
  name text not null,
  unique (category, name)
);

create table photo_tags (
  photo_id uuid not null references photos(id) on delete cascade,
  tag_id uuid not null references appearance_tags(id) on delete cascade,
  primary key (photo_id, tag_id)
);

-- ---------- PREFERENCES ----------
create table preferences (
  profile_id uuid primary key references profiles(id) on delete cascade,
  min_age smallint not null default 18,
  max_age smallint not null default 99,
  max_distance_km smallint not null default 50,
  interested_in_gender gender_type[] not null default '{}'
);

create table preference_tag_filters ( -- paid feature
  profile_id uuid not null references profiles(id) on delete cascade,
  tag_id uuid not null references appearance_tags(id) on delete cascade,
  primary key (profile_id, tag_id)
);

create table preference_params ( -- paid feature (height filter etc.)
  profile_id uuid primary key references profiles(id) on delete cascade,
  height_min smallint,
  height_max smallint
);

-- ---------- BUSINESS VERTICAL ----------
create table business_profiles (
  profile_id uuid primary key references profiles(id) on delete cascade,
  company_name text not null,
  inn text not null,
  verification_status verification_status_type not null default 'pending',
  verified_at timestamptz
);

-- ---------- MATCHING ----------
create table swipes (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid not null references profiles(id) on delete cascade,
  target_id uuid not null references profiles(id) on delete cascade,
  action swipe_action_type not null,
  context swipe_context_type not null default 'dating',
  created_at timestamptz not null default now(),
  unique (actor_id, target_id, context)
);
create index swipes_target_idx on swipes(target_id, context);
create index swipes_actor_idx on swipes(actor_id, context);

create table profile_impressions ( -- powers "seen, no reaction" status
  viewer_id uuid not null references profiles(id) on delete cascade,
  viewed_id uuid not null references profiles(id) on delete cascade,
  shown_at timestamptz not null default now(),
  primary key (viewer_id, viewed_id)
);

create table matches (
  id uuid primary key default gen_random_uuid(),
  user_a_id uuid not null references profiles(id) on delete cascade,
  user_b_id uuid not null references profiles(id) on delete cascade,
  context swipe_context_type not null default 'dating',
  status match_status_type not null default 'active',
  matched_at timestamptz not null default now(),
  unique (user_a_id, user_b_id, context)
);
create index matches_user_a_idx on matches(user_a_id);
create index matches_user_b_idx on matches(user_b_id);

-- ---------- CHAT ----------
create table messages (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references matches(id) on delete cascade,
  sender_id uuid not null references profiles(id) on delete cascade,
  type message_type not null default 'text',
  content text,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now(),
  read_at timestamptz
);
create index messages_match_idx on messages(match_id, created_at);

-- ---------- DATES / PLANNER ----------
create table places_catalog (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text,
  city text,
  address text,
  location geography(point, 4326)
);

create table date_proposals (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references matches(id) on delete cascade,
  proposed_by uuid not null references profiles(id) on delete cascade,
  proposed_date date not null,
  proposed_time time not null,
  place_id uuid references places_catalog(id),
  status date_proposal_status_type not null default 'pending',
  created_at timestamptz not null default now()
);

create table dates (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references matches(id) on delete cascade,
  date_proposal_id uuid references date_proposals(id),
  scheduled_at timestamptz not null,
  status date_status_type not null default 'confirmed',
  user_a_confirmed_met boolean,
  user_b_confirmed_met boolean,
  reminder_sent_at timestamptz,
  created_at timestamptz not null default now()
);

create table date_notes (
  id uuid primary key default gen_random_uuid(),
  date_id uuid not null references dates(id) on delete cascade,
  profile_id uuid not null references profiles(id) on delete cascade,
  note_text text not null,
  created_at timestamptz not null default now()
);

-- ---------- TONIGHT ----------
create table tonight_statuses (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references profiles(id) on delete cascade,
  text text not null,
  expires_at timestamptz not null default (now() + interval '24 hours'),
  created_at timestamptz not null default now()
);
create index tonight_statuses_profile_idx on tonight_statuses(profile_id, expires_at);

create table tonight_free_toggle (
  profile_id uuid primary key references profiles(id) on delete cascade,
  is_free_tonight boolean not null default false,
  city text,
  activated_at timestamptz,
  auto_reset_at timestamptz
);

-- ---------- DAILY MEETCUTE ----------
create table daily_meetcute (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references profiles(id) on delete cascade,
  candidate_id uuid not null references profiles(id) on delete cascade,
  explanation_text text not null,
  shown_date date not null default current_date,
  created_at timestamptz not null default now(),
  unique (profile_id, shown_date)
);

-- ---------- 36 QUESTIONS GAME ----------
create table question_36_game (
  id uuid primary key default gen_random_uuid(),
  match_id uuid not null references matches(id) on delete cascade,
  question_index smallint not null,
  answer_a text,
  answer_b text,
  both_revealed boolean not null default false,
  created_at timestamptz not null default now(),
  unique (match_id, question_index)
);

-- ---------- SUBSCRIPTIONS ----------
create table subscriptions (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references profiles(id) on delete cascade,
  tier subscription_tier_type not null,
  started_at timestamptz not null default now(),
  expires_at timestamptz not null,
  status subscription_status_type not null default 'active',
  payment_provider_ref text
);
create index subscriptions_profile_idx on subscriptions(profile_id, status);

-- ---------- SAFETY ----------
create table reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references profiles(id) on delete cascade,
  reported_id uuid not null references profiles(id) on delete cascade,
  reason text not null,
  status report_status_type not null default 'open',
  created_at timestamptz not null default now()
);

create table blocks (
  blocker_id uuid not null references profiles(id) on delete cascade,
  blocked_id uuid not null references profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (blocker_id, blocked_id)
);

-- ---------- NOTIFICATIONS ----------
create table notifications (
  id uuid primary key default gen_random_uuid(),
  profile_id uuid not null references profiles(id) on delete cascade,
  type text not null,
  payload jsonb not null default '{}',
  read_at timestamptz,
  created_at timestamptz not null default now()
);
create index notifications_profile_idx on notifications(profile_id, read_at);

-- =========================================================
-- ROW LEVEL SECURITY
-- =========================================================
alter table profiles enable row level security;
alter table photos enable row level security;
alter table photo_tags enable row level security;
alter table preferences enable row level security;
alter table preference_tag_filters enable row level security;
alter table preference_params enable row level security;
alter table business_profiles enable row level security;
alter table swipes enable row level security;
alter table profile_impressions enable row level security;
alter table matches enable row level security;
alter table messages enable row level security;
alter table date_proposals enable row level security;
alter table dates enable row level security;
alter table date_notes enable row level security;
alter table tonight_statuses enable row level security;
alter table tonight_free_toggle enable row level security;
alter table daily_meetcute enable row level security;
alter table question_36_game enable row level security;
alter table subscriptions enable row level security;
alter table reports enable row level security;
alter table blocks enable row level security;
alter table notifications enable row level security;

-- profiles: discovery requires reading other profiles; writes restricted to owner
create policy "profiles_select_all" on profiles for select using (true);
create policy "profiles_insert_own" on profiles for insert with check (auth.uid() = id);
create policy "profiles_update_own" on profiles for update using (auth.uid() = id);

create policy "photos_select_all" on photos for select using (true);
create policy "photos_write_own" on photos for all using (auth.uid() = profile_id) with check (auth.uid() = profile_id);

create policy "photo_tags_select_all" on photo_tags for select using (true);
create policy "photo_tags_write_own" on photo_tags for all
  using (exists (select 1 from photos where photos.id = photo_tags.photo_id and photos.profile_id = auth.uid()))
  with check (exists (select 1 from photos where photos.id = photo_tags.photo_id and photos.profile_id = auth.uid()));

create policy "preferences_own" on preferences for all using (auth.uid() = profile_id) with check (auth.uid() = profile_id);
create policy "preference_tag_filters_own" on preference_tag_filters for all using (auth.uid() = profile_id) with check (auth.uid() = profile_id);
create policy "preference_params_own" on preference_params for all using (auth.uid() = profile_id) with check (auth.uid() = profile_id);

create policy "business_profiles_select_all" on business_profiles for select using (true);
create policy "business_profiles_write_own" on business_profiles for all using (auth.uid() = profile_id) with check (auth.uid() = profile_id);

create policy "swipes_select_own" on swipes for select using (auth.uid() = actor_id or auth.uid() = target_id);
create policy "swipes_insert_own" on swipes for insert with check (auth.uid() = actor_id);

create policy "profile_impressions_select_own" on profile_impressions for select using (auth.uid() = viewer_id);
create policy "profile_impressions_insert_own" on profile_impressions for insert with check (auth.uid() = viewer_id);

create policy "matches_select_own" on matches for select using (auth.uid() = user_a_id or auth.uid() = user_b_id);
create policy "matches_update_own" on matches for update using (auth.uid() = user_a_id or auth.uid() = user_b_id);

create policy "messages_select_in_match" on messages for select using (
  exists (select 1 from matches m where m.id = messages.match_id and (m.user_a_id = auth.uid() or m.user_b_id = auth.uid()))
);
create policy "messages_insert_in_match" on messages for insert with check (
  auth.uid() = sender_id and
  exists (select 1 from matches m where m.id = messages.match_id and (m.user_a_id = auth.uid() or m.user_b_id = auth.uid()))
);

create policy "date_proposals_in_match" on date_proposals for all using (
  exists (select 1 from matches m where m.id = date_proposals.match_id and (m.user_a_id = auth.uid() or m.user_b_id = auth.uid()))
) with check (
  exists (select 1 from matches m where m.id = date_proposals.match_id and (m.user_a_id = auth.uid() or m.user_b_id = auth.uid()))
);

create policy "dates_in_match" on dates for all using (
  exists (select 1 from matches m where m.id = dates.match_id and (m.user_a_id = auth.uid() or m.user_b_id = auth.uid()))
) with check (
  exists (select 1 from matches m where m.id = dates.match_id and (m.user_a_id = auth.uid() or m.user_b_id = auth.uid()))
);

create policy "date_notes_own" on date_notes for all using (auth.uid() = profile_id) with check (auth.uid() = profile_id);

create policy "tonight_statuses_select_all" on tonight_statuses for select using (true);
create policy "tonight_statuses_write_own" on tonight_statuses for all using (auth.uid() = profile_id) with check (auth.uid() = profile_id);

create policy "tonight_free_toggle_select_all" on tonight_free_toggle for select using (true);
create policy "tonight_free_toggle_write_own" on tonight_free_toggle for all using (auth.uid() = profile_id) with check (auth.uid() = profile_id);

create policy "daily_meetcute_own" on daily_meetcute for select using (auth.uid() = profile_id);

create policy "question_36_in_match" on question_36_game for all using (
  exists (select 1 from matches m where m.id = question_36_game.match_id and (m.user_a_id = auth.uid() or m.user_b_id = auth.uid()))
) with check (
  exists (select 1 from matches m where m.id = question_36_game.match_id and (m.user_a_id = auth.uid() or m.user_b_id = auth.uid()))
);

create policy "subscriptions_own" on subscriptions for select using (auth.uid() = profile_id);

create policy "reports_insert_own" on reports for insert with check (auth.uid() = reporter_id);
create policy "reports_select_own" on reports for select using (auth.uid() = reporter_id);

create policy "blocks_own" on blocks for all using (auth.uid() = blocker_id) with check (auth.uid() = blocker_id);

create policy "notifications_own" on notifications for select using (auth.uid() = profile_id);
create policy "notifications_update_own" on notifications for update using (auth.uid() = profile_id);
