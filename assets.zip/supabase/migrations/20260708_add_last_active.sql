alter table profiles add column if not exists last_active_at timestamptz not null default now();
