-- Surfaces the fields the profile detail sheet needs but nearby_candidates() didn't
-- return yet: last_active_at (for an online/last-seen indicator) and the viewed
-- profile's business info (company + position) for the business-networking context.
create or replace function nearby_candidates(p_context swipe_context_type, p_is_business boolean)
returns table (
  id uuid,
  display_name text,
  birth_date date,
  bio text,
  height_cm smallint,
  city text,
  profession text,
  interests text[],
  verification_status verification_status_type,
  is_premium boolean,
  distance_km double precision,
  last_active_at timestamptz,
  company_name text,
  business_position text,
  photos jsonb
)
language sql stable security definer set search_path = public
as $$
  select
    p.id,
    p.display_name,
    p.birth_date,
    p.bio,
    p.height_cm,
    p.city,
    p.profession,
    p.interests,
    p.verification_status,
    exists(
      select 1 from subscriptions s
      where s.profile_id = p.id and s.status = 'active' and s.expires_at > now()
    ) as is_premium,
    case when me.location is not null and p.location is not null
      then ST_Distance(me.location, p.location) / 1000.0
      else null end as distance_km,
    p.last_active_at,
    bp.company_name,
    bp.position as business_position,
    coalesce(
      (select jsonb_agg(
         jsonb_build_object('url', ph.url, 'is_main', ph.is_main, 'position', ph.position)
         order by ph.is_main desc, ph.position asc, ph.created_at asc
       )
       from photos ph where ph.profile_id = p.id),
      '[]'::jsonb
    ) as photos
  from profiles p
  left join business_profiles bp on bp.profile_id = p.id
  cross join (select location from profiles where id = auth.uid()) me
  where p.id != auth.uid()
    and p.is_business = p_is_business
    and p.id not in (
      select target_id from swipes where actor_id = auth.uid() and context = p_context
    )
  order by
    (case when p.boost_until is not null and p.boost_until > now() then 0 else 1 end),
    distance_km asc nulls last;
$$;

grant execute on function nearby_candidates(swipe_context_type, boolean) to authenticated;
