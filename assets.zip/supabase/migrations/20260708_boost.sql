alter table profiles add column if not exists boost_until timestamptz;

create or replace function nearby_candidates(p_context swipe_context_type, p_is_business boolean)
returns table (
  id uuid,
  display_name text,
  birth_date date,
  bio text,
  height_cm smallint,
  city text,
  distance_km double precision,
  photos jsonb
)
language sql stable
as $$
  select
    p.id,
    p.display_name,
    p.birth_date,
    p.bio,
    p.height_cm,
    p.city,
    case when me.location is not null and p.location is not null
      then ST_Distance(me.location, p.location) / 1000.0
      else null end as distance_km,
    coalesce(
      (select jsonb_agg(jsonb_build_object('url', ph.url, 'is_main', ph.is_main, 'position', ph.position))
       from photos ph where ph.profile_id = p.id),
      '[]'::jsonb
    ) as photos
  from profiles p
  cross join (select location from profiles where id = auth.uid()) me
  where p.id != auth.uid()
    and p.is_business = p_is_business
    and p.id not in (
      select target_id from swipes where actor_id = auth.uid() and context = p_context
    )
  order by
    (case when p.boost_until is not null and p.boost_until > now() then 0 else 1 end),
    distance_km asc nulls last;
$$;

grant execute on function nearby_candidates(swipe_context_type, boolean) to authenticated;
