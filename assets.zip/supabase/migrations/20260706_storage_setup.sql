insert into storage.buckets (id, name, public)
values ('photos', 'photos', true)
on conflict (id) do nothing;

create policy "photos_bucket_public_read"
on storage.objects for select
using (bucket_id = 'photos');

create policy "photos_bucket_insert_own"
on storage.objects for insert
with check (bucket_id = 'photos' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "photos_bucket_delete_own"
on storage.objects for delete
using (bucket_id = 'photos' and (storage.foldername(name))[1] = auth.uid()::text);
