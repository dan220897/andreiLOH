alter table business_profiles add column if not exists position text;
