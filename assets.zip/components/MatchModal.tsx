import { MaterialIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { Image, Modal, Pressable, StyleSheet, Text, View } from 'react-native';

const CARD_BASE = '#170B33';
const ACCENT = '#8B5CF6';
const BORDER = 'rgba(255,255,255,0.14)';

export default function MatchModal({
  visible,
  myPhotoUrl,
  otherPhotoUrl,
  otherName,
  matchId,
  onClose,
}: {
  visible: boolean;
  myPhotoUrl: string | null;
  otherPhotoUrl: string | null;
  otherName: string;
  matchId: string | null;
  onClose: () => void;
}) {
  const router = useRouter();

  return (
    <Modal visible={visible} animationType="fade" transparent onRequestClose={onClose}>
      <View style={styles.backdrop}>
        <LinearGradient
          colors={['#1A0F38', '#2A1650', '#4C2A8C', '#170B33']}
          locations={[0, 0.35, 0.68, 1]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.card}
        >
          <View style={styles.avatarsRow}>
            <View style={[styles.avatarWrap, styles.avatarLeft]}>
              {myPhotoUrl ? (
                <Image source={{ uri: myPhotoUrl }} style={styles.avatar} />
              ) : (
                <View style={[styles.avatar, styles.avatarPlaceholder]} />
              )}
            </View>
            <View style={[styles.avatarWrap, styles.avatarRight]}>
              {otherPhotoUrl ? (
                <Image source={{ uri: otherPhotoUrl }} style={styles.avatar} />
              ) : (
                <View style={[styles.avatar, styles.avatarPlaceholder]} />
              )}
            </View>
            <View style={styles.heartBadge}>
              <MaterialIcons name="favorite" size={20} color="#fff" />
            </View>
          </View>

          <Text style={styles.title}>Это мэтч!</Text>
          <Text style={styles.subtitle}>
            Вы и <Text style={styles.subtitleName}>{otherName}</Text> понравились друг другу
          </Text>

          <Pressable
            style={styles.primaryButtonWrap}
            onPress={() => {
              onClose();
              if (matchId) router.push({ pathname: '/chat/[id]', params: { id: matchId } });
            }}
          >
            <LinearGradient
              colors={['#A78BFA', '#8B5CF6']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
              style={styles.primaryButton}
            >
              <Text style={styles.primaryButtonText}>Написать сообщение</Text>
            </LinearGradient>
          </Pressable>

          <Pressable style={styles.secondaryButton} onPress={onClose}>
            <Text style={styles.secondaryButtonText}>Продолжить свайпать</Text>
          </Pressable>
        </LinearGradient>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    backgroundColor: 'rgba(0,0,0,0.75)',
  },
  card: {
    width: '100%',
    maxWidth: 400,
    borderRadius: 32,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    alignItems: 'center',
    padding: 32,
    shadowColor: ACCENT,
    shadowOpacity: 0.5,
    shadowRadius: 30,
    shadowOffset: { width: 0, height: 10 },
    elevation: 16,
  },
  avatarsRow: {
    width: 190,
    height: 158,
    marginBottom: 28,
  },
  avatarWrap: {
    position: 'absolute',
    width: 128,
    height: 128,
    borderRadius: 64,
    borderWidth: 4,
    borderColor: CARD_BASE,
    overflow: 'hidden',
  },
  avatarLeft: { left: 0, top: 0 },
  avatarRight: { right: 0, top: 28 },
  avatar: { width: '100%', height: '100%' },
  avatarPlaceholder: { backgroundColor: 'rgba(255,255,255,0.08)' },
  heartBadge: {
    position: 'absolute',
    left: '50%',
    top: 57,
    marginLeft: -22,
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: ACCENT,
    borderWidth: 3,
    borderColor: CARD_BASE,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: ACCENT,
    shadowOpacity: 0.7,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 0 },
    elevation: 8,
  },
  title: { fontSize: 28, fontWeight: '900', color: '#fff', textAlign: 'center' },
  subtitle: {
    fontSize: 15,
    color: '#c9c9ce',
    textAlign: 'center',
    marginTop: 10,
    marginBottom: 32,
  },
  subtitleName: { color: '#fff', fontWeight: '700' },
  primaryButtonWrap: { width: '100%', borderRadius: 28, overflow: 'hidden' },
  primaryButton: { paddingVertical: 16, alignItems: 'center' },
  primaryButtonText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  secondaryButton: {
    width: '100%',
    borderWidth: 1,
    borderColor: BORDER,
    borderRadius: 28,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 12,
  },
  secondaryButtonText: { color: '#c9c9ce', fontSize: 16, fontWeight: '600' },
});
