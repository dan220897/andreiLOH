import { FontAwesome5, MaterialIcons } from '@expo/vector-icons';
import { View } from 'react-native';

export default function VerifiedBadge({ size = 18 }: { size?: number }) {
  return (
    <View style={{ width: size, height: size }}>
      <MaterialIcons
        name="verified"
        size={size}
        color="#8B5CF6"
        style={{ position: 'absolute', top: 0, left: 0 }}
      />
      <FontAwesome5
        name="check"
        size={size * 0.42}
        color="#fff"
        solid
        style={{
          position: 'absolute',
          top: size * 0.29,
          left: size * 0.29,
        }}
      />
    </View>
  );
}
