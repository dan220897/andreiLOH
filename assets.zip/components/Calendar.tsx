import { useState } from 'react';
import { FlatList, Modal, Pressable, StyleSheet, Text, View } from 'react-native';
import { BlurView } from 'expo-blur';

const MONTH_NAMES = [
  'Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь',
  'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь',
];

const WEEKDAY_LABELS = ['ПН', 'ВТ', 'СР', 'ЧТ', 'ПТ', 'СБ', 'ВС'];

const BORDER = 'rgba(255,255,255,0.14)';

function daysInMonth(year: number, month: number) {
  return new Date(year, month + 1, 0).getDate();
}

function mondayFirstWeekday(year: number, month: number) {
  return (new Date(year, month, 1).getDay() + 6) % 7;
}

function sameDay(a: Date, b: Date) {
  return (
    a.getFullYear() === b.getFullYear() &&
    a.getMonth() === b.getMonth() &&
    a.getDate() === b.getDate()
  );
}

export default function Calendar({
  value,
  onChange,
  maximumDate,
  minimumDate,
}: {
  value: Date;
  onChange: (date: Date) => void;
  maximumDate?: Date;
  minimumDate?: Date;
}) {
  const [viewYear, setViewYear] = useState(value.getFullYear());
  const [viewMonth, setViewMonth] = useState(value.getMonth());
  const [yearPickerOpen, setYearPickerOpen] = useState(false);

  const maxYear = maximumDate?.getFullYear() ?? new Date().getFullYear();
  const minYear = minimumDate?.getFullYear() ?? 1930;
  const years = Array.from({ length: maxYear - minYear + 1 }, (_, i) => maxYear - i);

  const changeMonth = (delta: number) => {
    let m = viewMonth + delta;
    let y = viewYear;
    if (m < 0) {
      m = 11;
      y -= 1;
    } else if (m > 11) {
      m = 0;
      y += 1;
    }
    if (y < minYear || y > maxYear) return;
    setViewMonth(m);
    setViewYear(y);
  };

  const totalDays = daysInMonth(viewYear, viewMonth);
  const leadingBlanks = mondayFirstWeekday(viewYear, viewMonth);
  const cells: (number | null)[] = [
    ...Array(leadingBlanks).fill(null),
    ...Array.from({ length: totalDays }, (_, i) => i + 1),
  ];

  const isDisabled = (day: number) => {
    const d = new Date(viewYear, viewMonth, day);
    if (maximumDate && d > maximumDate) return true;
    if (minimumDate && d < minimumDate) return true;
    return false;
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Pressable style={styles.navButton} onPress={() => changeMonth(-1)}>
          <Text style={styles.navButtonText}>‹</Text>
        </Pressable>
        <Pressable onPress={() => setYearPickerOpen(true)}>
          <Text style={styles.headerLabel}>
            {MONTH_NAMES[viewMonth]} {viewYear}
          </Text>
        </Pressable>
        <Pressable style={styles.navButton} onPress={() => changeMonth(1)}>
          <Text style={styles.navButtonText}>›</Text>
        </Pressable>
      </View>

      <View style={styles.weekdayRow}>
        {WEEKDAY_LABELS.map((w) => (
          <Text key={w} style={styles.weekdayLabel}>
            {w}
          </Text>
        ))}
      </View>

      <View style={styles.grid}>
        {cells.map((day, index) => {
          if (day === null) return <View key={index} style={styles.cell} />;
          const disabled = isDisabled(day);
          const selected = sameDay(new Date(viewYear, viewMonth, day), value);
          return (
            <Pressable
              key={index}
              style={styles.cell}
              disabled={disabled}
              onPress={() => onChange(new Date(viewYear, viewMonth, day))}
            >
              <View style={[styles.dayCircle, selected && styles.dayCircleSelected]}>
                <Text
                  style={[
                    styles.dayText,
                    disabled && styles.dayTextDisabled,
                    selected && styles.dayTextSelected,
                  ]}
                >
                  {day}
                </Text>
              </View>
            </Pressable>
          );
        })}
      </View>

      <Modal
        visible={yearPickerOpen}
        animationType="fade"
        transparent
        onRequestClose={() => setYearPickerOpen(false)}
      >
        <BlurView intensity={60} tint="dark" style={styles.yearModalSheet}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Выберите год</Text>
            <Pressable style={styles.modalCloseButton} onPress={() => setYearPickerOpen(false)}>
              <Text style={styles.modalCloseButtonText}>✕</Text>
            </Pressable>
          </View>
          <FlatList
            data={years}
            keyExtractor={(y) => String(y)}
            showsVerticalScrollIndicator={false}
            renderItem={({ item }) => (
              <Pressable
                style={styles.yearRow}
                onPress={() => {
                  setViewYear(item);
                  setYearPickerOpen(false);
                }}
              >
                <Text style={[styles.yearRowText, item === viewYear && styles.yearRowTextActive]}>
                  {item}
                </Text>
              </Pressable>
            )}
          />
        </BlurView>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: 'rgba(255,255,255,0.07)',
    borderWidth: 1,
    borderColor: BORDER,
    borderRadius: 16,
    padding: 16,
  },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  navButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  navButtonText: { color: '#fff', fontSize: 18, fontWeight: '700' },
  headerLabel: { color: '#fff', fontSize: 16, fontWeight: '700' },
  weekdayRow: { flexDirection: 'row', marginTop: 14 },
  weekdayLabel: {
    flex: 1,
    textAlign: 'center',
    color: '#7a7a80',
    fontSize: 12,
    fontWeight: '600',
  },
  grid: { flexDirection: 'row', flexWrap: 'wrap', marginTop: 8 },
  cell: {
    width: `${100 / 7}%`,
    aspectRatio: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  dayCircle: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  dayCircleSelected: { backgroundColor: '#8B5CF6' },
  dayText: { color: '#fff', fontSize: 14 },
  dayTextDisabled: { color: '#4a4a4d' },
  dayTextSelected: { fontWeight: '700' },
  yearModalSheet: {
    flex: 1,
    height: '100%',
    backgroundColor: 'rgba(20,18,20,0.85)',
    paddingTop: 56,
    paddingHorizontal: 20,
    paddingBottom: 24,
  },
  modalHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginBottom: 16 },
  modalTitle: { color: '#fff', fontSize: 18, fontWeight: '700', textAlign: 'center' },
  modalCloseButton: {
    position: 'absolute',
    right: 0,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalCloseButtonText: { color: '#fff', fontSize: 14, fontWeight: '700' },
  yearRow: {
    paddingVertical: 14,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: BORDER,
    alignItems: 'center',
  },
  yearRowText: { color: '#c9c9ce', fontSize: 16 },
  yearRowTextActive: { color: '#8B5CF6', fontWeight: '700' },
});
