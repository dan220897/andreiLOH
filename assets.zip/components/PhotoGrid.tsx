import { MaterialIcons } from '@expo/vector-icons';
import { BlurView } from 'expo-blur';
import * as ImagePicker from 'expo-image-picker';
import { useRef, useState } from 'react';
import {
  ActivityIndicator,
  Image,
  LayoutChangeEvent,
  Modal,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Animated, {
  runOnJS,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
} from 'react-native-reanimated';
import { showAlert } from '../lib/alert';
import { verifyFacePresent } from '../lib/faceCheck';

export type GridPhoto = {
  key: string;
  uri: string;
  base64?: string;
  existingId?: string;
  verified?: boolean;
};

const SLOT_COUNT = 6;
const GAP = 8;
const BORDER = 'rgba(255,255,255,0.14)';
const ACCENT = '#8B5CF6';

type Rect = { x: number; y: number; width: number; height: number };

export default function PhotoGrid({
  photos,
  onChange,
}: {
  photos: (GridPhoto | null)[];
  onChange: (next: (GridPhoto | null)[]) => void;
}) {
  const [gridWidth, setGridWidth] = useState(0);
  const [pickerForIndex, setPickerForIndex] = useState<number | null>(null);
  const [verifyingIndex, setVerifyingIndex] = useState<number | null>(null);
  const [draggingIndex, setDraggingIndex] = useState<number | null>(null);
  const slotRects = useRef<Array<Rect | null>>(Array(SLOT_COUNT).fill(null));

  const onGridLayout = (e: LayoutChangeEvent) => {
    setGridWidth(e.nativeEvent.layout.width);
  };

  const bigSize = gridWidth > 0 ? Math.floor(((gridWidth - GAP) * 2) / 3) : 0;
  const smallSize = gridWidth > 0 ? Math.floor((bigSize - GAP) / 2) : 0;
  const bottomSize = gridWidth > 0 ? Math.floor((gridWidth - GAP * 2) / 3) : 0;

  const pickFor = async (index: number, source: 'camera' | 'library') => {
    setPickerForIndex(null);
    let result;
    if (source === 'camera') {
      const perm = await ImagePicker.requestCameraPermissionsAsync();
      if (!perm.granted) {
        showAlert('Нет доступа к камере', 'Разрешите доступ к камере в настройках');
        return;
      }
      result = await ImagePicker.launchCameraAsync({ quality: 0.7, base64: true });
    } else {
      result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'],
        quality: 0.7,
        base64: true,
      });
    }
    if (result.canceled || !result.assets[0]) return;
    const asset = result.assets[0];
    const base64 = asset.base64 ?? '';

    const isDuplicate = photos.some(
      (p, i) => i !== index && p?.base64 && p.base64 === base64
    );
    if (isDuplicate) {
      showAlert('Это фото уже добавлено', 'Выберите другое фото для этого места');
      return;
    }

    const next = [...photos];
    next[index] = {
      key: `${Date.now()}-${index}`,
      uri: asset.uri,
      base64,
      verified: false,
    };
    onChange(next);

    setVerifyingIndex(index);
    const ok = await verifyFacePresent(base64);
    setVerifyingIndex(null);
    if (!ok) {
      showAlert('Не удалось распознать человека', 'Выберите фото, на котором чётко видно лицо');
      const reverted = [...next];
      reverted[index] = null;
      onChange(reverted);
      return;
    }
    const verifiedNext = [...next];
    verifiedNext[index] = { ...(verifiedNext[index] as GridPhoto), verified: true };
    onChange(verifiedNext);
  };

  const removeAt = (index: number) => {
    const next = [...photos];
    next[index] = null;
    onChange(next);
  };

  const swap = (a: number, b: number) => {
    if (a === b) return;
    const next = [...photos];
    [next[a], next[b]] = [next[b], next[a]];
    onChange(next);
  };

  const handleDrop = (fromIndex: number, absX: number, absY: number) => {
    let targetIndex: number | null = null;
    for (let i = 0; i < SLOT_COUNT; i++) {
      const rect = slotRects.current[i];
      if (!rect) continue;
      if (absX >= rect.x && absX <= rect.x + rect.width && absY >= rect.y && absY <= rect.y + rect.height) {
        targetIndex = i;
        break;
      }
    }
    if (targetIndex !== null) swap(fromIndex, targetIndex);
    setDraggingIndex(null);
  };

  return (
    <View onLayout={onGridLayout}>
      {gridWidth > 0 && (
        <>
          <View style={styles.row}>
            <Slot
              index={0}
              size={bigSize}
              photo={photos[0]}
              verifying={verifyingIndex === 0}
              dragging={draggingIndex === 0}
              onOpenPicker={() => setPickerForIndex(0)}
              onRemove={() => removeAt(0)}
              onLayoutRect={(rect) => (slotRects.current[0] = rect)}
              onDragStart={() => setDraggingIndex(0)}
              onDrop={(x, y) => handleDrop(0, x, y)}
            />
            <View style={{ gap: GAP }}>
              <Slot
                index={1}
                size={smallSize}
                photo={photos[1]}
                verifying={verifyingIndex === 1}
                dragging={draggingIndex === 1}
                onOpenPicker={() => setPickerForIndex(1)}
                onRemove={() => removeAt(1)}
                onLayoutRect={(rect) => (slotRects.current[1] = rect)}
                onDragStart={() => setDraggingIndex(1)}
                onDrop={(x, y) => handleDrop(1, x, y)}
              />
              <Slot
                index={2}
                size={smallSize}
                photo={photos[2]}
                verifying={verifyingIndex === 2}
                dragging={draggingIndex === 2}
                onOpenPicker={() => setPickerForIndex(2)}
                onRemove={() => removeAt(2)}
                onLayoutRect={(rect) => (slotRects.current[2] = rect)}
                onDragStart={() => setDraggingIndex(2)}
                onDrop={(x, y) => handleDrop(2, x, y)}
              />
            </View>
          </View>
          <View style={[styles.row, { marginTop: GAP }]}>
            {[3, 4, 5].map((index) => (
              <Slot
                key={index}
                index={index}
                size={bottomSize}
                photo={photos[index]}
                verifying={verifyingIndex === index}
                dragging={draggingIndex === index}
                onOpenPicker={() => setPickerForIndex(index)}
                onRemove={() => removeAt(index)}
                onLayoutRect={(rect) => (slotRects.current[index] = rect)}
                onDragStart={() => setDraggingIndex(index)}
                onDrop={(x, y) => handleDrop(index, x, y)}
              />
            ))}
          </View>
        </>
      )}

      <Modal
        visible={pickerForIndex !== null}
        animationType="fade"
        transparent
        onRequestClose={() => setPickerForIndex(null)}
      >
        <Pressable style={styles.sheetBackdrop} onPress={() => setPickerForIndex(null)}>
          <BlurView intensity={30} tint="dark" style={StyleSheet.absoluteFillObject} />
        </Pressable>
        <View style={styles.sheetContainer}>
          <BlurView intensity={60} tint="dark" style={styles.sheet}>
            <Pressable
              style={styles.sheetRow}
              onPress={() => pickerForIndex !== null && pickFor(pickerForIndex, 'camera')}
            >
              <MaterialIcons name="photo-camera" size={18} color="#fff" />
              <Text style={styles.sheetRowText}>Камера</Text>
            </Pressable>
            <View style={styles.sheetDivider} />
            <Pressable
              style={styles.sheetRow}
              onPress={() => pickerForIndex !== null && pickFor(pickerForIndex, 'library')}
            >
              <MaterialIcons name="photo-library" size={18} color="#fff" />
              <Text style={styles.sheetRowText}>Галерея</Text>
            </Pressable>
          </BlurView>
          <Pressable style={styles.sheetCancel} onPress={() => setPickerForIndex(null)}>
            <Text style={styles.sheetCancelText}>Отмена</Text>
          </Pressable>
        </View>
      </Modal>
    </View>
  );
}

function Slot({
  index,
  size,
  photo,
  verifying,
  dragging,
  onOpenPicker,
  onRemove,
  onLayoutRect,
  onDragStart,
  onDrop,
}: {
  index: number;
  size: number;
  photo: GridPhoto | null;
  verifying: boolean;
  dragging: boolean;
  onOpenPicker: () => void;
  onRemove: () => void;
  onLayoutRect: (rect: Rect) => void;
  onDragStart: () => void;
  onDrop: (absX: number, absY: number) => void;
}) {
  const viewRef = useRef<View>(null);
  const translateX = useSharedValue(0);
  const translateY = useSharedValue(0);

  const measureRect = () => {
    viewRef.current?.measure((_x, _y, width, height, pageX, pageY) => {
      onLayoutRect({ x: pageX, y: pageY, width, height });
    });
  };

  const panGesture = Gesture.Pan()
    .activateAfterLongPress(320)
    .enabled(!!photo)
    .onStart(() => {
      runOnJS(onDragStart)();
    })
    .onUpdate((e) => {
      translateX.value = e.translationX;
      translateY.value = e.translationY;
    })
    .onEnd((e) => {
      const dropX = e.absoluteX;
      const dropY = e.absoluteY;
      translateX.value = withSpring(0);
      translateY.value = withSpring(0);
      runOnJS(onDrop)(dropX, dropY);
    });

  const tapGesture = Gesture.Tap()
    .maxDistance(8)
    .onEnd((_e, success) => {
      if (success) runOnJS(onOpenPicker)();
    });

  const gesture = Gesture.Race(panGesture, tapGesture);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [
      { translateX: translateX.value },
      { translateY: translateY.value },
      { scale: dragging ? 1.06 : 1 },
    ],
    zIndex: dragging ? 10 : 0,
    shadowOpacity: dragging ? 0.4 : 0,
  }));

  return (
    <View
      ref={viewRef}
      onLayout={measureRect}
      style={[styles.slot, { width: size, height: size }, !photo && styles.slotEmpty]}
    >
      <GestureDetector gesture={gesture}>
        <Animated.View style={[StyleSheet.absoluteFillObject, styles.slotInner, animatedStyle]}>
          {photo ? (
            <>
              <Image source={{ uri: photo.uri }} style={styles.slotImage} />
              {verifying && (
                <View style={styles.verifyOverlay}>
                  <ActivityIndicator color="#fff" />
                </View>
              )}
            </>
          ) : (
            <MaterialIcons
              name={index === 0 ? 'add-a-photo' : 'add'}
              size={index === 0 ? 26 : 20}
              color={ACCENT}
            />
          )}
        </Animated.View>
      </GestureDetector>
      {photo && (
        <>
          <Pressable style={styles.removeButton} onPress={onRemove}>
            <MaterialIcons name="close" size={13} color="#fff" />
          </Pressable>
          {index === 0 && (
            <View style={styles.mainBadge} pointerEvents="none">
              <Text style={styles.mainBadgeText}>Главное</Text>
            </View>
          )}
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', gap: GAP },
  slot: {
    borderRadius: 16,
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: BORDER,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: ACCENT,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 0 },
    elevation: 4,
  },
  slotEmpty: {
    borderStyle: 'dashed',
    borderColor: 'rgba(139,92,246,0.4)',
  },
  slotInner: { alignItems: 'center', justifyContent: 'center' },
  slotImage: { width: '100%', height: '100%' },
  verifyOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.55)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  removeButton: {
    position: 'absolute',
    top: 4,
    right: 4,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: 'rgba(0,0,0,0.6)',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 2,
  },
  mainBadge: {
    position: 'absolute',
    left: 6,
    bottom: 6,
    backgroundColor: 'rgba(139,92,246,0.85)',
    borderRadius: 8,
    paddingHorizontal: 6,
    zIndex: 2,
    paddingVertical: 2,
  },
  mainBadgeText: { color: '#fff', fontSize: 9, fontWeight: '700' },

  sheetBackdrop: { ...StyleSheet.absoluteFillObject },
  sheetContainer: { position: 'absolute', left: 16, right: 16, bottom: 32, gap: 10 },
  sheet: { borderRadius: 20, overflow: 'hidden', borderWidth: 1, borderColor: BORDER },
  sheetRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 18,
  },
  sheetRowText: { color: '#fff', fontSize: 17, fontWeight: '500' },
  sheetDivider: { height: StyleSheet.hairlineWidth, backgroundColor: BORDER },
  sheetCancel: {
    backgroundColor: 'rgba(28,26,28,0.9)',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: BORDER,
    paddingVertical: 18,
    alignItems: 'center',
  },
  sheetCancelText: { color: '#fff', fontSize: 17, fontWeight: '700' },
});
