import { MaterialIcons } from '@expo/vector-icons';
import { BlurView } from 'expo-blur';
import { useState } from 'react';
import { Image, Platform, Pressable, StyleSheet, View, ViewStyle } from 'react-native';

type Photo = { url: string; is_main: boolean; position?: number };

export default function PhotoCarousel({
  photos,
  style,
}: {
  photos: Photo[];
  style?: ViewStyle;
}) {
  const ordered = [...photos].sort(
    (a, b) => (b.is_main ? 1 : 0) - (a.is_main ? 1 : 0) || (a.position ?? 0) - (b.position ?? 0)
  );
  const [index, setIndex] = useState(0);
  const photo = ordered[index] ?? ordered[0];

  const maxDots = Math.min(ordered.length, 6);
  const activeDot =
    ordered.length <= maxDots
      ? index
      : Math.round((index / (ordered.length - 1)) * (maxDots - 1));

  if (!photo) {
    return <View style={[styles.fill, styles.placeholder, style]} />;
  }

  return (
    <View style={[styles.fill, style]}>
      <Image source={{ uri: photo.url }} style={styles.fill} />
      {ordered.length > 1 && (
        <>
          <View style={styles.dotsRow} pointerEvents="none">
            {Array.from({ length: maxDots }).map((_, i) => (
              <View key={i} style={[styles.dot, i === activeDot && styles.dotActive]} />
            ))}
          </View>
          {index > 0 && (
            <Pressable
              style={({ pressed }) => [
                styles.arrow,
                styles.arrowLeft,
                pressed && styles.arrowPressed,
              ]}
              onPress={() => setIndex((i) => Math.max(0, i - 1))}
            >
              <BlurView intensity={40} tint="dark" style={styles.arrowInner}>
                <MaterialIcons name="chevron-left" size={22} color="#fff" />
              </BlurView>
            </Pressable>
          )}
          {index < ordered.length - 1 && (
            <Pressable
              style={({ pressed }) => [
                styles.arrow,
                styles.arrowRight,
                pressed && styles.arrowPressed,
              ]}
              onPress={() => setIndex((i) => Math.min(ordered.length - 1, i + 1))}
            >
              <BlurView intensity={40} tint="dark" style={styles.arrowInner}>
                <MaterialIcons name="chevron-right" size={22} color="#fff" />
              </BlurView>
            </Pressable>
          )}
        </>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  fill: { width: '100%', height: '100%' },
  placeholder: { backgroundColor: '#241a1c' },
  dotsRow: {
    position: 'absolute',
    top: 10,
    left: '25%',
    right: '25%',
    flexDirection: 'row',
    gap: 2,
    zIndex: 4,
  },
  dot: { flex: 1, height: 1.5, borderRadius: 1, backgroundColor: 'rgba(255,255,255,0.35)' },
  dotActive: { backgroundColor: '#fff' },
  arrow: {
    position: 'absolute',
    top: '50%',
    marginTop: -18,
    width: 36,
    height: 36,
    borderRadius: 18,
    overflow: 'hidden',
    zIndex: 4,
    shadowColor: '#8B5CF6',
    shadowOpacity: 0.35,
    shadowRadius: 10,
    shadowOffset: { width: 0, height: 0 },
    elevation: 6,
  },
  arrowLeft: { left: 10 },
  arrowRight: { right: 10 },
  arrowPressed: { opacity: 0.7 },
  arrowInner: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.5)',
    borderRadius: 18,
    backgroundColor: Platform.select({
      web: 'rgba(20,15,17,0.5)',
      default: 'rgba(20,15,17,0.25)',
    }),
  },
});
