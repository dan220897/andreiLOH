import { LinearGradient } from 'expo-linear-gradient';
import { useEffect, useId } from 'react';
import { Platform, StyleSheet, useWindowDimensions, View } from 'react-native';
import Animated, {
  Easing,
  interpolate,
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withSequence,
  withTiming,
} from 'react-native-reanimated';
import Svg, { Defs, RadialGradient, Rect, Stop } from 'react-native-svg';

const OVERSCAN = 1.4;
const IS_WEB = Platform.OS === 'web';

// Native background. Kept separate (and rendered via an early return before any
// hooks) because mixing the reanimated hooks + a react-native-svg element in the
// same component silently prevented this View from painting on the New
// Architecture (Fabric). expo-linear-gradient composites correctly behind content.
// Vertical gradient built from stacked plain Views. expo-linear-gradient does
// not render and a full-screen react-native-svg paints OVER content on this
// Android (Fabric) build, but plain Views composite correctly behind content.
const GRADIENT_STOPS: [number, number, number][] = [
  [95, 60, 185], // top: vivid purple
  [74, 46, 151],
  [58, 37, 120],
  [40, 24, 78],
  [26, 15, 46],
  [14, 10, 24],
  [10, 7, 20], // bottom: near-black
];
const BANDS = 48;

function lerp(a: number, b: number, t: number) {
  return Math.round(a + (b - a) * t);
}

function NativeAuthBackground() {
  const bands = Array.from({ length: BANDS }, (_, i) => {
    const p = (i / (BANDS - 1)) * (GRADIENT_STOPS.length - 1);
    const lo = Math.floor(p);
    const hi = Math.min(lo + 1, GRADIENT_STOPS.length - 1);
    const t = p - lo;
    const c = GRADIENT_STOPS[lo].map((v, k) => lerp(v, GRADIENT_STOPS[hi][k], t));
    return `rgb(${c[0]},${c[1]},${c[2]})`;
  });
  return (
    <View pointerEvents="none" style={[StyleSheet.absoluteFillObject, { backgroundColor: '#0a0714' }]}>
      {bands.map((color, i) => (
        <View key={i} style={{ height: `${100 / BANDS}%`, backgroundColor: color }} />
      ))}
    </View>
  );
}

export default function AuthBackground() {
  if (!IS_WEB) {
    return <NativeAuthBackground />;
  }

  // Web: animated SVG radial-gradient background.
  const { width, height } = useWindowDimensions();
  const uid = useId();
  const gid = (name: string) => `${uid}-${name}`;

  const drift = useSharedValue(0);

  useEffect(() => {
    drift.value = withRepeat(
      withSequence(
        withTiming(1, { duration: 4000, easing: Easing.inOut(Easing.sin) }),
        withTiming(0, { duration: 4000, easing: Easing.inOut(Easing.sin) })
      ),
      -1,
      false
    );
  }, []);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [
      { translateX: interpolate(drift.value, [0, 1], [-45, 45]) },
      { translateY: interpolate(drift.value, [0, 1], [-55, 40]) },
      { scale: interpolate(drift.value, [0, 1], [1, 1.14]) },
    ],
  }));

  return (
    <Animated.View
      style={[
        StyleSheet.absoluteFillObject,
        {
          width: width * OVERSCAN,
          height: height * OVERSCAN,
          left: -((width * OVERSCAN - width) / 2),
          top: -((height * OVERSCAN - height) / 2),
          pointerEvents: 'none',
        },
        animatedStyle,
      ]}
    >
      <Svg width="100%" height="100%" viewBox="0 0 400 800" preserveAspectRatio="none">
        <Defs>
          <RadialGradient id={gid('base')} cx="50%" cy="45%" r="80%">
            <Stop offset="0%" stopColor="#3f2a86" />
            <Stop offset="100%" stopColor="#0a0714" />
          </RadialGradient>
          <RadialGradient id={gid('topLeft')} cx="8%" cy="2%" r="38%">
            <Stop offset="0%" stopColor="#181038" stopOpacity="1" />
            <Stop offset="100%" stopColor="#181038" stopOpacity="0" />
          </RadialGradient>
          <RadialGradient id={gid('topRight')} cx="88%" cy="6%" r="48%">
            <Stop offset="0%" stopColor="#d7d9fb" stopOpacity="0.95" />
            <Stop offset="45%" stopColor="#9b8fe6" stopOpacity="0.55" />
            <Stop offset="100%" stopColor="#9b8fe6" stopOpacity="0" />
          </RadialGradient>
          <RadialGradient id={gid('center')} cx="52%" cy="42%" r="32%">
            <Stop offset="0%" stopColor="#8b3fe0" stopOpacity="0.6" />
            <Stop offset="100%" stopColor="#8b3fe0" stopOpacity="0" />
          </RadialGradient>
          <RadialGradient id={gid('bottomLeft')} cx="12%" cy="88%" r="48%">
            <Stop offset="0%" stopColor="#b6a9ec" stopOpacity="0.85" />
            <Stop offset="100%" stopColor="#b6a9ec" stopOpacity="0" />
          </RadialGradient>
          <RadialGradient id={gid('bottomRight')} cx="92%" cy="98%" r="42%">
            <Stop offset="0%" stopColor="#050308" stopOpacity="1" />
            <Stop offset="100%" stopColor="#050308" stopOpacity="0" />
          </RadialGradient>
        </Defs>
        <Rect x="0" y="0" width="400" height="800" fill={`url(#${gid('base')})`} />
        <Rect x="0" y="0" width="400" height="800" fill={`url(#${gid('topLeft')})`} />
        <Rect x="0" y="0" width="400" height="800" fill={`url(#${gid('topRight')})`} />
        <Rect x="0" y="0" width="400" height="800" fill={`url(#${gid('center')})`} />
        <Rect x="0" y="0" width="400" height="800" fill={`url(#${gid('bottomLeft')})`} />
        <Rect x="0" y="0" width="400" height="800" fill={`url(#${gid('bottomRight')})`} />
      </Svg>
    </Animated.View>
  );
}
