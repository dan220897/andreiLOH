import { MaterialIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { Dimensions, Modal, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import PhotoCarousel from './PhotoCarousel';
import VerifiedBadge from './VerifiedBadge';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const PHOTO_HEIGHT = Math.round(SCREEN_WIDTH * (4 / 3));

type ProfileDetail = {
  id: string;
  display_name: string;
  birth_date: string;
  height_cm: number;
  bio: string | null;
  city?: string | null;
  profession?: string | null;
  interests?: string[] | null;
  verification_status?: string | null;
  is_premium?: boolean;
  distance_km?: number | null;
  last_active_at?: string | null;
  company_name?: string | null;
  business_position?: string | null;
  photos: { url: string; is_main: boolean; position?: number }[];
};

const ACCENT = '#8B5CF6';
const BORDER = 'rgba(255,255,255,0.14)';

function calcAge(birthDate: string) {
  const diff = Date.now() - new Date(birthDate).getTime();
  return Math.floor(diff / (1000 * 60 * 60 * 24 * 365.25));
}

function lastActiveInfo(lastActiveAt: string | null | undefined) {
  if (!lastActiveAt) return null;
  const minutes = Math.floor((Date.now() - new Date(lastActiveAt).getTime()) / 60000);
  if (minutes < 5) return { online: true, label: 'Сейчас на сайте' };
  if (minutes < 60) return { online: false, label: `Был(а) в сети ${minutes} мин назад` };
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return { online: false, label: `Был(а) в сети ${hours} ч назад` };
  const days = Math.floor(hours / 24);
  if (days < 7) return { online: false, label: `Был(а) в сети ${days} дн назад` };
  return { online: false, label: 'Давно не был(а) в сети' };
}

function InfoPill({ icon, text }: { icon: keyof typeof MaterialIcons.glyphMap; text: string }) {
  return (
    <View style={styles.pill}>
      <MaterialIcons name={icon} size={14} color={ACCENT} />
      <Text style={styles.pillText}>{text}</Text>
    </View>
  );
}

export default function ProfileDetailModal({
  profile,
  onClose,
  onLike,
  onPass,
}: {
  profile: ProfileDetail | null;
  onClose: () => void;
  onLike?: () => void;
  onPass?: () => void;
}) {
  if (!profile) return null;

  const status = lastActiveInfo(profile.last_active_at);
  const showActions = !!(onLike || onPass);

  return (
    <Modal visible={!!profile} animationType="slide" transparent onRequestClose={onClose}>
      <View style={styles.backdrop}>
        <View style={styles.sheet}>
        <ScrollView
          style={styles.sheetScroll}
          contentContainerStyle={styles.sheetContent}
          showsVerticalScrollIndicator={false}
        >
          <View style={styles.photoWrap}>
            <PhotoCarousel photos={profile.photos} style={styles.photo} />
            <LinearGradient
              colors={['transparent', 'rgba(20,15,17,0.85)', '#140F11']}
              locations={[0.55, 0.85, 1]}
              style={styles.photoFade}
              pointerEvents="none"
            />
            {profile.is_premium && (
              <View style={styles.plusBadge}>
                <Text style={styles.plusBadgeText}>PLUS</Text>
              </View>
            )}
          </View>
          <Pressable style={styles.closeButton} onPress={onClose}>
            <MaterialIcons name="close" size={18} color="#fff" />
          </Pressable>

          <View style={styles.info}>
            <View style={styles.nameRow}>
              <Text style={styles.name}>
                {profile.display_name}, {calcAge(profile.birth_date)}
              </Text>
              {profile.verification_status === 'verified' && <VerifiedBadge size={22} />}
            </View>

            {status && (
              <View style={styles.statusRow}>
                <View style={[styles.statusDot, status.online && styles.statusDotOnline]} />
                <Text style={[styles.statusText, status.online && styles.statusTextOnline]}>
                  {status.label}
                </Text>
              </View>
            )}

            {profile.profession ? (
              <Text style={styles.profession}>{profile.profession}</Text>
            ) : null}

            {profile.company_name ? (
              <View style={styles.businessRow}>
                <MaterialIcons name="business-center" size={15} color={ACCENT} />
                <Text style={styles.businessText}>
                  {profile.company_name}
                  {profile.business_position ? ` · ${profile.business_position}` : ''}
                </Text>
              </View>
            ) : null}

            <View style={styles.pillRow}>
              {profile.height_cm ? <InfoPill icon="height" text={`${profile.height_cm} см`} /> : null}
              {profile.distance_km != null ? (
                <InfoPill icon="location-on" text={`${Math.round(profile.distance_km)} км`} />
              ) : null}
              {profile.city ? <InfoPill icon="place" text={profile.city} /> : null}
            </View>

            {profile.bio ? <Text style={styles.bio}>{profile.bio}</Text> : null}

            {profile.interests && profile.interests.length > 0 && (
              <>
                <Text style={styles.sectionLabel}>Интересы</Text>
                <View style={styles.interestsWrap}>
                  {profile.interests.map((interest) => (
                    <View key={interest} style={styles.interestChip}>
                      <Text style={styles.interestChipText}>{interest}</Text>
                    </View>
                  ))}
                </View>
              </>
            )}
          </View>
        </ScrollView>
        {showActions && (
          <View style={styles.actionsFooter}>
            {onPass && (
              <Pressable style={[styles.footerButton, styles.footerPassButton]} onPress={onPass}>
                <MaterialIcons name="close" size={26} color="#EF476F" />
              </Pressable>
            )}
            {onLike && (
              <Pressable style={[styles.footerButton, styles.footerLikeButton]} onPress={onLike}>
                <MaterialIcons name="favorite" size={24} color={ACCENT} />
              </Pressable>
            )}
          </View>
        )}
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: { flex: 1, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'flex-end' },
  sheet: {
    maxHeight: '88%',
    backgroundColor: '#140F11',
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderWidth: 1,
    borderColor: BORDER,
    shadowColor: ACCENT,
    shadowOpacity: 0.3,
    shadowRadius: 30,
    shadowOffset: { width: 0, height: -6 },
    elevation: 12,
  },
  sheetScroll: { flex: 1 },
  sheetContent: { paddingBottom: 32 },
  actionsFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 24,
    paddingVertical: 14,
    borderTopWidth: 1,
    borderTopColor: BORDER,
  },
  footerButton: {
    width: 56,
    height: 56,
    borderRadius: 28,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1.5,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  footerPassButton: { borderColor: 'rgba(239,71,111,0.5)' },
  footerLikeButton: {
    borderWidth: 2,
    borderColor: ACCENT,
    shadowColor: ACCENT,
    shadowOpacity: 0.5,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 0 },
    elevation: 8,
  },
  photoWrap: {
    width: '100%',
    height: PHOTO_HEIGHT,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    overflow: 'hidden',
  },
  photo: { width: '100%', height: '100%' },
  photoFade: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    height: 90,
    zIndex: 3,
  },
  plusBadge: {
    position: 'absolute',
    left: 16,
    bottom: 16,
    backgroundColor: 'rgba(0,0,0,0.45)',
    borderWidth: 1,
    borderColor: ACCENT,
    borderRadius: 12,
    paddingVertical: 3,
    paddingHorizontal: 10,
    zIndex: 5,
  },
  plusBadgeText: { color: '#fff', fontSize: 10, fontWeight: '800', letterSpacing: 0.5 },
  closeButton: {
    position: 'absolute',
    top: 16,
    right: 16,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(20,15,17,0.5)',
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.5)',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 5,
  },
  info: { padding: 24, paddingTop: 4, gap: 4 },
  nameRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  name: { fontSize: 26, fontWeight: '800', color: '#fff' },
  statusRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 4 },
  statusDot: {
    width: 7,
    height: 7,
    borderRadius: 3.5,
    backgroundColor: '#6b6b70',
  },
  statusDotOnline: { backgroundColor: '#4ADE80' },
  statusText: { fontSize: 13, color: '#8a8a90', fontWeight: '500' },
  statusTextOnline: { color: '#4ADE80' },
  profession: { fontSize: 15, color: '#c9c0f5', fontWeight: '600', marginTop: 8 },
  businessRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 6 },
  businessText: { fontSize: 14, color: '#c9c0f5', fontWeight: '500', flexShrink: 1 },
  pillRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 12 },
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: 'rgba(139,92,246,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.3)',
    borderRadius: 14,
    paddingVertical: 6,
    paddingHorizontal: 12,
  },
  pillText: { color: '#e4defa', fontSize: 13, fontWeight: '600' },
  bio: { fontSize: 15, color: '#d0d0d5', marginTop: 16, lineHeight: 21 },
  sectionLabel: {
    fontSize: 13,
    color: '#8a8a90',
    fontWeight: '700',
    marginTop: 20,
    marginBottom: 10,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  interestsWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  interestChip: {
    borderWidth: 1,
    borderColor: BORDER,
    backgroundColor: 'rgba(139,92,246,0.12)',
    borderRadius: 16,
    paddingVertical: 6,
    paddingHorizontal: 14,
  },
  interestChipText: { color: '#c9c0f5', fontSize: 13, fontWeight: '600' },
});
