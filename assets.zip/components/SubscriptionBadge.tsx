import { LinearGradient } from 'expo-linear-gradient';
import { Platform, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useSubscriptionStatus } from '../lib/subscription';

export default function SubscriptionBadge() {
  const insets = useSafeAreaInsets();
  const status = useSubscriptionStatus();

  if (status !== 'plus') return null;

  return (
    <View style={[styles.wrap, { top: insets.top + 10 }]} pointerEvents="none">
      <LinearGradient colors={['#A78BFA', '#8B5CF6']} style={styles.badge}>
        <Text style={styles.textPlus}>PLUS</Text>
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    position: Platform.OS === 'web' ? ('fixed' as any) : 'absolute',
    left: 16,
    zIndex: 10,
  },
  badge: { paddingHorizontal: 12, paddingVertical: 6, borderRadius: 14 },
  textPlus: { color: '#fff', fontWeight: '800', fontSize: 12, letterSpacing: 0.5 },
});
