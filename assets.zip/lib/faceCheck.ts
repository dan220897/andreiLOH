// TODO: заглушка — реальная проверка лица потребует API распознавания
// (AWS Rekognition / Google Vision / Azure Face API). Сейчас имитирует задержку
// сети и всегда считает, что на фото есть человек.
export async function verifyFacePresent(_base64: string): Promise<boolean> {
  await new Promise((resolve) => setTimeout(resolve, 900));
  return true;
}
