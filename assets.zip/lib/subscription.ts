import { useEffect, useState } from 'react';
import { useAuth } from './auth-context';
import { supabase } from './supabase';

export function useSubscriptionStatus(): 'free' | 'plus' {
  const { session } = useAuth();
  const [isPlus, setIsPlus] = useState(false);

  useEffect(() => {
    if (!session) return;
    supabase
      .from('subscriptions')
      .select('id')
      .eq('profile_id', session.user.id)
      .eq('status', 'active')
      .gt('expires_at', new Date().toISOString())
      .maybeSingle()
      .then(({ data }) => setIsPlus(!!data));
  }, [session?.user.id]);

  return isPlus ? 'plus' : 'free';
}
