export type CompanyLookupResult = {
  name: string;
  inn: string;
  status: string;
  type: 'LEGAL' | 'INDIVIDUAL';
};

export async function findCompanyByInn(inn: string): Promise<CompanyLookupResult | null> {
  const apiKey = process.env.EXPO_PUBLIC_DADATA_API_KEY;
  const res = await fetch(
    'https://suggestions.dadata.ru/suggestions/api/4_1/rs/findById/party',
    {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Accept: 'application/json',
        Authorization: `Token ${apiKey}`,
      },
      body: JSON.stringify({ query: inn }),
    }
  );

  if (!res.ok) {
    throw new Error(`DaData error: ${res.status}`);
  }

  const data = await res.json();
  const suggestion = data.suggestions?.[0];
  if (!suggestion) return null;

  return {
    name: suggestion.value,
    inn: suggestion.data.inn,
    status: suggestion.data.state?.status ?? 'UNKNOWN',
    type: suggestion.data.type,
  };
}
