import { useGlobalSearchParams, useRouter } from 'expo-router';
import { useEffect } from 'react';
import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import { supabase } from '../../lib/supabase';

export default function AuthCallback() {
  const router = useRouter();
  const params = useGlobalSearchParams<{ code?: string }>();

  useEffect(() => {
    (async () => {
      if (params.code) {
        const { error } = await supabase.auth.exchangeCodeForSession(params.code);
        if (!error) {
          router.replace('/');
          return;
        }
      }
      router.replace('/(auth)/welcome');
    })();
  }, [params.code]);

  return (
    <View style={styles.container}>
      <ActivityIndicator />
      <Text style={styles.text}>Входим...</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12 },
  text: { color: '#666' },
});
