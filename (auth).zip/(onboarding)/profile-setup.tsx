import { decode } from 'base64-arraybuffer';
import { BlurView } from 'expo-blur';
import * as ImagePicker from 'expo-image-picker';
import * as Location from 'expo-location';
import { useRouter } from 'expo-router';
import { useMemo, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Image,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import AuthBackground from '../../components/AuthBackground';
import Calendar from '../../components/Calendar';
import PhotoGrid, { GridPhoto } from '../../components/PhotoGrid';
import { showAlert } from '../../lib/alert';
import { useAuth } from '../../lib/auth-context';
import { findCompanyByInn } from '../../lib/dadata';
import { verifyFacePresent } from '../../lib/faceCheck';
import { INTERESTS } from '../../lib/interests';
import { supabase } from '../../lib/supabase';

const GENDERS = [
  { value: 'male', label: 'Мужчина' },
  { value: 'female', label: 'Женщина' },
  { value: 'other', label: 'Другое' },
];

const PURPOSES = [
  { value: 'dating', label: 'Знакомства' },
  { value: 'business', label: 'Нетворкинг для бизнеса' },
];

const INTERESTED_IN = [
  { value: 'male', label: 'Мужчины' },
  { value: 'female', label: 'Женщины' },
  { value: 'all', label: 'Все' },
];

const POSITIONS = [
  'Основатель / CEO',
  'Генеральный директор',
  'Совладелец',
  'Директор по развитию',
  'Менеджер по продажам',
  'Маркетолог',
  'HR-менеджер',
  'Финансовый директор',
  'Другое',
];

const OTHER_POSITION = 'Другое';

function getSteps(purpose: string[]) {
  const steps = [
    { key: 'name', title: 'Как вас зовут?', subtitle: 'Так вас будут видеть другие люди.' },
    { key: 'birthDate', title: 'Дата рождения?', subtitle: 'Возраст будет виден в профиле.' },
    { key: 'gender', title: 'Ваш пол?', subtitle: 'Помогает точнее подбирать анкеты.' },
    {
      key: 'purpose',
      title: 'Для чего вам приложение?',
      subtitle: 'Можно выбрать один или оба варианта.',
    },
  ];
  if (purpose.includes('business')) {
    steps.push({
      key: 'company',
      title: 'Данные компании',
      subtitle: 'Проверим по ИНН, что компания реально существует.',
    });
  }
  steps.push(
    { key: 'interestedIn', title: 'Кто вам интересен?', subtitle: 'Кого вам показывать в ленте.' },
    { key: 'height', title: 'Какой у вас рост?', subtitle: 'В сантиметрах.' },
    {
      key: 'location',
      title: 'Где вы находитесь?',
      subtitle: 'Покажем анкеты рядом с вами. Можно указать город вручную.',
    },
    { key: 'bio', title: 'Немного о себе', subtitle: 'Необязательно, но помогает понравиться.' },
    {
      key: 'interests',
      title: 'Ваши интересы',
      subtitle: 'Выберите то, что вам нравится — кино, музыка и так далее.',
    },
    { key: 'photo', title: 'Добавьте фото', subtitle: 'Главное фото профиля.' },
    {
      key: 'verification',
      title: 'Подтвердите личность',
      subtitle: 'Сделайте селфи, чтобы мы убедились, что это точно вы.',
    }
  );
  return steps;
}

export default function ProfileSetup() {
  const router = useRouter();
  const { session, refreshProfile } = useAuth();

  const [step, setStep] = useState(0);
  const [gridPhotos, setGridPhotos] = useState<(GridPhoto | null)[]>(Array(6).fill(null));
  const [selfieUri, setSelfieUri] = useState<string | null>(null);
  const [selfieBase64, setSelfieBase64] = useState<string | null>(null);
  const [selfieVerifying, setSelfieVerifying] = useState(false);
  const [selfieVerified, setSelfieVerified] = useState(false);
  const [name, setName] = useState('');
  const [birthDateObj, setBirthDateObj] = useState<Date>(() => {
    const d = new Date();
    d.setFullYear(d.getFullYear() - 18);
    return d;
  });
  const birthDate = birthDateObj.toISOString().slice(0, 10);
  const [gender, setGender] = useState<string | null>(null);
  const [purpose, setPurpose] = useState<string[]>([]);
  const [companyName, setCompanyName] = useState('');
  const [companyInn, setCompanyInn] = useState('');
  const [companyVerifying, setCompanyVerifying] = useState(false);
  const [companyVerifiedStatus, setCompanyVerifiedStatus] = useState<string | null>(null);
  const [positionSelected, setPositionSelected] = useState<string | null>(null);
  const [positionCustom, setPositionCustom] = useState('');
  const [positionPickerOpen, setPositionPickerOpen] = useState(false);
  const position = positionSelected === OTHER_POSITION ? positionCustom : positionSelected ?? '';
  const [interestedIn, setInterestedIn] = useState<string | null>(null);
  const [height, setHeight] = useState('');
  const [city, setCity] = useState('');
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [locating, setLocating] = useState(false);
  const [bio, setBio] = useState('');
  const [profession, setProfession] = useState('');
  const [interests, setInterests] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);

  const steps = useMemo(() => getSteps(purpose), [purpose]);

  const takeSelfie = async () => {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) {
      showAlert('Нет доступа к камере', 'Разрешите доступ к камере в настройках');
      return;
    }
    const result = await ImagePicker.launchCameraAsync({
      quality: 0.7,
      base64: true,
      cameraType: ImagePicker.CameraType.front,
    });
    if (result.canceled || !result.assets[0]) return;

    const base64 = result.assets[0].base64 ?? '';
    setSelfieUri(result.assets[0].uri);
    setSelfieBase64(base64);
    setSelfieVerified(false);
    setSelfieVerifying(true);
    const ok = await verifyFacePresent(base64);
    setSelfieVerifying(false);
    setSelfieVerified(ok);
    if (!ok) {
      showAlert('Не удалось распознать лицо', 'Сделайте селфи ещё раз, лицо должно быть хорошо видно');
    }
  };

  const detectLocation = async () => {
    setLocating(true);
    try {
      const perm = await Location.requestForegroundPermissionsAsync();
      if (!perm.granted) {
        showAlert('Нет доступа к геолокации', 'Разрешите доступ в настройках или введите город вручную');
        return;
      }
      const position = await Location.getCurrentPositionAsync({});
      const { latitude, longitude } = position.coords;
      setCoords({ lat: latitude, lng: longitude });

      const places = await Location.reverseGeocodeAsync({ latitude, longitude });
      const place = places[0];
      const cityName = place?.city || place?.subregion || place?.region;
      if (cityName) setCity(cityName);
    } catch (err: any) {
      showAlert('Не удалось определить геопозицию', err.message);
    } finally {
      setLocating(false);
    }
  };

  const togglePurpose = (value: string) => {
    setPurpose((prev) =>
      prev.includes(value) ? prev.filter((p) => p !== value) : [...prev, value]
    );
  };

  const toggleInterest = (value: string) => {
    setInterests((prev) =>
      prev.includes(value) ? prev.filter((i) => i !== value) : [...prev, value]
    );
  };

  const checkInn = async () => {
    if (!companyInn.trim()) {
      showAlert('Введите ИНН');
      return;
    }
    setCompanyVerifying(true);
    setCompanyVerifiedStatus(null);
    try {
      const result = await findCompanyByInn(companyInn.trim());
      if (!result) {
        showAlert('Не найдено', 'Компания с таким ИНН не найдена в реестре');
        return;
      }
      if (result.type !== 'LEGAL') {
        showAlert(
          'Нужен ИНН компании',
          'Этот ИНН принадлежит физлицу или ИП. Введите ИНН юридического лица.'
        );
        return;
      }
      setCompanyName(result.name);
      setCompanyVerifiedStatus(result.status);
      showAlert('Найдено', `${result.name}\nСтатус: ${result.status}`);
    } catch (err: any) {
      showAlert('Ошибка проверки', err.message);
    } finally {
      setCompanyVerifying(false);
    }
  };

  const validateStep = (): boolean => {
    const key = steps[step].key;
    if (key === 'name' && !name.trim()) {
      showAlert('Введите имя');
      return false;
    }
    if (key === 'birthDate') {
      const age = (Date.now() - birthDateObj.getTime()) / (1000 * 60 * 60 * 24 * 365.25);
      if (age < 18) {
        showAlert('Вам должно быть 18 лет или больше');
        return false;
      }
    }
    if (key === 'gender' && !gender) {
      showAlert('Выберите пол');
      return false;
    }
    if (key === 'purpose' && purpose.length === 0) {
      showAlert('Выберите хотя бы один вариант');
      return false;
    }
    if (key === 'company') {
      if (!companyInn.trim()) {
        showAlert('Введите ИНН компании');
        return false;
      }
      if (!companyVerifiedStatus) {
        showAlert('Проверьте ИНН', 'Нажмите «Проверить ИНН» перед продолжением');
        return false;
      }
      if (!position.trim()) {
        showAlert('Введите вашу должность');
        return false;
      }
    }
    if (key === 'interestedIn' && !interestedIn) {
      showAlert('Выберите вариант');
      return false;
    }
    if (key === 'height') {
      const heightNum = parseInt(height, 10);
      if (isNaN(heightNum) || heightNum < 100 || heightNum > 250) {
        showAlert('Некорректный рост (100-250 см)');
        return false;
      }
    }
    if (key === 'location' && !city.trim()) {
      showAlert('Укажите город', 'Определите геопозицию или введите город вручную');
      return false;
    }
    if (key === 'photo' && !gridPhotos[0]) {
      showAlert('Добавьте главное фото профиля');
      return false;
    }
    if (key === 'verification' && !selfieVerified) {
      showAlert('Сделайте селфи для проверки личности');
      return false;
    }
    return true;
  };

  const save = async () => {
    if (!session || !gridPhotos[0] || !selfieBase64) return;
    setSaving(true);
    try {
      const isBusiness = purpose.includes('business');

      const selfiePath = `${session.user.id}/selfie.jpg`;
      const { error: selfieUploadError } = await supabase.storage
        .from('photos')
        .upload(selfiePath, decode(selfieBase64), { contentType: 'image/jpeg', upsert: true });
      if (selfieUploadError) throw selfieUploadError;
      const { data: selfiePublicUrl } = supabase.storage.from('photos').getPublicUrl(selfiePath);

      const { error: profileError } = await supabase.from('profiles').insert({
        id: session.user.id,
        display_name: name,
        birth_date: birthDate,
        gender,
        orientation: [],
        height_cm: parseInt(height, 10),
        bio,
        profession: profession.trim() || null,
        interests,
        city: city.trim() || null,
        location: coords ? `POINT(${coords.lng} ${coords.lat})` : null,
        is_business: isBusiness,
        verification_status: 'verified',
        verification_selfie_url: selfiePublicUrl.publicUrl,
      });
      if (profileError) throw profileError;

      for (let i = 0; i < gridPhotos.length; i++) {
        const gp = gridPhotos[i];
        if (!gp?.base64) continue;
        const path = `${session.user.id}/photo-${i}.jpg`;
        const { error: uploadError } = await supabase.storage
          .from('photos')
          .upload(path, decode(gp.base64), { contentType: 'image/jpeg', upsert: true });
        if (uploadError) throw uploadError;
        const { data: publicUrl } = supabase.storage.from('photos').getPublicUrl(path);
        const { error: photoRowError } = await supabase.from('photos').insert({
          profile_id: session.user.id,
          url: publicUrl.publicUrl,
          position: i,
          is_main: i === 0,
        });
        if (photoRowError) throw photoRowError;
      }

      const interestedInGenders =
        interestedIn === 'all' ? ['male', 'female', 'other'] : [interestedIn];
      const { error: prefError } = await supabase.from('preferences').insert({
        profile_id: session.user.id,
        interested_in_gender: interestedInGenders,
      });
      if (prefError) throw prefError;

      if (isBusiness) {
        const { error: businessError } = await supabase.from('business_profiles').insert({
          profile_id: session.user.id,
          company_name: companyName,
          inn: companyInn.trim(),
          position: position.trim(),
          verification_status: companyVerifiedStatus === 'ACTIVE' ? 'verified' : 'pending',
          verified_at: companyVerifiedStatus === 'ACTIVE' ? new Date().toISOString() : null,
        });
        if (businessError) throw businessError;
      }

      await refreshProfile();
      router.replace('/');
    } catch (err: any) {
      showAlert('Ошибка', err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleContinue = () => {
    if (!validateStep()) return;
    if (step === steps.length - 1) {
      save();
    } else {
      setStep(step + 1);
    }
  };

  const handleBack = () => {
    if (step > 0) setStep(step - 1);
  };

  const current = steps[step];

  return (
    <View style={styles.screen}>
      <AuthBackground />
      <StatusBar barStyle="light-content" />
      <KeyboardAvoidingView
        style={[styles.flex, styles.foreground]}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <View style={styles.progressRow}>
          {steps.map((_, i) => (
            <View key={i} style={styles.progressTrack}>
              <View style={[styles.progressFill, i <= step && styles.progressFillActive]} />
            </View>
          ))}
        </View>

        {step > 0 && (
          <Pressable style={styles.backButton} onPress={handleBack}>
            <Text style={styles.backButtonText}>←</Text>
          </Pressable>
        )}

        <View style={styles.content}>
          <Text style={styles.title}>{current.title}</Text>
          <Text style={styles.subtitle}>{current.subtitle}</Text>

          {current.key === 'name' && (
            <TextInput
              style={styles.input}
              placeholder="Ваше имя"
              placeholderTextColor="#6b6b70"
              value={name}
              onChangeText={setName}
              autoFocus
            />
          )}

          {current.key === 'birthDate' && (
            <Calendar
              value={birthDateObj}
              onChange={setBirthDateObj}
              maximumDate={new Date()}
              minimumDate={new Date(1930, 0, 1)}
            />
          )}

          {current.key === 'gender' && (
            <View style={styles.chipWrap}>
              {GENDERS.map((g) => (
                <Pressable
                  key={g.value}
                  style={[styles.chip, gender === g.value && styles.chipSelected]}
                  onPress={() => setGender(g.value)}
                >
                  <Text style={[styles.chipText, gender === g.value && styles.chipTextSelected]}>
                    {g.label}
                  </Text>
                </Pressable>
              ))}
            </View>
          )}

          {current.key === 'purpose' && (
            <View style={styles.chipWrap}>
              {PURPOSES.map((p) => (
                <Pressable
                  key={p.value}
                  style={[styles.chip, purpose.includes(p.value) && styles.chipSelected]}
                  onPress={() => togglePurpose(p.value)}
                >
                  <Text
                    style={[styles.chipText, purpose.includes(p.value) && styles.chipTextSelected]}
                  >
                    {p.label}
                  </Text>
                </Pressable>
              ))}
            </View>
          )}

          {current.key === 'company' && (
            <View style={{ gap: 12 }}>
              <TextInput
                style={styles.input}
                placeholder="ИНН компании"
                placeholderTextColor="#6b6b70"
                keyboardType="number-pad"
                value={companyInn}
                onChangeText={(t) => {
                  setCompanyInn(t);
                  setCompanyVerifiedStatus(null);
                }}
                autoFocus
              />
              <Pressable style={styles.secondaryButton} onPress={checkInn} disabled={companyVerifying}>
                {companyVerifying ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text style={styles.secondaryButtonText}>Проверить ИНН</Text>
                )}
              </Pressable>
              {companyVerifiedStatus && (
                <>
                  <View style={styles.companyResultVerified}>
                    <Text style={styles.companyResultName}>{companyName}</Text>
                  </View>
                  <Pressable style={styles.input} onPress={() => setPositionPickerOpen(true)}>
                    <Text style={positionSelected ? styles.dropdownValue : styles.dropdownPlaceholder}>
                      {positionSelected ?? 'Выберите должность'}
                    </Text>
                  </Pressable>
                  {positionSelected === OTHER_POSITION && (
                    <TextInput
                      style={styles.input}
                      placeholder="Введите вашу должность"
                      placeholderTextColor="#6b6b70"
                      value={positionCustom}
                      onChangeText={setPositionCustom}
                      autoFocus
                    />
                  )}
                </>
              )}
            </View>
          )}

          {current.key === 'interestedIn' && (
            <View style={styles.chipWrap}>
              {INTERESTED_IN.map((o) => (
                <Pressable
                  key={o.value}
                  style={[styles.chip, interestedIn === o.value && styles.chipSelected]}
                  onPress={() => setInterestedIn(o.value)}
                >
                  <Text
                    style={[styles.chipText, interestedIn === o.value && styles.chipTextSelected]}
                  >
                    {o.label}
                  </Text>
                </Pressable>
              ))}
            </View>
          )}

          {current.key === 'height' && (
            <TextInput
              style={styles.input}
              placeholder="Рост в см"
              placeholderTextColor="#6b6b70"
              keyboardType="number-pad"
              value={height}
              onChangeText={setHeight}
              autoFocus
            />
          )}

          {current.key === 'location' && (
            <View style={{ gap: 12 }}>
              <Pressable
                style={styles.secondaryButton}
                onPress={detectLocation}
                disabled={locating}
              >
                {locating ? (
                  <ActivityIndicator color="#fff" />
                ) : (
                  <Text style={styles.secondaryButtonText}>
                    {coords ? '📍 Геопозиция определена' : 'Определить геопозицию'}
                  </Text>
                )}
              </Pressable>
              <TextInput
                style={styles.input}
                placeholder="Город"
                placeholderTextColor="#6b6b70"
                value={city}
                onChangeText={setCity}
              />
            </View>
          )}

          {current.key === 'bio' && (
            <View style={{ gap: 12 }}>
              <TextInput
                style={styles.input}
                placeholder="Профессия (необязательно)"
                placeholderTextColor="#6b6b70"
                value={profession}
                onChangeText={setProfession}
                autoFocus
              />
              <TextInput
                style={[styles.input, styles.bioInput]}
                placeholder="О себе"
                placeholderTextColor="#6b6b70"
                multiline
                value={bio}
                onChangeText={setBio}
              />
            </View>
          )}

          {current.key === 'interests' && (
            <View style={styles.chipWrap}>
              {INTERESTS.map((i) => (
                <Pressable
                  key={i}
                  style={[styles.chip, interests.includes(i) && styles.chipSelected]}
                  onPress={() => toggleInterest(i)}
                >
                  <Text
                    style={[styles.chipText, interests.includes(i) && styles.chipTextSelected]}
                  >
                    {i}
                  </Text>
                </Pressable>
              ))}
            </View>
          )}

          {current.key === 'photo' && (
            <PhotoGrid photos={gridPhotos} onChange={setGridPhotos} />
          )}

          {current.key === 'verification' && (
            <View style={{ gap: 12 }}>
              <View style={styles.photoPicker}>
                {selfieUri ? (
                  <Image source={{ uri: selfieUri }} style={styles.photo} />
                ) : (
                  <Text style={styles.photoPickerText}>Селфи для проверки</Text>
                )}
                {selfieVerifying && (
                  <View style={styles.verifyOverlay}>
                    <ActivityIndicator color="#fff" size="large" />
                    <Text style={styles.verifyOverlayText}>Проверяем...</Text>
                  </View>
                )}
              </View>
              {selfieVerified && (
                <View style={styles.companyResultVerified}>
                  <Text style={styles.companyResultName}>✓ Личность подтверждена</Text>
                </View>
              )}
              <Pressable style={styles.secondaryButton} onPress={takeSelfie} disabled={selfieVerifying}>
                <Text style={styles.secondaryButtonText}>
                  {selfieUri ? 'Переснять селфи' : 'Сделать селфи'}
                </Text>
              </Pressable>
            </View>
          )}
        </View>

        <Pressable style={styles.ctaButtonWrap} onPress={handleContinue} disabled={saving}>
          <BlurView intensity={50} tint="dark" style={styles.ctaButton}>
            <Text style={styles.ctaButtonText}>
              {saving ? 'Сохранение...' : step === steps.length - 1 ? 'Готово' : 'Продолжить'}
            </Text>
          </BlurView>
        </Pressable>
      </KeyboardAvoidingView>

      <Modal
        visible={positionPickerOpen}
        animationType="fade"
        transparent
        onRequestClose={() => setPositionPickerOpen(false)}
      >
        <BlurView intensity={60} tint="dark" style={styles.modalSheet}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Выберите должность</Text>
            <Pressable
              style={styles.modalCloseButton}
              onPress={() => setPositionPickerOpen(false)}
            >
              <Text style={styles.modalCloseButtonText}>✕</Text>
            </Pressable>
          </View>
          <FlatList
            data={POSITIONS}
            keyExtractor={(item) => item}
            showsVerticalScrollIndicator={false}
            renderItem={({ item }) => (
              <Pressable
                style={styles.positionRow}
                onPress={() => {
                  setPositionSelected(item);
                  setPositionPickerOpen(false);
                }}
              >
                <Text
                  style={[
                    styles.positionRowText,
                    item === positionSelected && styles.positionRowTextActive,
                  ]}
                >
                  {item}
                </Text>
              </Pressable>
            )}
          />
        </BlurView>
      </Modal>
    </View>
  );
}

const BORDER = 'rgba(255,255,255,0.14)';

const styles = StyleSheet.create({
  screen: { flex: 1, minHeight: '100%' },
  flex: { flex: 1, padding: 24 },
  foreground: { zIndex: 1, elevation: 1 },
  progressRow: { flexDirection: 'row', gap: 6, marginTop: 8 },
  progressTrack: {
    flex: 1,
    height: 3,
    borderRadius: 2,
    backgroundColor: 'rgba(255,255,255,0.15)',
    overflow: 'hidden',
  },
  progressFill: { flex: 1, backgroundColor: 'transparent' },
  progressFillActive: { backgroundColor: '#8B5CF6' },
  backButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 20,
  },
  backButtonText: { color: '#fff', fontSize: 18, fontWeight: '600' },
  content: { flex: 1, marginTop: 24 },
  title: { fontSize: 30, fontWeight: '800', color: '#fff' },
  subtitle: { fontSize: 14, color: '#9a9aa0', marginTop: 8, marginBottom: 28 },
  input: {
    backgroundColor: 'rgba(255,255,255,0.07)',
    borderWidth: 1,
    borderColor: BORDER,
    borderRadius: 16,
    padding: 16,
    fontSize: 17,
    color: '#fff',
  },
  bioInput: { minHeight: 120, textAlignVertical: 'top' },
  chipWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  chip: {
    borderWidth: 1,
    borderColor: BORDER,
    backgroundColor: 'rgba(255,255,255,0.07)',
    borderRadius: 20,
    paddingVertical: 10,
    paddingHorizontal: 18,
  },
  chipSelected: { backgroundColor: '#8B5CF6', borderColor: '#8B5CF6' },
  chipText: { color: '#c9c9ce', fontSize: 15 },
  chipTextSelected: { color: '#fff', fontWeight: '600' },
  secondaryButton: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1,
    borderColor: BORDER,
    borderRadius: 16,
    paddingVertical: 14,
    alignItems: 'center',
  },
  secondaryButtonText: { color: '#fff', fontSize: 15, fontWeight: '600' },
  companyResultVerified: {
    backgroundColor: 'rgba(46,204,113,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(46,204,113,0.5)',
    borderRadius: 16,
    padding: 14,
  },
  companyResultName: { color: '#2ecc71', fontSize: 15, fontWeight: '700' },
  dropdownValue: { color: '#fff', fontSize: 17 },
  dropdownPlaceholder: { color: '#6b6b70', fontSize: 17 },
  modalSheet: {
    flex: 1,
    height: '100%',
    backgroundColor: 'rgba(20,18,20,0.85)',
    paddingTop: 56,
    paddingHorizontal: 20,
    paddingBottom: 24,
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  modalTitle: { color: '#fff', fontSize: 18, fontWeight: '700', textAlign: 'center' },
  modalCloseButton: {
    position: 'absolute',
    right: 0,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalCloseButtonText: { color: '#fff', fontSize: 14, fontWeight: '700' },
  positionRow: {
    paddingVertical: 16,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: BORDER,
  },
  positionRowText: { color: '#c9c9ce', fontSize: 16 },
  positionRowTextActive: { color: '#8B5CF6', fontWeight: '700' },
  photoPicker: {
    width: '100%',
    aspectRatio: 1,
    borderRadius: 24,
    backgroundColor: 'rgba(255,255,255,0.07)',
    borderWidth: 1,
    borderColor: BORDER,
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  photo: { width: '100%', height: '100%' },
  photoPickerText: { color: '#9a9aa0' },
  verifyOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.55)',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  verifyOverlayText: { color: '#fff', fontSize: 14, fontWeight: '600' },
  ctaButtonWrap: { borderRadius: 26, overflow: 'hidden', marginBottom: 8 },
  ctaButton: {
    borderRadius: 26,
    paddingVertical: 16,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: BORDER,
  },
  ctaButtonText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});
