import { FontAwesome5, MaterialCommunityIcons } from '@expo/vector-icons';
import { Tabs } from 'expo-router';
import { StyleSheet, View } from 'react-native';

const ACCENT = '#8B5CF6';
const INACTIVE = '#8a8a90';
const BAR_BG = '#0E0A0C';

function TabIcon({ focused, children }: { focused: boolean; children: React.ReactNode }) {
  return (
    <View style={[styles.iconWrap, focused && styles.iconWrapActive]}>{children}</View>
  );
}

export default function TabsLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarShowLabel: false,
        tabBarStyle: styles.tabBar,
        tabBarBackground: () => (
          <View style={[StyleSheet.absoluteFillObject, { backgroundColor: BAR_BG }]} />
        ),
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Знакомства',
          tabBarIcon: ({ focused }) => (
            <TabIcon focused={focused}>
              <MaterialCommunityIcons
                name={focused ? 'cards' : 'cards-outline'}
                size={24}
                color={focused ? '#fff' : INACTIVE}
              />
            </TabIcon>
          ),
        }}
      />
      <Tabs.Screen
        name="likes"
        options={{
          title: 'Лайки',
          tabBarIcon: ({ focused }) => (
            <TabIcon focused={focused}>
              <FontAwesome5 name="heart" size={20} color={focused ? '#fff' : INACTIVE} />
            </TabIcon>
          ),
        }}
      />
      <Tabs.Screen
        name="chats"
        options={{
          title: 'Чаты',
          tabBarIcon: ({ focused }) => (
            <TabIcon focused={focused}>
              <FontAwesome5 name="comment-dots" size={20} color={focused ? '#fff' : INACTIVE} />
            </TabIcon>
          ),
        }}
      />
      <Tabs.Screen
        name="profile"
        options={{
          title: 'Профиль',
          tabBarIcon: ({ focused }) => (
            <TabIcon focused={focused}>
              <FontAwesome5 name="user" size={20} color={focused ? '#fff' : INACTIVE} />
            </TabIcon>
          ),
        }}
      />
      <Tabs.Screen name="tonight" options={{ href: null }} />
      <Tabs.Screen name="business" options={{ href: null }} />
    </Tabs>
  );
}

const styles = StyleSheet.create({
  tabBar: {
    position: 'absolute',
    borderTopWidth: 0,
    backgroundColor: 'transparent',
    height: 72,
    paddingTop: 12,
    paddingBottom: 12,
  },
  iconWrap: {
    width: 46,
    height: 46,
    borderRadius: 23,
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconWrapActive: {
    backgroundColor: ACCENT,
  },
});
