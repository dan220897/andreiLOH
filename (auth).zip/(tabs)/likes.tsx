import { MaterialIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useFocusEffect } from 'expo-router';
import { useCallback, useState } from 'react';
import { ActivityIndicator, FlatList, Image, Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import MatchModal from '../../components/MatchModal';
import ProfileDetailModal from '../../components/ProfileDetailModal';
import SubscriptionBadge from '../../components/SubscriptionBadge';
import VerifiedBadge from '../../components/VerifiedBadge';
import { showAlert } from '../../lib/alert';
import { useAuth } from '../../lib/auth-context';
import { supabase } from '../../lib/supabase';

const BAR_BG = '#0E0A0C';
const ACCENT = '#8B5CF6';

type ProfileCard = {
  id: string;
  display_name: string;
  birth_date: string;
  gender: string;
  height_cm: number;
  bio: string | null;
  city: string | null;
  profession: string | null;
  interests: string[] | null;
  verification_status: string | null;
  photos: { url: string; is_main: boolean; position: number }[];
};

type Reaction = 'pending' | 'disliked';
type SentLike = ProfileCard & { reaction: Reaction };
type Tab = 'received' | 'sent';

function calcAge(birthDate: string) {
  const diff = Date.now() - new Date(birthDate).getTime();
  return Math.floor(diff / (1000 * 60 * 60 * 24 * 365.25));
}

const REACTION_LABEL: Record<Reaction, string> = {
  pending: 'Ждёт ответа',
  disliked: 'Не ответили',
};
const REACTION_ICON: Record<Reaction, keyof typeof MaterialIcons.glyphMap> = {
  pending: 'schedule',
  disliked: 'close',
};

export default function Likes() {
  const { session } = useAuth();
  const insets = useSafeAreaInsets();
  const [tab, setTab] = useState<Tab>('received');
  const [receivedLikes, setReceivedLikes] = useState<ProfileCard[] | null>(null);
  const [sentLikes, setSentLikes] = useState<SentLike[] | null>(null);
  const [detailProfile, setDetailProfile] = useState<ProfileCard | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [myPhotoUrl, setMyPhotoUrl] = useState<string | null>(null);
  const [matchModal, setMatchModal] = useState<{ target: ProfileCard; matchId: string | null } | null>(
    null
  );

  const load = useCallback(async () => {
    if (!session) return;
    const myId = session.user.id;
    const [incomingRes, myOutgoingRes, sentRes, theirActionsRes, matchesRes, myPhotoRes, myPrefRes] =
      await Promise.all([
        supabase
          .from('swipes')
          .select(
            'created_at, actor:profiles!swipes_actor_id_fkey(id, display_name, birth_date, gender, height_cm, bio, city, profession, interests, verification_status, photos(url, is_main, position))'
          )
          .eq('target_id', myId)
          .eq('action', 'like')
          .eq('context', 'dating')
          .order('created_at', { ascending: false }),
        supabase.from('swipes').select('target_id, action').eq('actor_id', myId).eq('context', 'dating'),
        supabase
          .from('swipes')
          .select(
            'created_at, target:profiles!swipes_target_id_fkey(id, display_name, birth_date, gender, height_cm, bio, city, profession, interests, verification_status, photos(url, is_main, position))'
          )
          .eq('actor_id', myId)
          .eq('action', 'like')
          .eq('context', 'dating')
          .order('created_at', { ascending: false }),
        supabase.from('swipes').select('actor_id, action').eq('target_id', myId).eq('context', 'dating'),
        supabase
          .from('matches')
          .select('user_a_id, user_b_id')
          .eq('context', 'dating')
          .or(`user_a_id.eq.${myId},user_b_id.eq.${myId}`),
        supabase
          .from('photos')
          .select('url')
          .eq('profile_id', myId)
          .eq('is_main', true)
          .maybeSingle(),
        supabase
          .from('preferences')
          .select('interested_in_gender')
          .eq('profile_id', myId)
          .maybeSingle(),
      ]);

    if (incomingRes.error) {
      console.error(incomingRes.error);
      setReceivedLikes([]);
      setSentLikes([]);
      return;
    }

    setMyPhotoUrl(myPhotoRes.data?.url ?? null);

    // only show people whose gender matches what I'm looking for
    const interestedInGender = myPrefRes.data?.interested_in_gender ?? [];
    const matchesGender = (g: string) => interestedInGender.length === 0 || interestedInGender.includes(g);

    // people I've already disliked (hide from "received")
    const myActionMap = new Map<string, string>(
      (myOutgoingRes.data ?? []).map((s: any) => [s.target_id, s.action])
    );
    // their reaction toward me (used for the "Мои лайки" status badge)
    const theirActionMap = new Map<string, string>(
      (theirActionsRes.data ?? []).map((r: any) => [r.actor_id, r.action])
    );
    // anyone already matched lives in Chats now, never on the Likes screen
    const matchedIds = new Set(
      (matchesRes.data ?? []).map((m: any) => (m.user_a_id === myId ? m.user_b_id : m.user_a_id))
    );

    const received = (incomingRes.data ?? [])
      .map((row: any) => row.actor as ProfileCard)
      .filter(
        (actor) =>
          actor &&
          myActionMap.get(actor.id) !== 'dislike' &&
          !matchedIds.has(actor.id) &&
          matchesGender(actor.gender)
      );
    setReceivedLikes(received);

    const sent = (sentRes.data ?? [])
      .map((row: any) => row.target as ProfileCard)
      .filter((t) => !!t && !matchedIds.has(t.id) && matchesGender(t.gender))
      .map((t): SentLike => {
        const theirAction = theirActionMap.get(t.id);
        const reaction: Reaction = theirAction === 'dislike' ? 'disliked' : 'pending';
        return { ...t, reaction };
      });
    setSentLikes(sent);
  }, [session?.user.id]);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const likeBack = async (target: ProfileCard) => {
    if (!session || busyId) return;
    setBusyId(target.id);
    const { error } = await supabase.from('swipes').insert({
      actor_id: session.user.id,
      target_id: target.id,
      action: 'like',
      context: 'dating',
    });
    if (error) {
      setBusyId(null);
      showAlert('Ошибка', error.message);
      return;
    }
    const { data: matchRow } = await supabase
      .from('matches')
      .insert({ user_a_id: session.user.id, user_b_id: target.id, context: 'dating' })
      .select('id')
      .single();
    setReceivedLikes((prev) => (prev ? prev.filter((l) => l.id !== target.id) : prev));
    setBusyId(null);
    setDetailProfile(null);
    setMatchModal({ target, matchId: matchRow?.id ?? null });
  };

  const passLike = async (target: ProfileCard) => {
    if (!session || busyId) return;
    setBusyId(target.id);
    const { error } = await supabase.from('swipes').insert({
      actor_id: session.user.id,
      target_id: target.id,
      action: 'dislike',
      context: 'dating',
    });
    setBusyId(null);
    if (error) {
      showAlert('Ошибка', error.message);
      return;
    }
    setReceivedLikes((prev) => (prev ? prev.filter((l) => l.id !== target.id) : prev));
    setDetailProfile(null);
  };

  const receivedCount = receivedLikes?.length ?? 0;
  const activeList = tab === 'received' ? receivedLikes : sentLikes;

  const SegmentedControl = (
    <View style={[styles.segmentRow, { top: insets.top + 16 }]}>
      <Pressable
        style={[styles.segmentPill, tab === 'received' && styles.segmentPillActive]}
        onPress={() => setTab('received')}
      >
        <MaterialIcons
          name="favorite"
          size={14}
          color={tab === 'received' ? '#fff' : '#8a8a90'}
        />
        <Text style={[styles.segmentPillText, tab === 'received' && styles.segmentPillTextActive]}>
          Меня лайкнули
        </Text>
        {receivedCount > 0 && (
          <View style={styles.segmentCountPill}>
            <Text style={styles.segmentCountText}>{receivedCount}</Text>
          </View>
        )}
      </Pressable>
      <Pressable
        style={[styles.segmentPill, tab === 'sent' && styles.segmentPillActive]}
        onPress={() => setTab('sent')}
      >
        <MaterialIcons name="send" size={14} color={tab === 'sent' ? '#fff' : '#8a8a90'} />
        <Text style={[styles.segmentPillText, tab === 'sent' && styles.segmentPillTextActive]}>
          Мои лайки
        </Text>
      </Pressable>
    </View>
  );

  return (
    <View style={[styles.screen, { backgroundColor: BAR_BG }]}>
      <SubscriptionBadge />
      {SegmentedControl}

      {activeList === null ? (
        <View style={styles.center}>
          <ActivityIndicator color="#fff" />
        </View>
      ) : activeList.length === 0 ? (
        <View style={styles.center}>
          <View style={styles.emptyIconWrap}>
            <MaterialIcons
              name={tab === 'received' ? 'favorite-border' : 'send'}
              size={30}
              color={ACCENT}
            />
          </View>
          <Text style={styles.title}>
            {tab === 'received' ? 'Пока нет лайков' : 'Вы никого не лайкнули'}
          </Text>
          <Text style={styles.subtitle}>
            {tab === 'received'
              ? 'Здесь появятся те, кто вас лайкнул'
              : 'Анкеты, которые вы лайкнули, появятся здесь'}
          </Text>
        </View>
      ) : (
        <FlatList
          data={activeList}
          keyExtractor={(item) => item.id}
          numColumns={2}
          contentContainerStyle={[
            styles.grid,
            { paddingTop: insets.top + 92, paddingBottom: 96 },
          ]}
          columnWrapperStyle={{ gap: 12 }}
          renderItem={({ item }) => {
            const photo = item.photos?.find((p) => p.is_main) ?? item.photos?.[0];
            const reaction: Reaction | null = tab === 'sent' ? (item as SentLike).reaction : null;
            return (
              <Pressable style={styles.card} onPress={() => setDetailProfile(item)}>
                {photo ? (
                  <Image source={{ uri: photo.url }} style={styles.photo} />
                ) : (
                  <View style={[styles.photo, styles.photoPlaceholder]} />
                )}
                <LinearGradient
                  colors={['transparent', 'rgba(14,10,12,0.55)', BAR_BG]}
                  locations={[0, 0.5, 1]}
                  style={styles.overlay}
                >
                  <View style={styles.nameRow}>
                    <Text style={styles.name} numberOfLines={1}>
                      {item.display_name}, {calcAge(item.birth_date)}
                    </Text>
                    {item.verification_status === 'verified' && <VerifiedBadge size={14} />}
                  </View>
                  {item.city ? (
                    <View style={styles.cityRow}>
                      <MaterialIcons name="place" size={12} color="#9a9aa0" />
                      <Text style={styles.city} numberOfLines={1}>
                        {item.city}
                      </Text>
                    </View>
                  ) : null}
                  {reaction ? (
                    <View
                      style={[
                        styles.reactionPill,
                        reaction === 'disliked' && styles.reactionPillDisliked,
                      ]}
                    >
                      <MaterialIcons
                        name={REACTION_ICON[reaction]}
                        size={11}
                        color={reaction === 'disliked' ? '#EF476F' : '#9a9aa0'}
                      />
                      <Text
                        style={[
                          styles.reactionText,
                          reaction === 'disliked' && styles.reactionTextDisliked,
                        ]}
                      >
                        {REACTION_LABEL[reaction]}
                      </Text>
                    </View>
                  ) : null}
                </LinearGradient>
              </Pressable>
            );
          }}
        />
      )}

      <ProfileDetailModal
        profile={detailProfile}
        onClose={() => setDetailProfile(null)}
        onLike={tab === 'received' && detailProfile ? () => likeBack(detailProfile) : undefined}
        onPass={tab === 'received' && detailProfile ? () => passLike(detailProfile) : undefined}
      />

      <MatchModal
        visible={!!matchModal}
        myPhotoUrl={myPhotoUrl}
        otherPhotoUrl={
          matchModal
            ? (matchModal.target.photos?.find((p) => p.is_main) ?? matchModal.target.photos?.[0])
                ?.url ?? null
            : null
        }
        otherName={matchModal?.target.display_name ?? ''}
        matchId={matchModal?.matchId ?? null}
        onClose={() => setMatchModal(null)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  segmentRow: {
    position: 'absolute',
    left: 0,
    right: 0,
    alignSelf: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 8,
    zIndex: 9,
  },
  segmentPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    borderRadius: 14,
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  segmentPillActive: {
    backgroundColor: 'rgba(139,92,246,0.35)',
    borderColor: ACCENT,
  },
  segmentPillText: { color: '#8a8a90', fontSize: 13, fontWeight: '600' },
  segmentPillTextActive: { color: '#fff' },
  segmentCountPill: {
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    paddingHorizontal: 5,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 2,
  },
  segmentCountText: { color: ACCENT, fontSize: 10, fontWeight: '800' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 8, padding: 24 },
  emptyIconWrap: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(139,92,246,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.3)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
  },
  title: { color: '#fff', fontSize: 18, fontWeight: '700' },
  subtitle: { color: '#9a9aa0', fontSize: 14, textAlign: 'center' },
  grid: { padding: 12, gap: 12 },
  card: {
    flex: 1,
    aspectRatio: 0.75,
    borderRadius: 18,
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  photo: { width: '100%', height: '100%' },
  photoPlaceholder: { backgroundColor: '#241a1c' },
  overlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    padding: 10,
    paddingTop: 34,
  },
  nameRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  name: { color: '#fff', fontSize: 14, fontWeight: '700', flexShrink: 1 },
  cityRow: { flexDirection: 'row', alignItems: 'center', gap: 3, marginTop: 3 },
  city: { color: '#9a9aa0', fontSize: 12, fontWeight: '500', flexShrink: 1 },
  reactionPill: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    gap: 3,
    marginTop: 4,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 10,
    paddingVertical: 2,
    paddingHorizontal: 7,
  },
  reactionPillDisliked: { backgroundColor: 'rgba(239,71,111,0.15)' },
  reactionText: { color: '#c9c9ce', fontSize: 10, fontWeight: '700' },
  reactionTextDisliked: { color: '#EF476F' },
});
