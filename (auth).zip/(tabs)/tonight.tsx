import { MaterialIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import SubscriptionBadge from '../../components/SubscriptionBadge';

export default function Tonight() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  return (
    <LinearGradient colors={['#0E0A0C', '#1A0A0D']} style={styles.screen}>
      <SubscriptionBadge />
      <Pressable
        style={[styles.backButton, { top: insets.top + 10 }]}
        onPress={() => router.back()}
      >
        <MaterialIcons name="close" size={18} color="#fff" />
      </Pressable>
      <View style={styles.center}>
        <View style={styles.iconWrap}>
          <Text style={styles.emoji}>🌙</Text>
        </View>
        <Text style={styles.title}>Tonight — скоро</Text>
        <Text style={styles.subtitle}>Статусы на вечер и свободные сегодня рядом с вами</Text>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 8, padding: 24 },
  iconWrap: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(139,92,246,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.3)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
  },
  emoji: { fontSize: 30 },
  title: { color: '#fff', fontSize: 18, fontWeight: '700' },
  subtitle: { color: '#9a9aa0', fontSize: 14, textAlign: 'center' },
  backButton: {
    position: 'absolute',
    right: 16,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 10,
  },
});
