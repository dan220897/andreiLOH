import { MaterialIcons } from '@expo/vector-icons';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import { useEffect, useState } from 'react';
import {
  ActivityIndicator,
  Dimensions,
  Image,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Animated, {
  Extrapolation,
  interpolate,
  runOnJS,
  useAnimatedStyle,
  useSharedValue,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import MatchModal from '../../components/MatchModal';
import PhotoCarousel from '../../components/PhotoCarousel';
import ProfileDetailModal from '../../components/ProfileDetailModal';
import SubscriptionBadge from '../../components/SubscriptionBadge';
import VerifiedBadge from '../../components/VerifiedBadge';
import { showAlert } from '../../lib/alert';
import { useAuth } from '../../lib/auth-context';
import { INTERESTS } from '../../lib/interests';
import { supabase } from '../../lib/supabase';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const SWIPE_THRESHOLD = 120;
// PhotoCarousel arrows sit 10px from each edge, are 36px wide, and are vertically
// centered — this is that hitbox plus a 20px buffer so a near-miss tap never opens
// the profile detail sheet instead of paging the photo.
const ARROW_TAP_ZONE_X = 10 + 36 + 20;
const ARROW_TAP_ZONE_Y_HALF = 18 + 20;
const BAR_BG = '#0E0A0C';

type Candidate = {
  id: string;
  display_name: string;
  birth_date: string;
  bio: string | null;
  height_cm: number;
  city: string | null;
  profession: string | null;
  interests: string[] | null;
  verification_status: string | null;
  is_premium: boolean;
  distance_km: number | null;
  last_active_at: string | null;
  company_name: string | null;
  business_position: string | null;
  photos: { url: string; is_main: boolean; position: number }[];
};

type DealContext = 'dating' | 'business';
type SwipeAction = 'like' | 'dislike' | 'superlike';

function calcAge(birthDate: string) {
  const diff = Date.now() - new Date(birthDate).getTime();
  return Math.floor(diff / (1000 * 60 * 60 * 24 * 365.25));
}

function mainPhotoOf(c: Candidate) {
  return c.photos.find((p) => p.is_main) ?? c.photos[0];
}

export default function SwipeDeck() {
  const { session, profile, refreshProfile } = useAuth();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [dealContext, setDealContext] = useState<DealContext>('dating');
  const [candidates, setCandidates] = useState<Candidate[] | null>(null);
  const [lastSwiped, setLastSwiped] = useState<Candidate | null>(null);
  const [rewinding, setRewinding] = useState(false);
  const [detailProfile, setDetailProfile] = useState<Candidate | null>(null);
  const [boosting, setBoosting] = useState(false);
  const [filterOpen, setFilterOpen] = useState(false);
  const [filterCity, setFilterCity] = useState('');
  const [filterMinHeight, setFilterMinHeight] = useState('');
  const [filterMaxHeight, setFilterMaxHeight] = useState('');
  const [filterMinAge, setFilterMinAge] = useState('');
  const [filterMaxAge, setFilterMaxAge] = useState('');
  const [filterMaxDistance, setFilterMaxDistance] = useState('');
  const [filterVerifiedOnly, setFilterVerifiedOnly] = useState(false);
  const [filterInterests, setFilterInterests] = useState<string[]>([]);
  const emptyFilters = {
    city: '',
    minHeight: '',
    maxHeight: '',
    minAge: '',
    maxAge: '',
    maxDistance: '',
    verifiedOnly: false,
    interests: [] as string[],
  };
  const [appliedFilters, setAppliedFilters] = useState(emptyFilters);
  const activeFilterCount =
    (appliedFilters.city.trim() ? 1 : 0) +
    (appliedFilters.minHeight || appliedFilters.maxHeight ? 1 : 0) +
    (appliedFilters.minAge || appliedFilters.maxAge ? 1 : 0) +
    (appliedFilters.maxDistance ? 1 : 0) +
    (appliedFilters.verifiedOnly ? 1 : 0) +
    (appliedFilters.interests.length > 0 ? 1 : 0);
  const [myPhotoUrl, setMyPhotoUrl] = useState<string | null>(null);
  const [matchModal, setMatchModal] = useState<{ target: Candidate; matchId: string | null } | null>(
    null
  );

  const boostActive = !!profile?.boost_until && new Date(profile.boost_until) > new Date();

  useEffect(() => {
    if (!session) return;
    supabase
      .from('photos')
      .select('url')
      .eq('profile_id', session.user.id)
      .eq('is_main', true)
      .maybeSingle()
      .then(({ data }) => setMyPhotoUrl(data?.url ?? null));
  }, [session?.user.id]);

  const translateX = useSharedValue(0);
  const translateY = useSharedValue(0);
  const cardSize = useSharedValue({ width: 0, height: 0 });

  const loadCandidates = async () => {
    if (!session) return;
    setCandidates(null);
    setLastSwiped(null);
    const { data, error } = await supabase.rpc('nearby_candidates', {
      p_context: dealContext,
      p_is_business: dealContext === 'business',
    });
    if (error) {
      showAlert('Ошибка', error.message);
      setCandidates([]);
      return;
    }
    let list = (data ?? []) as Candidate[];
    if (appliedFilters.city.trim()) {
      const needle = appliedFilters.city.trim().toLowerCase();
      list = list.filter((c) => c.city?.toLowerCase().includes(needle));
    }
    const minH = parseInt(appliedFilters.minHeight, 10);
    if (!isNaN(minH)) list = list.filter((c) => c.height_cm >= minH);
    const maxH = parseInt(appliedFilters.maxHeight, 10);
    if (!isNaN(maxH)) list = list.filter((c) => c.height_cm <= maxH);
    const minA = parseInt(appliedFilters.minAge, 10);
    if (!isNaN(minA)) list = list.filter((c) => calcAge(c.birth_date) >= minA);
    const maxA = parseInt(appliedFilters.maxAge, 10);
    if (!isNaN(maxA)) list = list.filter((c) => calcAge(c.birth_date) <= maxA);
    const maxDist = parseInt(appliedFilters.maxDistance, 10);
    if (!isNaN(maxDist)) {
      list = list.filter((c) => c.distance_km == null || c.distance_km <= maxDist);
    }
    if (appliedFilters.verifiedOnly) {
      list = list.filter((c) => c.verification_status === 'verified');
    }
    if (appliedFilters.interests.length > 0) {
      list = list.filter((c) => c.interests?.some((i) => appliedFilters.interests.includes(i)));
    }
    setCandidates(list);
  };

  useEffect(() => {
    loadCandidates();
  }, [session?.user.id, dealContext, appliedFilters]);

  const activateBoost = async () => {
    if (!session || boosting) return;
    setBoosting(true);
    const boostUntil = new Date(Date.now() + 30 * 60 * 1000).toISOString();
    const { error } = await supabase
      .from('profiles')
      .update({ boost_until: boostUntil })
      .eq('id', session.user.id);
    setBoosting(false);
    if (error) {
      showAlert('Ошибка', error.message);
      return;
    }
    await refreshProfile();
    showAlert('Буст активирован 🚀', 'Ваша анкета будет показываться чаще следующие 30 минут');
  };

  const openFilters = () => {
    setFilterCity(appliedFilters.city);
    setFilterMinHeight(appliedFilters.minHeight);
    setFilterMaxHeight(appliedFilters.maxHeight);
    setFilterMinAge(appliedFilters.minAge);
    setFilterMaxAge(appliedFilters.maxAge);
    setFilterMaxDistance(appliedFilters.maxDistance);
    setFilterVerifiedOnly(appliedFilters.verifiedOnly);
    setFilterInterests(appliedFilters.interests);
    setFilterOpen(true);
  };

  const toggleInterest = (interest: string) => {
    setFilterInterests((prev) =>
      prev.includes(interest) ? prev.filter((i) => i !== interest) : [...prev, interest]
    );
  };

  const applyFilters = () => {
    setAppliedFilters({
      city: filterCity,
      minHeight: filterMinHeight,
      maxHeight: filterMaxHeight,
      minAge: filterMinAge,
      maxAge: filterMaxAge,
      maxDistance: filterMaxDistance,
      verifiedOnly: filterVerifiedOnly,
      interests: filterInterests,
    });
    setFilterOpen(false);
  };

  const resetFilters = () => {
    setFilterCity('');
    setFilterMinHeight('');
    setFilterMaxHeight('');
    setFilterMinAge('');
    setFilterMaxAge('');
    setFilterMaxDistance('');
    setFilterVerifiedOnly(false);
    setFilterInterests([]);
    setAppliedFilters(emptyFilters);
    setFilterOpen(false);
  };

  const recordSwipe = async (target: Candidate, action: SwipeAction) => {
    const { error } = await supabase.from('swipes').insert({
      actor_id: session!.user.id,
      target_id: target.id,
      action,
      context: dealContext,
    });

    if (error) {
      showAlert('Ошибка', error.message);
      return;
    }

    if (action === 'like' || action === 'superlike') {
      const { data: reciprocal } = await supabase
        .from('swipes')
        .select('id')
        .eq('actor_id', target.id)
        .eq('target_id', session!.user.id)
        .in('action', ['like', 'superlike'])
        .eq('context', dealContext)
        .maybeSingle();

      if (reciprocal) {
        const { data: matchRow } = await supabase
          .from('matches')
          .insert({
            user_a_id: session!.user.id,
            user_b_id: target.id,
            context: dealContext,
          })
          .select('id')
          .single();
        setMatchModal({ target, matchId: matchRow?.id ?? null });
      }
    }
  };

  const advanceCard = (action: SwipeAction) => {
    if (!candidates || candidates.length === 0) return;
    const target = candidates[0];
    setLastSwiped(target);
    setCandidates((prev) => (prev ? prev.slice(1) : prev));
    translateX.value = 0;
    translateY.value = 0;
    recordSwipe(target, action);
  };

  const rewind = async () => {
    if (!lastSwiped || !session || rewinding) return;
    setRewinding(true);
    const target = lastSwiped;
    setCandidates((prev) => (prev ? [target, ...prev] : [target]));
    setLastSwiped(null);
    translateX.value = 0;
    translateY.value = 0;
    await supabase
      .from('swipes')
      .delete()
      .eq('actor_id', session.user.id)
      .eq('target_id', target.id)
      .eq('context', dealContext);
    setRewinding(false);
  };

  const flyOut = (action: SwipeAction) => {
    if (action === 'superlike') {
      translateY.value = withTiming(-SCREEN_WIDTH * 1.4, { duration: 260 }, (finished) => {
        if (finished) runOnJS(advanceCard)(action);
      });
    } else {
      const dir = action === 'like' ? 1 : -1;
      translateX.value = withTiming(dir * SCREEN_WIDTH * 1.3, { duration: 260 }, (finished) => {
        if (finished) runOnJS(advanceCard)(action);
      });
    }
  };

  const openDetail = () => {
    if (candidates && candidates.length > 0) setDetailProfile(candidates[0]);
  };

  const panGesture = Gesture.Pan()
    .onUpdate((e) => {
      translateX.value = e.translationX;
      translateY.value = e.translationY * 0.15;
    })
    .onEnd((e) => {
      if (e.translationY > 90 && Math.abs(e.translationX) < 60) {
        translateX.value = withSpring(0);
        translateY.value = withSpring(0);
        runOnJS(openDetail)();
      } else if (e.translationX > SWIPE_THRESHOLD) {
        translateX.value = withTiming(SCREEN_WIDTH * 1.3, { duration: 220 }, (finished) => {
          if (finished) runOnJS(advanceCard)('like');
        });
      } else if (e.translationX < -SWIPE_THRESHOLD) {
        translateX.value = withTiming(-SCREEN_WIDTH * 1.3, { duration: 220 }, (finished) => {
          if (finished) runOnJS(advanceCard)('dislike');
        });
      } else {
        translateX.value = withSpring(0);
        translateY.value = withSpring(0);
      }
    });

  const tapGesture = Gesture.Tap()
    .maxDistance(10)
    .onEnd((e, success) => {
      if (!success) return;
      const { width, height } = cardSize.value;
      const nearSideEdge = e.x <= ARROW_TAP_ZONE_X || e.x >= width - ARROW_TAP_ZONE_X;
      const nearArrowHeight = Math.abs(e.y - height / 2) <= ARROW_TAP_ZONE_Y_HALF;
      if (nearSideEdge && nearArrowHeight) return;
      runOnJS(openDetail)();
    });

  const cardGesture = Gesture.Race(panGesture, tapGesture);

  const cardAnimatedStyle = useAnimatedStyle(() => {
    const rotate = interpolate(
      translateX.value,
      [-300, 0, 300],
      [-12, 0, 12],
      Extrapolation.CLAMP
    );
    return {
      transform: [
        { translateX: translateX.value },
        { translateY: translateY.value },
        { rotate: `${rotate}deg` },
      ],
    };
  });

  const nextCardStyle = useAnimatedStyle(() => {
    const dragDistance = Math.max(Math.abs(translateX.value), Math.abs(translateY.value));
    const scale = interpolate(dragDistance, [0, SWIPE_THRESHOLD], [0.94, 1], Extrapolation.CLAMP);
    const opacity = interpolate(dragDistance, [0, SWIPE_THRESHOLD], [0.75, 1], Extrapolation.CLAMP);
    return { transform: [{ scale }], opacity };
  });

  const likeBadgeStyle = useAnimatedStyle(() => ({
    opacity: interpolate(translateX.value, [10, SWIPE_THRESHOLD], [0, 1], Extrapolation.CLAMP),
  }));
  const nopeBadgeStyle = useAnimatedStyle(() => ({
    opacity: interpolate(translateX.value, [-10, -SWIPE_THRESHOLD], [0, 1], Extrapolation.CLAMP),
  }));

  const selectBusiness = () => {
    if (!profile?.is_business) {
      showAlert(
        'Нужен бизнес-профиль',
        'Добавьте компанию в профиле, чтобы пользоваться вкладкой для бизнеса'
      );
      router.push('/(tabs)/profile');
      return;
    }
    setDealContext('business');
  };

  const SegmentedControl = (
    <View style={[styles.segmentRow, { top: insets.top + 55 }]}>
      <Pressable
        style={[styles.segmentPill, dealContext === 'dating' && styles.segmentPillActive]}
        onPress={() => setDealContext('dating')}
      >
        <Text style={styles.segmentIcon}>💝</Text>
        <Text
          style={[styles.segmentPillText, dealContext === 'dating' && styles.segmentPillTextActive]}
        >
          Знакомства
        </Text>
      </Pressable>
      <Pressable
        style={[styles.segmentPill, dealContext === 'business' && styles.segmentPillActive]}
        onPress={selectBusiness}
      >
        <Text style={styles.segmentIcon}>🤝</Text>
        <Text
          style={[styles.segmentPillText, dealContext === 'business' && styles.segmentPillTextActive]}
        >
          Для бизнеса
        </Text>
      </Pressable>
    </View>
  );

  const Logo = (
    <View style={[styles.logoWrap, { top: insets.top + 10 }]} pointerEvents="none">
      <Text style={styles.logoText}>MEETCUTE</Text>
    </View>
  );

  const TopRightButtons = (
    <View style={[styles.topRightRow, { top: insets.top + 10 }]}>
      <Pressable
        style={[styles.topIconButton, activeFilterCount > 0 && styles.topIconButtonActive]}
        onPress={openFilters}
      >
        <MaterialIcons name="tune" size={18} color={activeFilterCount > 0 ? '#8B5CF6' : '#fff'} />
        {activeFilterCount > 0 && (
          <View style={styles.filterCountBadge}>
            <Text style={styles.filterCountBadgeText}>{activeFilterCount}</Text>
          </View>
        )}
      </Pressable>
      <Pressable
        style={[styles.topIconButton, boostActive && styles.topIconButtonActive]}
        onPress={activateBoost}
        disabled={boosting || boostActive}
      >
        <MaterialIcons
          name="visibility"
          size={18}
          color={boostActive ? '#8B5CF6' : '#fff'}
        />
      </Pressable>
    </View>
  );

  if (candidates === null) {
    return (
      <LinearGradient colors={['#0E0A0C', '#1A0A0D']} style={styles.screen}>
        <SubscriptionBadge />
        {Logo}
        {TopRightButtons}
        {SegmentedControl}
        <View style={styles.center}>
          <ActivityIndicator color="#fff" />
        </View>
      </LinearGradient>
    );
  }

  if (candidates.length === 0) {
    return (
      <View style={[styles.screen, { backgroundColor: BAR_BG }]}>
        <SubscriptionBadge />
        {Logo}
        {TopRightButtons}
        {SegmentedControl}
        <View style={styles.center}>
          <Text style={styles.emptyText}>Анкеты закончились</Text>
          <Pressable style={styles.refreshButton} onPress={loadCandidates}>
            <Text style={styles.refreshButtonText}>Обновить</Text>
          </Pressable>
        </View>
      </View>
    );
  }

  const current = candidates[0];
  const next = candidates[1];
  const nextPhoto = next ? mainPhotoOf(next) : null;

  return (
    <LinearGradient colors={['#0E0A0C', '#1A0A0D']} style={styles.screen}>
      {nextPhoto && (
        <Animated.View
          style={[styles.card, styles.nextCard, { top: insets.top + 100 }, nextCardStyle]}
        >
          <Image source={{ uri: nextPhoto.url }} style={styles.photo} />
        </Animated.View>
      )}

      <GestureDetector gesture={cardGesture}>
        <Animated.View
          style={[
            styles.card,
            { top: insets.top + 100 },
            cardAnimatedStyle,
          ]}
          onLayout={(e) => {
            const { width, height } = e.nativeEvent.layout;
            cardSize.value = { width, height };
          }}
        >
          <PhotoCarousel photos={current.photos} style={styles.photo} />

          <Animated.View style={[styles.badge, styles.likeBadge, likeBadgeStyle]}>
            <Text style={[styles.badgeText, styles.likeBadgeText]}>LIKE</Text>
          </Animated.View>
          <Animated.View style={[styles.badge, styles.nopeBadge, nopeBadgeStyle]}>
            <Text style={[styles.badgeText, styles.nopeBadgeText]}>NOPE</Text>
          </Animated.View>

          <View style={styles.swipeHint} pointerEvents="none">
            <View style={styles.swipeHintBar} />
          </View>

          <LinearGradient
            colors={['transparent', 'rgba(14,10,12,0.6)', BAR_BG, BAR_BG]}
            locations={[0, 0.35, 0.65, 1]}
            style={[
              styles.photoOverlay,
              { height: insets.bottom + 260, paddingBottom: insets.bottom + 172 },
            ]}
          >
            {current.is_premium && (
              <View style={styles.plusBadge}>
                <Text style={styles.plusBadgeText}>PLUS</Text>
              </View>
            )}
            <View style={styles.nameRow}>
              <View style={styles.nameRowLeft}>
                <Text style={styles.name}>
                  {current.display_name}, {calcAge(current.birth_date)}
                </Text>
                {current.verification_status === 'verified' && <VerifiedBadge size={18} />}
              </View>
              {current.distance_km != null && (
                <View style={styles.distancePill}>
                  <MaterialIcons name="location-on" size={13} color="#fff" />
                  <Text style={styles.distancePillText}>
                    {Math.round(current.distance_km)} км
                  </Text>
                </View>
              )}
            </View>
            {current.city ? <Text style={styles.cityText}>{current.city}</Text> : null}
            {(current.profession || current.height_cm) && (
              <View style={styles.metaRow}>
                {current.profession ? (
                  <View style={styles.professionTag}>
                    <Text style={styles.professionTagText}>{current.profession}</Text>
                  </View>
                ) : null}
                {current.height_cm ? (
                  <View style={styles.professionTag}>
                    <Text style={styles.professionTagText}>{current.height_cm} см</Text>
                  </View>
                ) : null}
              </View>
            )}
            {current.bio ? (
              <Text style={styles.bio} numberOfLines={2}>
                {current.bio}
              </Text>
            ) : null}
          </LinearGradient>
        </Animated.View>
      </GestureDetector>

      <SubscriptionBadge />
      {Logo}
      {TopRightButtons}
      {SegmentedControl}

      <View style={[styles.actions, { bottom: insets.bottom + 96 }]}>
        <Pressable
          style={[styles.actionButton, styles.rewindButton, !lastSwiped && styles.actionButtonDisabled]}
          onPress={rewind}
          disabled={!lastSwiped || rewinding}
        >
          <Text style={styles.rewindText}>↺</Text>
        </Pressable>
        <Pressable
          style={[styles.actionButton, styles.dislikeButton]}
          onPress={() => flyOut('dislike')}
        >
          <Text style={styles.dislikeText}>✕</Text>
        </Pressable>
        <Pressable
          style={[styles.actionButton, styles.likeButton]}
          onPress={() => flyOut('like')}
        >
          <Text style={styles.likeText}>❤</Text>
        </Pressable>
        <Pressable
          style={[styles.actionButton, styles.superlikeButton]}
          onPress={() => flyOut('superlike')}
        >
          <Text style={styles.superlikeText}>★</Text>
        </Pressable>
      </View>

      <ProfileDetailModal profile={detailProfile} onClose={() => setDetailProfile(null)} />

      <MatchModal
        visible={!!matchModal}
        myPhotoUrl={myPhotoUrl}
        otherPhotoUrl={matchModal ? mainPhotoOf(matchModal.target)?.url ?? null : null}
        otherName={matchModal?.target.display_name ?? ''}
        matchId={matchModal?.matchId ?? null}
        onClose={() => setMatchModal(null)}
      />

      <Modal
        visible={filterOpen}
        animationType="fade"
        transparent
        onRequestClose={() => setFilterOpen(false)}
      >
        <BlurView intensity={40} tint="dark" style={styles.filterBackdrop}>
          <Pressable style={StyleSheet.absoluteFillObject} onPress={() => setFilterOpen(false)} />
          <View style={styles.filterCard}>
            <View style={styles.filterHeader}>
              <Text style={styles.filterTitle}>Фильтры</Text>
              <Pressable style={styles.filterCloseButton} onPress={() => setFilterOpen(false)}>
                <MaterialIcons name="close" size={16} color="#fff" />
              </Pressable>
            </View>

            <ScrollView
              style={styles.filterScroll}
              showsVerticalScrollIndicator={false}
              keyboardShouldPersistTaps="handled"
            >
              <Text style={styles.filterLabel}>Город</Text>
              <TextInput
                style={styles.filterInput}
                placeholder="Например, Москва"
                placeholderTextColor="#6b6b70"
                value={filterCity}
                onChangeText={setFilterCity}
              />

              <Text style={styles.filterLabel}>Возраст</Text>
              <View style={styles.filterRow}>
                <TextInput
                  style={[styles.filterInput, styles.filterInputHalf]}
                  placeholder="От"
                  placeholderTextColor="#6b6b70"
                  keyboardType="number-pad"
                  value={filterMinAge}
                  onChangeText={setFilterMinAge}
                />
                <TextInput
                  style={[styles.filterInput, styles.filterInputHalf]}
                  placeholder="До"
                  placeholderTextColor="#6b6b70"
                  keyboardType="number-pad"
                  value={filterMaxAge}
                  onChangeText={setFilterMaxAge}
                />
              </View>

              <Text style={styles.filterLabel}>Рост, см</Text>
              <View style={styles.filterRow}>
                <TextInput
                  style={[styles.filterInput, styles.filterInputHalf]}
                  placeholder="От"
                  placeholderTextColor="#6b6b70"
                  keyboardType="number-pad"
                  value={filterMinHeight}
                  onChangeText={setFilterMinHeight}
                />
                <TextInput
                  style={[styles.filterInput, styles.filterInputHalf]}
                  placeholder="До"
                  placeholderTextColor="#6b6b70"
                  keyboardType="number-pad"
                  value={filterMaxHeight}
                  onChangeText={setFilterMaxHeight}
                />
              </View>

              <Text style={styles.filterLabel}>Расстояние, км</Text>
              <TextInput
                style={styles.filterInput}
                placeholder="Например, 30"
                placeholderTextColor="#6b6b70"
                keyboardType="number-pad"
                value={filterMaxDistance}
                onChangeText={setFilterMaxDistance}
              />

              <Pressable
                style={styles.filterToggleRow}
                onPress={() => setFilterVerifiedOnly((v) => !v)}
              >
                <View style={styles.filterToggleLabelWrap}>
                  <MaterialIcons name="verified" size={16} color="#8B5CF6" />
                  <Text style={styles.filterToggleLabel}>Только верифицированные</Text>
                </View>
                <View style={[styles.toggleTrack, filterVerifiedOnly && styles.toggleTrackActive]}>
                  <View style={[styles.toggleThumb, filterVerifiedOnly && styles.toggleThumbActive]} />
                </View>
              </Pressable>

              <Text style={styles.filterLabel}>Интересы</Text>
              <View style={styles.filterChipWrap}>
                {INTERESTS.map((interest) => {
                  const selected = filterInterests.includes(interest);
                  return (
                    <Pressable
                      key={interest}
                      style={[styles.filterChip, selected && styles.filterChipSelected]}
                      onPress={() => toggleInterest(interest)}
                    >
                      <Text
                        style={[styles.filterChipText, selected && styles.filterChipTextSelected]}
                      >
                        {interest}
                      </Text>
                    </Pressable>
                  );
                })}
              </View>
            </ScrollView>

            <View style={styles.filterActions}>
              <Pressable style={styles.filterResetButton} onPress={resetFilters}>
                <Text style={styles.filterResetText}>Сбросить</Text>
              </Pressable>
              <Pressable style={styles.filterApplyButtonWrap} onPress={applyFilters}>
                <LinearGradient
                  colors={['#A78BFA', '#8B5CF6']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={styles.filterApplyButton}
                >
                  <Text style={styles.filterApplyText}>Применить</Text>
                </LinearGradient>
              </Pressable>
            </View>
          </View>
        </BlurView>
      </Modal>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 16 },
  emptyText: { fontSize: 16, color: '#9a9aa0' },
  refreshButton: {
    backgroundColor: '#8B5CF6',
    borderRadius: 20,
    paddingVertical: 10,
    paddingHorizontal: 20,
  },
  refreshButtonText: { color: '#fff', fontWeight: '600' },

  segmentRow: {
    position: 'absolute',
    alignSelf: 'center',
    flexDirection: 'row',
    gap: 7,
    zIndex: 10,
  },
  segmentPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    borderRadius: 13,
    paddingVertical: 5,
    paddingHorizontal: 11,
  },
  segmentPillActive: {
    backgroundColor: 'rgba(139,92,246,0.35)',
    borderColor: '#8B5CF6',
  },
  segmentIcon: { fontSize: 9 },
  segmentPillText: { color: '#8a8a90', fontSize: 14, fontWeight: '600' },
  segmentPillTextActive: { color: '#fff' },

  logoWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    height: 36,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 9,
  },
  logoText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 1.5,
  },
  topRightRow: {
    position: 'absolute',
    right: 16,
    flexDirection: 'row',
    gap: 8,
    zIndex: 10,
  },
  topIconButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  topIconButtonActive: {
    backgroundColor: 'rgba(139,92,246,0.25)',
    borderColor: '#8B5CF6',
  },
  filterCountBadge: {
    position: 'absolute',
    top: -4,
    right: -4,
    minWidth: 17,
    height: 17,
    borderRadius: 9,
    backgroundColor: '#8B5CF6',
    borderWidth: 1.5,
    borderColor: BAR_BG,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 3,
  },
  filterCountBadgeText: { color: '#fff', fontSize: 10, fontWeight: '800' },

  filterBackdrop: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  filterCard: {
    width: '100%',
    maxHeight: '82%',
    backgroundColor: 'rgba(26,21,23,0.92)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    borderRadius: 28,
    padding: 20,
    shadowColor: '#8B5CF6',
    shadowOpacity: 0.25,
    shadowRadius: 30,
    shadowOffset: { width: 0, height: 10 },
    elevation: 12,
  },
  filterHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  filterTitle: { color: '#fff', fontSize: 18, fontWeight: '800' },
  filterCloseButton: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  filterScroll: { flexGrow: 0 },
  filterLabel: { color: '#9a9aa0', fontSize: 13, fontWeight: '600', marginTop: 14, marginBottom: 8 },
  filterInput: {
    width: '100%',
    backgroundColor: 'rgba(255,255,255,0.07)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    borderRadius: 14,
    padding: 14,
    fontSize: 16,
    color: '#fff',
  },
  filterRow: { flexDirection: 'row', gap: 10 },
  filterInputHalf: { flex: 1, minWidth: 0 },
  filterToggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: 'rgba(139,92,246,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.3)',
    borderRadius: 14,
    paddingVertical: 12,
    paddingHorizontal: 14,
    marginTop: 14,
  },
  filterToggleLabelWrap: { flexDirection: 'row', alignItems: 'center', gap: 8, flexShrink: 1 },
  filterToggleLabel: { color: '#fff', fontSize: 14, fontWeight: '600' },
  toggleTrack: {
    width: 42,
    height: 24,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.14)',
    padding: 3,
  },
  toggleTrackActive: { backgroundColor: '#8B5CF6' },
  toggleThumb: {
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: '#fff',
  },
  toggleThumbActive: { transform: [{ translateX: 18 }] },
  filterChipWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  filterChip: {
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 16,
    paddingVertical: 8,
    paddingHorizontal: 14,
  },
  filterChipSelected: { backgroundColor: '#8B5CF6', borderColor: '#8B5CF6' },
  filterChipText: { color: '#c9c9ce', fontSize: 13, fontWeight: '500' },
  filterChipTextSelected: { color: '#fff', fontWeight: '700' },
  filterActions: { flexDirection: 'row', gap: 10, marginTop: 16 },
  filterResetButton: {
    flex: 1,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    borderRadius: 14,
    paddingVertical: 12,
    alignItems: 'center',
  },
  filterResetText: { color: '#9a9aa0', fontWeight: '600' },
  filterApplyButtonWrap: {
    flex: 1,
    borderRadius: 14,
    overflow: 'hidden',
    shadowColor: '#8B5CF6',
    shadowOpacity: 0.5,
    shadowRadius: 12,
    shadowOffset: { width: 0, height: 4 },
    elevation: 6,
  },
  filterApplyButton: { paddingVertical: 12, alignItems: 'center' },
  filterApplyText: { color: '#fff', fontWeight: '700' },

  card: {
    position: 'absolute',
    left: 10,
    right: 10,
    bottom: 0,
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    zIndex: 2,
  },
  nextCard: {
    zIndex: 1,
  },
  photo: { width: '100%', height: '100%' },
  photoPlaceholder: { backgroundColor: '#241a1c' },
  photoOverlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 18,
    justifyContent: 'flex-end',
  },
  swipeHint: {
    position: 'absolute',
    top: 10,
    left: 0,
    right: 0,
    alignItems: 'center',
    zIndex: 4,
  },
  swipeHintBar: {
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(255,255,255,0.4)',
  },
  plusBadge: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(0,0,0,0.4)',
    borderRadius: 12,
    paddingVertical: 3,
    paddingHorizontal: 9,
    marginBottom: 8,
  },
  plusBadgeText: { color: '#fff', fontSize: 9, fontWeight: '600' },
  nameRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  nameRowLeft: { flexDirection: 'row', alignItems: 'center', gap: 6, flexShrink: 1 },
  name: { fontSize: 22, fontWeight: '800', color: '#fff' },
  cityText: { fontSize: 13, color: '#e0e0e5', fontWeight: '500', marginTop: 3 },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 6, flexWrap: 'wrap' },
  professionTag: {
    backgroundColor: '#8B5CF6',
    borderRadius: 12,
    paddingVertical: 3,
    paddingHorizontal: 12,
  },
  professionTagText: { color: '#fff', fontSize: 13, fontWeight: '500' },
  distancePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    backgroundColor: 'rgba(0,0,0,0.4)',
    borderRadius: 12,
    paddingVertical: 3,
    paddingHorizontal: 9,
    marginLeft: 8,
  },
  distancePillText: { color: '#fff', fontSize: 12, fontWeight: '600' },
  bio: { fontSize: 13, color: '#d0d0d5', marginTop: 6 },
  badge: {
    position: 'absolute',
    top: '50%',
    left: '50%',
    marginTop: -28,
    marginLeft: -70,
    width: 140,
    borderWidth: 3,
    borderRadius: 14,
    paddingVertical: 10,
    alignItems: 'center',
    zIndex: 5,
    backgroundColor: 'rgba(14,10,12,0.4)',
  },
  likeBadge: {
    borderColor: '#8B5CF6',
    transform: [{ rotate: '-18deg' }],
    shadowColor: '#8B5CF6',
    shadowOpacity: 0.9,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 0 },
    elevation: 14,
  },
  nopeBadge: {
    borderColor: '#EF476F',
    transform: [{ rotate: '18deg' }],
    shadowColor: '#EF476F',
    shadowOpacity: 0.9,
    shadowRadius: 18,
    shadowOffset: { width: 0, height: 0 },
    elevation: 14,
  },
  badgeText: { fontSize: 26, fontWeight: '900', letterSpacing: 1 },
  likeBadgeText: {
    color: '#8B5CF6',
    textShadowColor: '#8B5CF6',
    textShadowRadius: 14,
    textShadowOffset: { width: 0, height: 0 },
  },
  nopeBadgeText: {
    color: '#EF476F',
    textShadowColor: '#EF476F',
    textShadowRadius: 14,
    textShadowOffset: { width: 0, height: 0 },
  },
  actions: {
    position: 'absolute',
    left: 0,
    right: 0,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 20,
    zIndex: 10,
  },
  actionButton: {
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.18)',
  },
  actionButtonDisabled: { opacity: 0.35 },
  rewindButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  rewindText: { fontSize: 20, color: '#c9c9ce' },
  dislikeButton: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  likeButton: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 2,
    borderColor: '#8B5CF6',
    shadowColor: '#8B5CF6',
    shadowOpacity: 0.5,
    shadowRadius: 14,
    shadowOffset: { width: 0, height: 0 },
    elevation: 8,
  },
  superlikeButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  dislikeText: { fontSize: 24, color: '#EF476F' },
  likeText: { fontSize: 24, color: '#8B5CF6' },
  superlikeText: { fontSize: 20, color: '#c9c9ce' },
});
