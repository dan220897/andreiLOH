import { MaterialIcons } from '@expo/vector-icons';
import { decode } from 'base64-arraybuffer';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useCallback, useMemo, useState } from 'react';
import { useFocusEffect, useRouter } from 'expo-router';
import {
  ActivityIndicator,
  Image,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { Circle, Svg } from 'react-native-svg';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import Calendar from '../../components/Calendar';
import PhotoGrid, { GridPhoto } from '../../components/PhotoGrid';
import SubscriptionBadge from '../../components/SubscriptionBadge';
import VerifiedBadge from '../../components/VerifiedBadge';
import { showAlert } from '../../lib/alert';
import { useAuth } from '../../lib/auth-context';
import { findCompanyByInn } from '../../lib/dadata';
import { INTERESTS } from '../../lib/interests';
import { supabase } from '../../lib/supabase';
import { useSubscriptionStatus } from '../../lib/subscription';

const ACCENT = '#8B5CF6';

function CompletionRing({ percent, size }: { percent: number; size: number }) {
  const strokeWidth = 3;
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference * (1 - Math.min(100, Math.max(0, percent)) / 100);
  return (
    <Svg
      width={size}
      height={size}
      style={[styles.ringSvg, { transform: [{ rotate: '-90deg' }] }]}
    >
      <Circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        stroke="rgba(255,255,255,0.14)"
        strokeWidth={strokeWidth}
        fill="none"
      />
      <Circle
        cx={size / 2}
        cy={size / 2}
        r={radius}
        stroke={ACCENT}
        strokeWidth={strokeWidth}
        strokeDasharray={`${circumference} ${circumference}`}
        strokeDashoffset={offset}
        strokeLinecap="round"
        fill="none"
      />
    </Svg>
  );
}

const GENDERS = [
  { value: 'male', label: 'Мужчина' },
  { value: 'female', label: 'Женщина' },
  { value: 'other', label: 'Другое' },
];

const INTERESTED_IN = [
  { value: 'male', label: 'Мужчины' },
  { value: 'female', label: 'Женщины' },
  { value: 'all', label: 'Все' },
];

function calcAge(birthDate: string) {
  const diff = Date.now() - new Date(birthDate).getTime();
  return Math.floor(diff / (1000 * 60 * 60 * 24 * 365.25));
}

function interestedInGendersToValue(genders: string[] | undefined) {
  if (!genders || genders.length === 0) return null;
  if (genders.length >= 3) return 'all';
  if (genders.length === 1) return genders[0];
  return 'all';
}

type BusinessProfile = {
  company_name: string;
  inn: string;
  position: string | null;
  verification_status: string;
};

type PhotoRow = { id: string; url: string; position: number; is_main: boolean };

export default function Profile() {
  const { profile, session, refreshProfile } = useAuth();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [photoUrl, setPhotoUrl] = useState<string | null>(null);
  const [allPhotos, setAllPhotos] = useState<PhotoRow[]>([]);
  const [interestedInGender, setInterestedInGender] = useState<string[]>([]);
  const [businessProfile, setBusinessProfile] = useState<BusinessProfile | null>(null);

  const [companyModalOpen, setCompanyModalOpen] = useState(false);
  const [companyInn, setCompanyInn] = useState('');
  const [companyName, setCompanyName] = useState('');
  const [companyPosition, setCompanyPosition] = useState('');
  const [companyVerifying, setCompanyVerifying] = useState(false);
  const [companyVerifiedStatus, setCompanyVerifiedStatus] = useState<string | null>(null);
  const [savingCompany, setSavingCompany] = useState(false);

  const [editOpen, setEditOpen] = useState(false);
  const [editName, setEditName] = useState('');
  const [editBirthDate, setEditBirthDate] = useState(new Date());
  const [editGender, setEditGender] = useState<string | null>(null);
  const [editInterestedIn, setEditInterestedIn] = useState<string | null>(null);
  const [editHeight, setEditHeight] = useState('');
  const [editCity, setEditCity] = useState('');
  const [editProfession, setEditProfession] = useState('');
  const [editBio, setEditBio] = useState('');
  const [editInterests, setEditInterests] = useState<string[]>([]);
  const [editGridPhotos, setEditGridPhotos] = useState<(GridPhoto | null)[]>(Array(6).fill(null));
  const [saving, setSaving] = useState(false);

  const loadExtra = useCallback(async () => {
    if (!session) return;
    const [photosRes, prefRes, bizRes] = await Promise.all([
      supabase
        .from('photos')
        .select('id, url, position, is_main')
        .eq('profile_id', session.user.id)
        .order('position', { ascending: true }),
      supabase
        .from('preferences')
        .select('interested_in_gender')
        .eq('profile_id', session.user.id)
        .maybeSingle(),
      supabase
        .from('business_profiles')
        .select('company_name, inn, position, verification_status')
        .eq('profile_id', session.user.id)
        .maybeSingle(),
    ]);
    const list = photosRes.data ?? [];
    setAllPhotos(list);
    setPhotoUrl(list.find((p) => p.is_main)?.url ?? list[0]?.url ?? null);
    setInterestedInGender(prefRes.data?.interested_in_gender ?? []);
    setBusinessProfile(bizRes.data ?? null);
  }, [session?.user.id]);

  useFocusEffect(
    useCallback(() => {
      loadExtra();
    }, [loadExtra])
  );

  const openEdit = () => {
    if (!profile) return;
    setEditName(profile.display_name ?? '');
    setEditBirthDate(profile.birth_date ? new Date(profile.birth_date) : new Date());
    setEditGender(profile.gender ?? null);
    setEditInterestedIn(interestedInGendersToValue(interestedInGender));
    setEditHeight(String(profile.height_cm ?? ''));
    setEditCity(profile.city ?? '');
    setEditProfession(profile.profession ?? '');
    setEditBio(profile.bio ?? '');
    setEditInterests(profile.interests ?? []);
    const grid: (GridPhoto | null)[] = Array(6).fill(null);
    [...allPhotos]
      .sort((a, b) => a.position - b.position)
      .slice(0, 6)
      .forEach((p, i) => {
        grid[i] = { key: p.id, uri: p.url, existingId: p.id, verified: true };
      });
    setEditGridPhotos(grid);
    setEditOpen(true);
  };

  const toggleEditInterest = (value: string) => {
    setEditInterests((prev) =>
      prev.includes(value) ? prev.filter((i) => i !== value) : [...prev, value]
    );
  };

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    router.replace('/(auth)/welcome');
  };

  const saveEdit = async () => {
    if (!session) return;
    if (!editName.trim()) {
      showAlert('Введите имя');
      return;
    }
    if (!editGridPhotos[0]) {
      showAlert('Добавьте главное фото');
      return;
    }
    const heightNum = parseInt(editHeight, 10);
    if (isNaN(heightNum) || heightNum < 100 || heightNum > 250) {
      showAlert('Некорректный рост (100-250 см)');
      return;
    }
    setSaving(true);
    try {
      const keptIds = new Set(
        editGridPhotos.filter((p): p is GridPhoto => !!p && !!p.existingId).map((p) => p.existingId)
      );
      const removedIds = allPhotos.filter((p) => !keptIds.has(p.id)).map((p) => p.id);
      if (removedIds.length) {
        const { error: deleteError } = await supabase.from('photos').delete().in('id', removedIds);
        if (deleteError) throw deleteError;
      }

      for (let i = 0; i < editGridPhotos.length; i++) {
        const gp = editGridPhotos[i];
        if (!gp) continue;
        if (gp.base64) {
          const path = `${session.user.id}/photo-${i}.jpg`;
          const { error: uploadError } = await supabase.storage
            .from('photos')
            .upload(path, decode(gp.base64), { contentType: 'image/jpeg', upsert: true });
          if (uploadError) throw uploadError;
          const { data: publicUrl } = supabase.storage.from('photos').getPublicUrl(path);
          if (gp.existingId) {
            const { error } = await supabase
              .from('photos')
              .update({ url: publicUrl.publicUrl, position: i, is_main: i === 0 })
              .eq('id', gp.existingId);
            if (error) throw error;
          } else {
            const { error } = await supabase.from('photos').insert({
              profile_id: session.user.id,
              url: publicUrl.publicUrl,
              position: i,
              is_main: i === 0,
            });
            if (error) throw error;
          }
        } else if (gp.existingId) {
          const { error } = await supabase
            .from('photos')
            .update({ position: i, is_main: i === 0 })
            .eq('id', gp.existingId);
          if (error) throw error;
        }
      }

      const { error: profileError } = await supabase
        .from('profiles')
        .update({
          display_name: editName.trim(),
          birth_date: editBirthDate.toISOString().slice(0, 10),
          gender: editGender,
          height_cm: heightNum,
          city: editCity.trim() || null,
          profession: editProfession.trim() || null,
          bio: editBio.trim() || null,
          interests: editInterests,
        })
        .eq('id', session.user.id);
      if (profileError) throw profileError;

      const interestedInGenders =
        editInterestedIn === 'all' ? ['male', 'female', 'other'] : [editInterestedIn];
      const { error: prefError } = await supabase
        .from('preferences')
        .update({ interested_in_gender: interestedInGenders })
        .eq('profile_id', session.user.id);
      if (prefError) throw prefError;

      await refreshProfile();
      await loadExtra();
      setEditOpen(false);
    } catch (err: any) {
      showAlert('Ошибка', err.message);
    } finally {
      setSaving(false);
    }
  };

  const checkInn = async () => {
    if (!companyInn.trim()) {
      showAlert('Введите ИНН');
      return;
    }
    setCompanyVerifying(true);
    setCompanyVerifiedStatus(null);
    try {
      const result = await findCompanyByInn(companyInn.trim());
      if (!result) {
        showAlert('Не найдено', 'Компания с таким ИНН не найдена в реестре');
        return;
      }
      if (result.type !== 'LEGAL') {
        showAlert(
          'Нужен ИНН компании',
          'Этот ИНН принадлежит физлицу или ИП. Введите ИНН юридического лица.'
        );
        return;
      }
      setCompanyName(result.name);
      setCompanyVerifiedStatus(result.status);
    } catch (err: any) {
      showAlert('Ошибка проверки', err.message);
    } finally {
      setCompanyVerifying(false);
    }
  };

  const saveCompany = async () => {
    if (!session) return;
    if (!companyVerifiedStatus) {
      showAlert('Проверьте ИНН', 'Нажмите «Проверить ИНН» перед сохранением');
      return;
    }
    if (!companyPosition.trim()) {
      showAlert('Введите вашу должность');
      return;
    }
    setSavingCompany(true);
    try {
      const { error: businessError } = await supabase.from('business_profiles').insert({
        profile_id: session.user.id,
        company_name: companyName,
        inn: companyInn.trim(),
        position: companyPosition.trim(),
        verification_status: companyVerifiedStatus === 'ACTIVE' ? 'verified' : 'pending',
        verified_at: companyVerifiedStatus === 'ACTIVE' ? new Date().toISOString() : null,
      });
      if (businessError) throw businessError;

      const { error: profileError } = await supabase
        .from('profiles')
        .update({ is_business: true })
        .eq('id', session.user.id);
      if (profileError) throw profileError;

      await refreshProfile();
      await loadExtra();
      setCompanyModalOpen(false);
      setCompanyInn('');
      setCompanyName('');
      setCompanyPosition('');
      setCompanyVerifiedStatus(null);
      showAlert('Готово', 'Бизнес-профиль добавлен');
    } catch (err: any) {
      showAlert('Ошибка', err.message);
    } finally {
      setSavingCompany(false);
    }
  };

  const interestedLabel =
    INTERESTED_IN.find((o) => o.value === interestedInGendersToValue(interestedInGender))?.label ??
    '—';
  const genderLabel = GENDERS.find((g) => g.value === profile?.gender)?.label ?? '—';

  const subStatus = useSubscriptionStatus();

  const completion = useMemo(() => {
    if (!profile) return 0;
    const checks = [
      !!photoUrl,
      !!profile.bio,
      !!profile.city,
      !!profile.profession,
      (profile.interests?.length ?? 0) > 0,
      profile.verification_status === 'verified',
    ];
    return Math.round((checks.filter(Boolean).length / checks.length) * 100);
  }, [profile, photoUrl]);

  const boostActive = !!profile?.boost_until && new Date(profile.boost_until) > new Date();
  const boostMinutesLeft = boostActive
    ? Math.max(0, Math.round((new Date(profile!.boost_until!).getTime() - Date.now()) / 60000))
    : 0;

  return (
    <View style={[styles.screen, { backgroundColor: '#0E0A0C' }]}>
      <SubscriptionBadge />
      <ScrollView
        contentContainerStyle={[
          styles.container,
          { paddingTop: insets.top + 16, paddingBottom: 96 },
        ]}
      >
        <View style={styles.profileCard}>
          <View style={[styles.avatarWrap, { width: 92, height: 92 }]}>
            <CompletionRing percent={completion} size={92} />
            <View style={styles.avatarInner}>
              {photoUrl ? (
                <Image source={{ uri: photoUrl }} style={styles.avatarImg} />
              ) : (
                <View style={[styles.avatarImg, styles.avatarPlaceholder]} />
              )}
            </View>
            <View style={styles.completionBadge}>
              <Text style={styles.completionBadgeText}>{completion}%</Text>
            </View>
          </View>

          <View style={styles.profileCardBody}>
            <View style={styles.nameRow}>
              <Text style={styles.name} numberOfLines={1}>
                {profile?.display_name}
                {profile ? `, ${calcAge(profile.birth_date)}` : ''}
              </Text>
              {profile?.verification_status === 'verified' && <VerifiedBadge size={17} />}
            </View>
            {profile?.city ? (
              <View style={styles.cityRow}>
                <MaterialIcons name="place" size={13} color="#9a9aa0" />
                <Text style={styles.cityText}>{profile.city}</Text>
              </View>
            ) : null}
          </View>

          <Pressable style={styles.editIconButton} onPress={openEdit}>
            <MaterialIcons name="edit" size={16} color="#fff" />
          </Pressable>
        </View>

        {subStatus !== 'plus' && (
          <Pressable
            style={styles.premiumBannerWrap}
            onPress={() => showAlert('MeetCute Plus', 'Скоро будет доступно')}
          >
            <LinearGradient
              colors={['#A78BFA', '#8B5CF6', '#6D28D9']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.premiumBanner}
            >
              <View style={styles.premiumTextWrap}>
                <Text style={styles.premiumTitle}>MeetCute Plus</Text>
                <Text style={styles.premiumSubtitle}>
                  Больше лайков, буст анкеты и приоритет в ленте
                </Text>
              </View>
              <View style={styles.premiumArrowWrap}>
                <MaterialIcons name="north-east" size={18} color={ACCENT} />
              </View>
            </LinearGradient>
          </Pressable>
        )}

        <View style={styles.tileRow}>
          <Pressable style={styles.tile} onPress={() => router.push('/tonight')}>
            <View style={styles.tileIconWrap}>
              <Text style={styles.tileEmoji}>🌙</Text>
            </View>
            <Text style={styles.tileTitle}>Тунайт</Text>
            <Text style={styles.tileSubtitle} numberOfLines={1}>
              Свободен(на) сегодня
            </Text>
          </Pressable>
          <Pressable style={styles.tile} onPress={() => router.push('/(tabs)')}>
            <View style={styles.tileIconWrap}>
              <MaterialIcons name="bolt" size={20} color={boostActive ? '#FBBF24' : ACCENT} />
            </View>
            <Text style={styles.tileTitle}>Буст</Text>
            <Text style={styles.tileSubtitle} numberOfLines={1}>
              {boostActive ? `Активен · ${boostMinutesLeft} мин` : 'Показываться чаще'}
            </Text>
          </Pressable>
        </View>

        <View style={styles.infoCard}>
          <InfoRow label="Возраст" value={profile ? `${calcAge(profile.birth_date)} лет` : '—'} />
          <InfoRow label="Пол" value={genderLabel} />
          <InfoRow label="Рост" value={profile ? `${profile.height_cm} см` : '—'} />
          <InfoRow label="Город" value={profile?.city || '—'} />
          <InfoRow label="Профессия" value={profile?.profession || '—'} />
          <InfoRow label="Кого ищу" value={interestedLabel} />
          <InfoRow label="О себе" value={profile?.bio || '—'} />
          <InfoRow
            label="Интересы"
            value={profile?.interests?.length ? profile.interests.join(', ') : '—'}
            last
          />
        </View>

        {businessProfile && (
          <View style={styles.infoCard}>
            <Text style={styles.cardHeading}>Бизнес-профиль</Text>
            <InfoRow label="Компания" value={businessProfile.company_name} />
            <InfoRow label="ИНН" value={businessProfile.inn} />
            <InfoRow label="Должность" value={businessProfile.position || '—'} />
            <InfoRow
              label="Статус"
              value={businessProfile.verification_status === 'verified' ? 'Подтверждён' : 'На проверке'}
              last
            />
          </View>
        )}

        {!profile?.is_business && (
          <Pressable
            style={styles.addCompanyButtonWrap}
            onPress={() => setCompanyModalOpen(true)}
          >
            <View style={styles.addCompanyButton}>
              <Text style={styles.addCompanyButtonText}>+ Добавить компанию</Text>
            </View>
          </Pressable>
        )}

        <Pressable style={styles.signOutButtonWrap} onPress={handleSignOut}>
          <View style={styles.signOutButton}>
            <Text style={styles.signOutText}>Выйти</Text>
          </View>
        </Pressable>
      </ScrollView>

      <Modal
        visible={companyModalOpen}
        animationType="fade"
        transparent
        onRequestClose={() => setCompanyModalOpen(false)}
      >
        <View style={styles.modalBackdrop}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Данные компании</Text>
            <Text style={styles.modalSubtitle}>
              Проверим по ИНН, что компания реально существует
            </Text>

            <TextInput
              style={styles.input}
              placeholder="ИНН компании"
              placeholderTextColor="#6b6b70"
              keyboardType="number-pad"
              value={companyInn}
              onChangeText={(t) => {
                setCompanyInn(t);
                setCompanyVerifiedStatus(null);
              }}
            />
            <Pressable style={styles.secondaryButton} onPress={checkInn} disabled={companyVerifying}>
              {companyVerifying ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={styles.secondaryButtonText}>Проверить ИНН</Text>
              )}
            </Pressable>

            {companyVerifiedStatus && (
              <>
                <View style={styles.companyResultVerified}>
                  <Text style={styles.companyResultName}>{companyName}</Text>
                </View>
                <TextInput
                  style={styles.input}
                  placeholder="Ваша должность"
                  placeholderTextColor="#6b6b70"
                  value={companyPosition}
                  onChangeText={setCompanyPosition}
                />
              </>
            )}

            <View style={styles.modalActions}>
              <Pressable
                style={styles.modalCancelButton}
                onPress={() => setCompanyModalOpen(false)}
              >
                <Text style={styles.modalCancelText}>Отмена</Text>
              </Pressable>
              <Pressable
                style={styles.modalSaveButtonWrap}
                onPress={saveCompany}
                disabled={savingCompany}
              >
                <LinearGradient
                  colors={['#A78BFA', '#8B5CF6']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={styles.modalSaveButton}
                >
                  <Text style={styles.modalSaveText}>
                    {savingCompany ? 'Сохранение...' : 'Сохранить'}
                  </Text>
                </LinearGradient>
              </Pressable>
            </View>
          </View>
        </View>
      </Modal>

      <Modal
        visible={editOpen}
        animationType="slide"
        transparent
        onRequestClose={() => setEditOpen(false)}
      >
        <View style={styles.editBackdrop}>
          <BlurView intensity={60} tint="dark" style={styles.editSheet}>
            <View style={styles.editHeader}>
              <Text style={styles.editTitle}>Редактировать профиль</Text>
              <Pressable style={styles.editCloseButton} onPress={() => setEditOpen(false)}>
                <Text style={styles.editCloseText}>✕</Text>
              </Pressable>
            </View>
            <ScrollView contentContainerStyle={{ paddingBottom: 24 }}>
              <Text style={styles.fieldLabel}>Фотографии</Text>
              <PhotoGrid photos={editGridPhotos} onChange={setEditGridPhotos} />

              <Text style={[styles.fieldLabel, { marginTop: 16 }]}>Имя</Text>
              <TextInput style={styles.input} value={editName} onChangeText={setEditName} />

              <Text style={styles.fieldLabel}>Дата рождения</Text>
              <Calendar
                value={editBirthDate}
                onChange={setEditBirthDate}
                maximumDate={new Date()}
                minimumDate={new Date(1930, 0, 1)}
              />

              <Text style={styles.fieldLabel}>Пол</Text>
              <View style={styles.chipWrap}>
                {GENDERS.map((g) => (
                  <Pressable
                    key={g.value}
                    style={[styles.chip, editGender === g.value && styles.chipSelected]}
                    onPress={() => setEditGender(g.value)}
                  >
                    <Text
                      style={[styles.chipText, editGender === g.value && styles.chipTextSelected]}
                    >
                      {g.label}
                    </Text>
                  </Pressable>
                ))}
              </View>

              <Text style={styles.fieldLabel}>Кого ищу</Text>
              <View style={styles.chipWrap}>
                {INTERESTED_IN.map((o) => (
                  <Pressable
                    key={o.value}
                    style={[styles.chip, editInterestedIn === o.value && styles.chipSelected]}
                    onPress={() => setEditInterestedIn(o.value)}
                  >
                    <Text
                      style={[
                        styles.chipText,
                        editInterestedIn === o.value && styles.chipTextSelected,
                      ]}
                    >
                      {o.label}
                    </Text>
                  </Pressable>
                ))}
              </View>

              <Text style={styles.fieldLabel}>Рост, см</Text>
              <TextInput
                style={styles.input}
                keyboardType="number-pad"
                value={editHeight}
                onChangeText={setEditHeight}
              />

              <Text style={styles.fieldLabel}>Город</Text>
              <TextInput style={styles.input} value={editCity} onChangeText={setEditCity} />

              <Text style={styles.fieldLabel}>Профессия</Text>
              <TextInput
                style={styles.input}
                value={editProfession}
                onChangeText={setEditProfession}
              />

              <Text style={styles.fieldLabel}>О себе</Text>
              <TextInput
                style={[styles.input, styles.bioInput]}
                multiline
                value={editBio}
                onChangeText={setEditBio}
              />

              <Text style={styles.fieldLabel}>Интересы</Text>
              <View style={styles.chipWrap}>
                {INTERESTS.map((i) => (
                  <Pressable
                    key={i}
                    style={[styles.chip, editInterests.includes(i) && styles.chipSelected]}
                    onPress={() => toggleEditInterest(i)}
                  >
                    <Text
                      style={[
                        styles.chipText,
                        editInterests.includes(i) && styles.chipTextSelected,
                      ]}
                    >
                      {i}
                    </Text>
                  </Pressable>
                ))}
              </View>

              <Pressable style={styles.saveButtonWrap} onPress={saveEdit} disabled={saving}>
                <LinearGradient
                  colors={['#A78BFA', '#8B5CF6']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={styles.saveButton}
                >
                  <Text style={styles.saveButtonText}>
                    {saving ? 'Сохранение...' : 'Сохранить'}
                  </Text>
                </LinearGradient>
              </Pressable>
            </ScrollView>
          </BlurView>
        </View>
      </Modal>
    </View>
  );
}

function InfoRow({ label, value, last }: { label: string; value: string; last?: boolean }) {
  return (
    <View style={[rowStyles.row, last && rowStyles.rowLast]}>
      <Text style={rowStyles.label}>{label}</Text>
      <Text style={rowStyles.value}>{value}</Text>
    </View>
  );
}

const rowStyles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(255,255,255,0.1)',
  },
  rowLast: { borderBottomWidth: 0 },
  label: { color: '#9a9aa0', fontSize: 14 },
  value: { color: '#fff', fontSize: 14, fontWeight: '600', flexShrink: 1, textAlign: 'right' },
});

const BORDER = 'rgba(255,255,255,0.14)';

const styles = StyleSheet.create({
  screen: { flex: 1 },
  container: { padding: 20, gap: 8 },
  avatarPlaceholder: { backgroundColor: 'rgba(255,255,255,0.07)' },

  profileCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: BORDER,
    borderRadius: 22,
    padding: 14,
  },
  avatarWrap: { alignItems: 'center', justifyContent: 'center' },
  ringSvg: { position: 'absolute', top: 0, left: 0 },
  avatarInner: {
    width: '78%',
    height: '78%',
    borderRadius: 999,
    overflow: 'hidden',
  },
  avatarImg: { width: '100%', height: '100%' },
  completionBadge: {
    position: 'absolute',
    bottom: -4,
    alignSelf: 'center',
    backgroundColor: ACCENT,
    borderRadius: 10,
    paddingHorizontal: 7,
    paddingVertical: 2,
    borderWidth: 2,
    borderColor: '#0E0A0C',
  },
  completionBadgeText: { color: '#fff', fontSize: 10, fontWeight: '800' },
  profileCardBody: { flex: 1, minWidth: 0, gap: 4 },
  nameRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  name: { fontSize: 19, fontWeight: '800', color: '#fff', flexShrink: 1 },
  cityRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  cityText: { color: '#9a9aa0', fontSize: 13, fontWeight: '500' },
  editIconButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(139,92,246,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.5)',
    alignItems: 'center',
    justifyContent: 'center',
  },

  premiumBannerWrap: { marginTop: 14, borderRadius: 20, overflow: 'hidden' },
  premiumBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 16,
  },
  premiumTextWrap: { flex: 1 },
  premiumTitle: { color: '#fff', fontSize: 16, fontWeight: '800' },
  premiumSubtitle: { color: 'rgba(255,255,255,0.85)', fontSize: 12, marginTop: 3, lineHeight: 16 },
  premiumArrowWrap: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },

  tileRow: { flexDirection: 'row', gap: 12, marginTop: 14 },
  tile: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: BORDER,
    borderRadius: 20,
    padding: 14,
    gap: 8,
  },
  tileIconWrap: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: 'rgba(139,92,246,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  tileEmoji: { fontSize: 16 },
  tileTitle: { color: '#fff', fontSize: 14, fontWeight: '700' },
  tileSubtitle: { color: '#9a9aa0', fontSize: 11, fontWeight: '500' },

  infoCard: {
    width: '100%',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: BORDER,
    borderRadius: 20,
    padding: 16,
    marginTop: 20,
  },
  cardHeading: { color: '#fff', fontSize: 15, fontWeight: '800', marginBottom: 4 },
  addCompanyButtonWrap: { marginTop: 20, borderRadius: 20, overflow: 'hidden' },
  addCompanyButton: {
    borderWidth: 1,
    borderColor: BORDER,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 20,
    paddingVertical: 12,
    paddingHorizontal: 24,
  },
  addCompanyButtonText: { color: '#fff', fontWeight: '600' },
  signOutButtonWrap: { marginTop: 16, borderRadius: 20, overflow: 'hidden' },
  signOutButton: {
    borderWidth: 1,
    borderColor: BORDER,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 20,
    paddingVertical: 12,
    paddingHorizontal: 24,
  },
  signOutText: { color: '#EF476F', fontWeight: '600' },

  modalBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.65)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  modalCard: {
    width: '100%',
    backgroundColor: '#1A1517',
    borderWidth: 1,
    borderColor: BORDER,
    borderRadius: 24,
    padding: 20,
    gap: 10,
  },
  modalTitle: { color: '#fff', fontSize: 18, fontWeight: '800', textAlign: 'center' },
  modalSubtitle: { color: '#9a9aa0', fontSize: 13, textAlign: 'center', marginBottom: 8 },
  input: {
    backgroundColor: 'rgba(255,255,255,0.07)',
    borderWidth: 1,
    borderColor: BORDER,
    borderRadius: 14,
    padding: 14,
    fontSize: 16,
    color: '#fff',
    marginBottom: 12,
  },
  bioInput: { minHeight: 90, textAlignVertical: 'top' },
  secondaryButton: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1,
    borderColor: BORDER,
    borderRadius: 14,
    paddingVertical: 12,
    alignItems: 'center',
  },
  secondaryButtonText: { color: '#fff', fontSize: 14, fontWeight: '600' },
  companyResultVerified: {
    backgroundColor: 'rgba(46,204,113,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(46,204,113,0.5)',
    borderRadius: 14,
    padding: 12,
    marginTop: 10,
    marginBottom: 10,
  },
  companyResultName: { color: '#2ecc71', fontSize: 14, fontWeight: '700' },
  modalActions: { flexDirection: 'row', gap: 10, marginTop: 6 },
  modalCancelButton: {
    flex: 1,
    borderWidth: 1,
    borderColor: BORDER,
    borderRadius: 14,
    paddingVertical: 12,
    alignItems: 'center',
  },
  modalCancelText: { color: '#9a9aa0', fontWeight: '600' },
  modalSaveButtonWrap: { flex: 1, borderRadius: 14, overflow: 'hidden' },
  modalSaveButton: { paddingVertical: 12, alignItems: 'center' },
  modalSaveText: { color: '#fff', fontWeight: '700' },

  editBackdrop: { flex: 1, justifyContent: 'flex-end' },
  editSheet: {
    maxHeight: '90%',
    backgroundColor: 'rgba(20,18,20,0.9)',
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    borderWidth: 1,
    borderColor: BORDER,
    padding: 20,
  },
  editHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginBottom: 16 },
  editTitle: { color: '#fff', fontSize: 18, fontWeight: '800' },
  editCloseButton: {
    position: 'absolute',
    right: 0,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  editCloseText: { color: '#fff', fontSize: 14, fontWeight: '700' },
  fieldLabel: { color: '#9a9aa0', fontSize: 13, fontWeight: '600', marginBottom: 6, marginTop: 4 },
  chipWrap: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 12 },
  chip: {
    borderWidth: 1,
    borderColor: BORDER,
    backgroundColor: 'rgba(255,255,255,0.07)',
    borderRadius: 18,
    paddingVertical: 8,
    paddingHorizontal: 16,
  },
  chipSelected: { backgroundColor: '#8B5CF6', borderColor: '#8B5CF6' },
  chipText: { color: '#c9c9ce', fontSize: 14 },
  chipTextSelected: { color: '#fff', fontWeight: '600' },
  saveButtonWrap: { borderRadius: 20, overflow: 'hidden', marginTop: 12 },
  saveButton: { paddingVertical: 15, alignItems: 'center' },
  saveButtonText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});
