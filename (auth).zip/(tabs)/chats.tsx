import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useFocusEffect, useRouter } from 'expo-router';
import { useCallback, useMemo, useState } from 'react';
import {
  ActivityIndicator,
  FlatList,
  Image,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import SubscriptionBadge from '../../components/SubscriptionBadge';
import { useAuth } from '../../lib/auth-context';
import { supabase } from '../../lib/supabase';

const ONLINE_THRESHOLD_MS = 5 * 60 * 1000;

type OtherProfile = {
  id: string;
  display_name: string;
  last_active_at: string;
  photos: { url: string; is_main: boolean }[];
};

type LastMessage = {
  content: string | null;
  sender_id: string;
  created_at: string;
  read_at: string | null;
};

type MatchRow = {
  id: string;
  other: OtherProfile;
  lastMessage: LastMessage | null;
  unread: boolean;
};

function isOnline(lastActiveAt: string) {
  return Date.now() - new Date(lastActiveAt).getTime() < ONLINE_THRESHOLD_MS;
}

function formatLastSeen(lastActiveAt: string) {
  if (isOnline(lastActiveAt)) return 'В сети';
  const diffMs = Date.now() - new Date(lastActiveAt).getTime();
  const minutes = Math.floor(diffMs / 60000);
  if (minutes < 60) return `Был(а) ${minutes} мин назад`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `Был(а) ${hours} ч назад`;
  const days = Math.floor(hours / 24);
  if (days === 1) return 'Был(а) вчера';
  if (days < 7) return `Был(а) ${days} дн назад`;
  return 'Давно не был(а) в сети';
}

function formatMessageTime(createdAt: string) {
  const date = new Date(createdAt);
  const now = new Date();
  const sameDay = date.toDateString() === now.toDateString();
  if (sameDay) {
    return date.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
  }
  const yesterday = new Date(now);
  yesterday.setDate(now.getDate() - 1);
  if (date.toDateString() === yesterday.toDateString()) return 'Вчера';
  const diffDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
  if (diffDays < 7) {
    return date.toLocaleDateString('ru-RU', { weekday: 'short' });
  }
  return date.toLocaleDateString('ru-RU', { day: '2-digit', month: '2-digit' });
}

export default function Chats() {
  const { session } = useAuth();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [matches, setMatches] = useState<MatchRow[] | null>(null);

  const load = useCallback(async () => {
    if (!session) return;
    const { data, error } = await supabase
      .from('matches')
      .select(
        'id, user_a_id, user_b_id, user_a:profiles!matches_user_a_id_fkey(id, display_name, last_active_at, photos(url, is_main)), user_b:profiles!matches_user_b_id_fkey(id, display_name, last_active_at, photos(url, is_main))'
      )
      .eq('context', 'dating')
      .eq('status', 'active')
      .or(`user_a_id.eq.${session.user.id},user_b_id.eq.${session.user.id}`);

    if (error) {
      console.error(error);
      setMatches([]);
      return;
    }

    const matchIds = (data ?? []).map((m: any) => m.id);
    const { data: msgData } = matchIds.length
      ? await supabase
          .from('messages')
          .select('match_id, content, sender_id, created_at, read_at')
          .in('match_id', matchIds)
          .order('created_at', { ascending: false })
      : { data: [] as any[] };

    const lastByMatch = new Map<string, LastMessage & { match_id: string }>();
    for (const msg of msgData ?? []) {
      if (!lastByMatch.has(msg.match_id)) lastByMatch.set(msg.match_id, msg);
    }

    const rows: MatchRow[] = (data ?? []).map((m: any) => {
      const last = lastByMatch.get(m.id) ?? null;
      return {
        id: m.id,
        other: m.user_a_id === session.user.id ? m.user_b : m.user_a,
        lastMessage: last,
        unread: !!last && last.sender_id !== session.user.id && !last.read_at,
      };
    });

    rows.sort((a, b) => {
      const at = a.lastMessage ? new Date(a.lastMessage.created_at).getTime() : 0;
      const bt = b.lastMessage ? new Date(b.lastMessage.created_at).getTime() : 0;
      return bt - at;
    });

    setMatches(rows);
  }, [session?.user.id]);

  useFocusEffect(
    useCallback(() => {
      load();
    }, [load])
  );

  const { newMatches, conversations } = useMemo(() => {
    const all = matches ?? [];
    return {
      newMatches: all.filter((m) => !m.lastMessage),
      conversations: all.filter((m) => m.lastMessage),
    };
  }, [matches]);

  if (matches === null) {
    return (
      <View style={[styles.screen, { backgroundColor: '#0E0A0C' }]}>
        <SubscriptionBadge />
        <View style={styles.center}>
          <ActivityIndicator color="#fff" />
        </View>
      </View>
    );
  }

  if (matches.length === 0) {
    return (
      <View style={[styles.screen, { backgroundColor: '#0E0A0C' }]}>
        <SubscriptionBadge />
        <View style={styles.center}>
          <Text style={styles.emptyEmoji}>💬</Text>
          <Text style={styles.emptyText}>Пока нет мэтчей</Text>
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.screen, { backgroundColor: '#0E0A0C' }]}>
      <LinearGradient
        colors={['#241338', '#150C24', '#0E0A0C']}
        style={styles.topGlow}
        pointerEvents="none"
      />
      <SubscriptionBadge />
      <FlatList
        data={conversations}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{
          padding: 12,
          paddingTop: insets.top + 64,
          paddingBottom: 96,
        }}
        ListHeaderComponent={
          <>
            {newMatches.length > 0 && (
              <View style={styles.newMatchesSection}>
                <Text style={styles.bigSectionTitle}>Мэтчи</Text>
                <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                  {newMatches.map((item) => {
                    const photo =
                      item.other.photos?.find((p) => p.is_main) ?? item.other.photos?.[0];
                    return (
                      <Pressable
                        key={item.id}
                        style={styles.newMatchItem}
                        onPress={() =>
                          router.push({ pathname: '/chat/[id]', params: { id: item.id } })
                        }
                      >
                        <View style={styles.newMatchAvatarWrap}>
                          {photo ? (
                            <Image source={{ uri: photo.url }} style={styles.newMatchAvatar} />
                          ) : (
                            <View style={[styles.newMatchAvatar, styles.avatarPlaceholder]} />
                          )}
                          {isOnline(item.other.last_active_at) && <View style={styles.onlineDot} />}
                        </View>
                        <Text style={styles.newMatchName} numberOfLines={1}>
                          {item.other.display_name}
                        </Text>
                      </Pressable>
                    );
                  })}
                </ScrollView>
              </View>
            )}
            {conversations.length > 0 && (
              <Text style={styles.bigSectionTitle}>Сообщения</Text>
            )}
          </>
        }
        renderItem={({ item }) => {
          const photo = item.other.photos?.find((p) => p.is_main) ?? item.other.photos?.[0];
          const mine = item.lastMessage?.sender_id === session?.user.id;
          const preview = item.lastMessage?.content ?? '';
          return (
            <Pressable
              onPress={() => router.push({ pathname: '/chat/[id]', params: { id: item.id } })}
            >
              <BlurView
                intensity={30}
                tint="dark"
                style={[styles.row, item.unread && styles.rowUnread]}
              >
                <View style={styles.avatarWrap}>
                  {photo ? (
                    <Image source={{ uri: photo.url }} style={styles.avatar} />
                  ) : (
                    <View style={[styles.avatar, styles.avatarPlaceholder]} />
                  )}
                  {isOnline(item.other.last_active_at) && <View style={styles.onlineDot} />}
                </View>
                <View style={styles.rowBody}>
                  <View style={styles.rowTopLine}>
                    <Text
                      style={[styles.name, item.unread && styles.nameUnread]}
                      numberOfLines={1}
                    >
                      {item.other.display_name}
                    </Text>
                    {item.lastMessage && (
                      <Text style={[styles.time, item.unread && styles.timeUnread]}>
                        {formatMessageTime(item.lastMessage.created_at)}
                      </Text>
                    )}
                  </View>
                  <View style={styles.rowBottomLine}>
                    <Text
                      style={[styles.preview, item.unread && styles.previewUnread]}
                      numberOfLines={1}
                      ellipsizeMode="tail"
                    >
                      {mine ? `Вы: ${preview}` : preview}
                    </Text>
                    {item.unread && <View style={styles.unreadDot} />}
                  </View>
                  <Text style={styles.lastSeen}>{formatLastSeen(item.other.last_active_at)}</Text>
                </View>
              </BlurView>
            </Pressable>
          );
        }}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  topGlow: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 260,
  },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 8 },
  emptyEmoji: { fontSize: 40 },
  emptyText: { color: '#9a9aa0', fontSize: 16 },
  bigSectionTitle: {
    color: '#fff',
    fontSize: 19,
    fontWeight: '800',
    marginBottom: 12,
    marginTop: 4,
  },
  newMatchesSection: { marginBottom: 26 },
  newMatchItem: { alignItems: 'center', width: 72, marginRight: 12 },
  newMatchAvatarWrap: { position: 'relative' },
  newMatchAvatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
    borderWidth: 2,
    borderColor: '#8B5CF6',
  },
  newMatchName: { color: '#fff', fontSize: 12, marginTop: 6, maxWidth: 68 },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 14,
    marginBottom: 10,
    borderRadius: 20,
    overflow: 'hidden',
    backgroundColor: 'rgba(139,92,246,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  rowUnread: {
    backgroundColor: 'rgba(139,92,246,0.16)',
    borderColor: 'rgba(139,92,246,0.45)',
  },
  avatarWrap: { position: 'relative' },
  avatar: {
    width: 54,
    height: 54,
    borderRadius: 27,
    borderWidth: 2,
    borderColor: 'rgba(139,92,246,0.5)',
  },
  avatarPlaceholder: { backgroundColor: 'rgba(255,255,255,0.08)' },
  onlineDot: {
    position: 'absolute',
    right: 0,
    bottom: 0,
    width: 13,
    height: 13,
    borderRadius: 7,
    backgroundColor: '#2ecc71',
    borderWidth: 2,
    borderColor: '#1A0A0D',
  },
  rowBody: { flex: 1, minWidth: 0 },
  rowTopLine: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  name: { fontSize: 16, fontWeight: '600', color: '#fff', flexShrink: 1 },
  nameUnread: { fontWeight: '800' },
  time: { fontSize: 12, color: '#9a9aa0', marginLeft: 8 },
  timeUnread: { color: '#A78BFA', fontWeight: '700' },
  rowBottomLine: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 3 },
  preview: { fontSize: 13, color: '#9a9aa0', flex: 1 },
  previewUnread: { color: '#e8e8ea', fontWeight: '600' },
  unreadDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: '#8B5CF6' },
  lastSeen: { fontSize: 11, color: '#6b6b70', marginTop: 3 },
});
