import { MaterialIcons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { StyleSheet, Text, View } from 'react-native';
import SubscriptionBadge from '../../components/SubscriptionBadge';

export default function Business() {
  return (
    <LinearGradient colors={['#0E0A0C', '#1A0A0D']} style={styles.screen}>
      <SubscriptionBadge />
      <View style={styles.center}>
        <View style={styles.iconWrap}>
          <MaterialIcons name="business-center" size={30} color="#8B5CF6" />
        </View>
        <Text style={styles.title}>Нетворкинг — скоро</Text>
        <Text style={styles.subtitle}>Деловые знакомства и общение с бизнесом рядом с вами</Text>
      </View>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 8, padding: 24 },
  iconWrap: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(139,92,246,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.3)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
  },
  title: { color: '#fff', fontSize: 18, fontWeight: '700' },
  subtitle: { color: '#9a9aa0', fontSize: 14, textAlign: 'center' },
});
