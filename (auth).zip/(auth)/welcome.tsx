import { FontAwesome5 } from '@expo/vector-icons';
import { BlurView } from 'expo-blur';
import { useRouter } from 'expo-router';
import { useState } from 'react';
import {
  Alert,
  FlatList,
  KeyboardAvoidingView,
  Modal,
  Platform,
  Pressable,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import AuthBackground from '../../components/AuthBackground';
import { COUNTRIES, Country } from '../../lib/countries';
import { supabase } from '../../lib/supabase';

type Method = 'email' | 'phone';

export default function Welcome() {
  const router = useRouter();
  const [method, setMethod] = useState<Method>('phone');
  const [email, setEmail] = useState('');
  const [country, setCountry] = useState<Country>(COUNTRIES[0]);
  const [localDigits, setLocalDigits] = useState('');
  const [countryPickerOpen, setCountryPickerOpen] = useState(false);
  const [countrySearch, setCountrySearch] = useState('');
  const [sending, setSending] = useState(false);

  const e164Phone = country.dial + localDigits;
  const filteredCountries = COUNTRIES.filter(
    (c) =>
      c.name.toLowerCase().includes(countrySearch.toLowerCase()) ||
      c.dial.includes(countrySearch)
  );

  const sendEmailCode = async () => {
    if (!email.includes('@')) {
      Alert.alert('Введите корректный email');
      return;
    }
    setSending(true);
    const { error } = await supabase.auth.signInWithOtp({ email });
    setSending(false);
    if (error) {
      Alert.alert('Ошибка', error.message);
      return;
    }
    router.push({ pathname: '/(auth)/verify', params: { email } });
  };

  const sendPhoneCode = async () => {
    if (localDigits.length < 6) {
      Alert.alert('Введите корректный номер телефона');
      return;
    }
    setSending(true);
    const { error } = await supabase.auth.signInWithOtp({ phone: e164Phone });
    setSending(false);
    if (error) {
      Alert.alert('Ошибка', error.message);
      return;
    }
    router.push({ pathname: '/(auth)/verify', params: { phone: e164Phone } });
  };

  const comingSoon = (provider: string) => Alert.alert(provider, 'Скоро будет доступно');
  const submit = method === 'phone' ? sendPhoneCode : sendEmailCode;

  return (
    <View style={styles.screen}>
      <AuthBackground />
      <StatusBar barStyle="light-content" />
      <KeyboardAvoidingView
        style={[styles.flex, styles.foreground]}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
      <ScrollView
        contentContainerStyle={styles.scrollContent}
        keyboardShouldPersistTaps="handled"
      >
      <View style={styles.header}>
        <Text style={styles.wordmark}>MEETCUTE</Text>
        <Text style={styles.subtitle}>Свайпай на свидания, а не только на лица</Text>
      </View>

      <View style={styles.card}>
        <Pressable style={styles.appleButton} onPress={() => comingSoon('Apple')}>
          <FontAwesome5 name="apple" size={18} color="#000" style={styles.glassIcon} />
          <Text style={styles.appleButtonText}>Войти через Apple</Text>
        </Pressable>
        <GlassButton icon="google" label="Войти через Google" onPress={() => comingSoon('Google')} />
        <Pressable style={styles.vkButton} onPress={() => comingSoon('VK')}>
          <FontAwesome5 name="vk" size={18} color="#fff" style={styles.glassIcon} />
          <Text style={styles.vkButtonText}>Войти через VK</Text>
        </Pressable>

        <View style={styles.dividerRow}>
          <View style={styles.dividerLine} />
          <Text style={styles.dividerText}>
            или по {method === 'phone' ? 'телефону' : 'email'}
          </Text>
          <View style={styles.dividerLine} />
        </View>

        <View style={styles.methodSwitch}>
          <Pressable
            style={[styles.methodTab, method === 'phone' && styles.methodTabActive]}
            onPress={() => setMethod('phone')}
          >
            <Text style={[styles.methodTabText, method === 'phone' && styles.methodTabTextActive]}>
              Телефон
            </Text>
          </Pressable>
          <Pressable
            style={[styles.methodTab, method === 'email' && styles.methodTabActive]}
            onPress={() => setMethod('email')}
          >
            <Text style={[styles.methodTabText, method === 'email' && styles.methodTabTextActive]}>
              Email
            </Text>
          </Pressable>
        </View>

        {method === 'phone' ? (
          <View style={styles.phoneRow}>
            <Pressable
              style={styles.countryPicker}
              onPress={() => setCountryPickerOpen(true)}
            >
              <Text style={styles.countryFlag}>{country.flag}</Text>
              <Text style={styles.countryDial}>{country.dial}</Text>
            </Pressable>
            <TextInput
              style={[styles.input, styles.phoneNumberInput]}
              placeholder="900 000 00 00"
              placeholderTextColor="#6b6b70"
              keyboardType="phone-pad"
              value={localDigits}
              onChangeText={(t) => setLocalDigits(t.replace(/\D/g, '').slice(0, 12))}
            />
          </View>
        ) : (
          <TextInput
            style={styles.input}
            placeholder="Email"
            placeholderTextColor="#6b6b70"
            autoCapitalize="none"
            keyboardType="email-address"
            value={email}
            onChangeText={setEmail}
          />
        )}

        {method === 'phone' && (
          <Text style={styles.hint}>
            Для теста: страна 🇺🇸 +1, номер 0000000001…0000000005, код 111111
          </Text>
        )}

        <Pressable style={styles.ctaButtonWrap} onPress={submit} disabled={sending}>
          <BlurView intensity={50} tint="dark" style={styles.ctaButton}>
            <Text style={styles.ctaButtonText}>{sending ? 'Отправка...' : 'Продолжить'}</Text>
          </BlurView>
        </Pressable>
      </View>

      <Text style={styles.footnote}>
        Вам должно быть 18+ лет.{'\n'}Продолжая, вы соглашаетесь с условиями использования.
      </Text>
      </ScrollView>
      </KeyboardAvoidingView>

      <Modal
        visible={countryPickerOpen}
        animationType="fade"
        transparent
        onRequestClose={() => setCountryPickerOpen(false)}
      >
        <BlurView intensity={60} tint="dark" style={styles.modalSheet}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Выберите страну</Text>
            <Pressable
              style={styles.modalCloseButton}
              onPress={() => setCountryPickerOpen(false)}
            >
              <Text style={styles.modalCloseButtonText}>✕</Text>
            </Pressable>
          </View>
          <TextInput
            style={styles.modalSearchInput}
            placeholder="Поиск страны"
            placeholderTextColor="#6b6b70"
            value={countrySearch}
            onChangeText={setCountrySearch}
          />
          <FlatList
            data={filteredCountries}
            keyExtractor={(item) => item.code}
            showsVerticalScrollIndicator={false}
            renderItem={({ item }) => (
              <Pressable
                style={styles.countryRow}
                onPress={() => {
                  setCountry(item);
                  setCountryPickerOpen(false);
                  setCountrySearch('');
                }}
              >
                <Text style={styles.countryFlag}>{item.flag}</Text>
                <Text style={styles.countryRowName}>{item.name}</Text>
                <Text style={styles.countryRowDial}>{item.dial}</Text>
              </Pressable>
            )}
          />
        </BlurView>
      </Modal>
    </View>
  );
}

function GlassButton({
  icon,
  label,
  onPress,
}: {
  icon: 'apple' | 'google' | 'vk';
  label: string;
  onPress: () => void;
}) {
  return (
    <Pressable style={styles.glassButtonWrap} onPress={onPress}>
      <BlurView intensity={40} tint="dark" style={styles.glassButton}>
        <FontAwesome5 name={icon} size={18} color="#fff" style={styles.glassIcon} />
        <Text style={styles.glassButtonText}>{label}</Text>
      </BlurView>
    </Pressable>
  );
}

const BORDER = 'rgba(255,255,255,0.14)';

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#0E0A0C',
    ...Platform.select({ web: { height: '100vh' as any } }),
  },
  flex: { flex: 1 },
  foreground: {},
  scrollContent: {
    flexGrow: 1,
    padding: 24,
    justifyContent: 'center',
  },
  header: { alignItems: 'center', marginBottom: 28 },
  wordmark: {
    fontSize: 34,
    fontWeight: '900',
    color: '#fff',
    letterSpacing: 2,
    textAlign: 'center',
    marginBottom: 8,
    textShadowColor: 'rgba(139,92,246,0.7)',
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 20,
  },
  subtitle: {
    fontSize: 11,
    color: '#fff',
    textAlign: 'center',
    paddingHorizontal: 20,
  },
  appleButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#fff',
    borderRadius: 26,
    paddingVertical: 14,
  },
  appleButtonText: { fontSize: 16, fontWeight: '600', color: '#000' },
  vkButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#0077FF',
    borderRadius: 26,
    paddingVertical: 14,
  },
  vkButtonText: { fontSize: 16, fontWeight: '600', color: '#fff' },
  card: {
    backgroundColor: 'rgba(28,26,28,0.45)',
    borderWidth: 1,
    borderColor: BORDER,
    borderRadius: 24,
    padding: 20,
    gap: 10,
  },
  glassButtonWrap: {
    borderRadius: 26,
    overflow: 'hidden',
  },
  glassButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    borderWidth: 1,
    borderColor: BORDER,
    borderRadius: 26,
    backgroundColor: Platform.select({ web: 'rgba(255,255,255,0.08)', default: 'transparent' }),
  },
  glassIcon: { position: 'absolute', left: 18 },
  glassButtonText: { fontSize: 16, fontWeight: '600', color: '#fff' },
  dividerRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginVertical: 4 },
  dividerLine: { flex: 1, height: StyleSheet.hairlineWidth, backgroundColor: BORDER },
  dividerText: { color: '#7a7a80', fontSize: 12 },
  methodSwitch: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    padding: 4,
  },
  methodTab: { flex: 1, paddingVertical: 10, alignItems: 'center', borderRadius: 9 },
  methodTabActive: { backgroundColor: 'rgba(255,255,255,0.12)' },
  methodTabText: { color: '#8a8a90', fontWeight: '500' },
  methodTabTextActive: { color: '#fff' },
  input: {
    backgroundColor: 'rgba(255,255,255,0.07)',
    borderWidth: 1,
    borderColor: BORDER,
    borderRadius: 14,
    padding: 14,
    fontSize: 16,
    color: '#fff',
  },
  hint: { fontSize: 11, color: '#6b6b70', textAlign: 'center' },
  phoneRow: { flexDirection: 'row', gap: 8 },
  countryPicker: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: 'rgba(255,255,255,0.07)',
    borderWidth: 1,
    borderColor: BORDER,
    borderRadius: 14,
    paddingHorizontal: 12,
    paddingVertical: 14,
  },
  countryFlag: { fontSize: 18, color: '#fff', lineHeight: 21 },
  countryDial: { color: '#fff', fontSize: 15, fontWeight: '600', lineHeight: 21 },
  phoneNumberInput: { flex: 1, minWidth: 0 },
  modalSheet: {
    flex: 1,
    height: '100%',
    backgroundColor: 'rgba(20,18,20,0.75)',
    paddingTop: 56,
    paddingHorizontal: 20,
    paddingBottom: 24,
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  modalTitle: { color: '#fff', fontSize: 18, fontWeight: '700', textAlign: 'center' },
  modalCloseButton: {
    position: 'absolute',
    right: 0,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  modalCloseButtonText: { color: '#fff', fontSize: 14, fontWeight: '700' },
  modalSearchInput: {
    backgroundColor: 'rgba(255,255,255,0.07)',
    borderWidth: 1,
    borderColor: BORDER,
    borderRadius: 14,
    padding: 12,
    fontSize: 15,
    color: '#fff',
    marginBottom: 8,
  },
  countryRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 12,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: BORDER,
  },
  countryRowName: { flex: 1, color: '#fff', fontSize: 15 },
  countryRowDial: { color: '#9a9aa0', fontSize: 14 },
  ctaButtonWrap: {
    borderRadius: 26,
    overflow: 'hidden',
    marginTop: 4,
  },
  ctaButton: {
    borderRadius: 26,
    paddingVertical: 15,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: BORDER,
  },
  ctaButtonText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  footnote: {
    fontSize: 11,
    color: '#fff',
    textAlign: 'center',
    marginTop: 20,
    paddingHorizontal: 12,
    lineHeight: 16,
  },
});
