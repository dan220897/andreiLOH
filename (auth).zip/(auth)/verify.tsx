import { BlurView } from 'expo-blur';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useEffect, useRef, useState } from 'react';
import {
  Alert,
  NativeSyntheticEvent,
  Platform,
  Pressable,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TextInputKeyPressEventData,
  View,
} from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from 'react-native-reanimated';
import AuthBackground from '../../components/AuthBackground';
import { supabase } from '../../lib/supabase';

const CODE_LENGTH = 6;

export default function Verify() {
  const router = useRouter();
  const { email, phone } = useLocalSearchParams<{ email?: string; phone?: string }>();
  const [digits, setDigits] = useState<string[]>(Array(CODE_LENGTH).fill(''));
  const [verifying, setVerifying] = useState(false);
  const inputRefs = useRef<Array<TextInput | null>>([]);

  const cardProgress = useSharedValue(0);

  useEffect(() => {
    cardProgress.value = withTiming(1, { duration: 550 });
  }, []);

  const cardStyle = useAnimatedStyle(() => ({
    opacity: cardProgress.value,
    transform: [{ translateY: 28 - cardProgress.value * 28 }],
  }));

  const code = digits.join('');

  const handleChange = (text: string, index: number) => {
    const value = text.replace(/\D/g, '').slice(-1);
    const next = [...digits];
    next[index] = value;
    setDigits(next);
    if (value && index < CODE_LENGTH - 1) {
      inputRefs.current[index + 1]?.focus();
    }
  };

  const handleKeyPress = (
    e: NativeSyntheticEvent<TextInputKeyPressEventData>,
    index: number
  ) => {
    if (e.nativeEvent.key === 'Backspace' && !digits[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const verify = async () => {
    setVerifying(true);
    const { error } = phone
      ? await supabase.auth.verifyOtp({ phone, token: code, type: 'sms' })
      : await supabase.auth.verifyOtp({ email: email!, token: code, type: 'email' });
    setVerifying(false);
    if (error) {
      Alert.alert('Ошибка', error.message);
      return;
    }
    router.replace('/');
  };

  useEffect(() => {
    if (code.length === CODE_LENGTH && !verifying) {
      verify();
    }
  }, [code]);

  return (
    <View style={styles.screen}>
      <AuthBackground />
      <StatusBar barStyle="light-content" />

      <Animated.View style={[styles.card, cardStyle]}>
        <Text style={styles.title}>Введите код</Text>
        <Text style={styles.subtitle}>Мы отправили код на {phone ?? email}</Text>

        <View style={styles.codeRow}>
          {digits.map((digit, index) => (
            <TextInput
              key={index}
              ref={(el) => {
                inputRefs.current[index] = el;
              }}
              style={styles.codeBox}
              keyboardType="number-pad"
              maxLength={1}
              value={digit}
              onChangeText={(text) => handleChange(text, index)}
              onKeyPress={(e) => handleKeyPress(e, index)}
            />
          ))}
        </View>

        <Pressable style={styles.ctaButtonWrap} onPress={verify} disabled={verifying}>
          <BlurView intensity={50} tint="dark" style={styles.ctaButton}>
            <Text style={styles.ctaButtonText}>{verifying ? 'Проверка...' : 'Подтвердить'}</Text>
          </BlurView>
        </Pressable>
      </Animated.View>
    </View>
  );
}

const BORDER = 'rgba(255,255,255,0.14)';

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    ...Platform.select({ web: { minHeight: '100vh' as any } }),
    padding: 24,
    justifyContent: 'center',
  },
  card: {
    backgroundColor: 'rgba(28,26,28,0.45)',
    borderWidth: 1,
    borderColor: BORDER,
    borderRadius: 24,
    padding: 24,
    gap: 12,
    zIndex: 1,
    elevation: 1,
  },
  title: { fontSize: 24, fontWeight: '800', color: '#fff', textAlign: 'center' },
  subtitle: { fontSize: 14, color: '#9a9aa0', textAlign: 'center', marginBottom: 8 },
  codeRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  codeBox: {
    width: 44,
    height: 52,
    backgroundColor: 'rgba(255,255,255,0.07)',
    borderWidth: 1,
    borderColor: BORDER,
    borderRadius: 14,
    fontSize: 22,
    fontWeight: '700',
    color: '#fff',
    textAlign: 'center',
  },
  ctaButtonWrap: {
    borderRadius: 26,
    overflow: 'hidden',
    marginTop: 4,
  },
  ctaButton: {
    borderRadius: 26,
    paddingVertical: 15,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: BORDER,
  },
  ctaButtonText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});
