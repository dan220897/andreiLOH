import { MaterialIcons } from '@expo/vector-icons';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { useEffect, useRef, useState } from 'react';
import {
  FlatList,
  Image,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../../lib/auth-context';
import { supabase } from '../../lib/supabase';

const ACCENT = '#8B5CF6';
const BORDER = 'rgba(255,255,255,0.14)';
const ONLINE_THRESHOLD_MS = 5 * 60 * 1000;

function isOnline(lastActiveAt: string | null) {
  if (!lastActiveAt) return false;
  return Date.now() - new Date(lastActiveAt).getTime() < ONLINE_THRESHOLD_MS;
}

function formatLastSeen(lastActiveAt: string | null) {
  if (!lastActiveAt) return '';
  if (isOnline(lastActiveAt)) return 'В сети';
  const diffMs = Date.now() - new Date(lastActiveAt).getTime();
  const minutes = Math.floor(diffMs / 60000);
  if (minutes < 60) return `Был(а) ${minutes} мин назад`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `Был(а) ${hours} ч назад`;
  const days = Math.floor(hours / 24);
  if (days === 1) return 'Был(а) вчера';
  if (days < 7) return `Был(а) ${days} дн назад`;
  return 'Давно не был(а) в сети';
}

type Message = {
  id: string;
  match_id: string;
  sender_id: string;
  type: string;
  content: string | null;
  created_at: string;
};

export default function ChatScreen() {
  const { id: matchId } = useLocalSearchParams<{ id: string }>();
  const { session } = useAuth();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [messages, setMessages] = useState<Message[]>([]);
  const [text, setText] = useState('');
  const [otherName, setOtherName] = useState('');
  const [otherPhotoUrl, setOtherPhotoUrl] = useState<string | null>(null);
  const [otherLastActive, setOtherLastActive] = useState<string | null>(null);
  const listRef = useRef<FlatList>(null);

  useEffect(() => {
    if (!matchId || !session) return;

    (async () => {
      const { data: match } = await supabase
        .from('matches')
        .select(
          'user_a_id, user_b_id, user_a:profiles!matches_user_a_id_fkey(display_name, last_active_at, photos(url, is_main)), user_b:profiles!matches_user_b_id_fkey(display_name, last_active_at, photos(url, is_main))'
        )
        .eq('id', matchId)
        .single();

      if (match) {
        const other =
          (match as any).user_a_id === session.user.id ? (match as any).user_b : (match as any).user_a;
        setOtherName(other?.display_name ?? '');
        setOtherLastActive(other?.last_active_at ?? null);
        const otherPhotos = (other?.photos ?? []) as { url: string; is_main: boolean }[];
        setOtherPhotoUrl(otherPhotos.find((p) => p.is_main)?.url ?? otherPhotos[0]?.url ?? null);
      }

      const { data: msgs } = await supabase
        .from('messages')
        .select('*')
        .eq('match_id', matchId)
        .order('created_at', { ascending: true });
      setMessages(msgs ?? []);

      await supabase
        .from('messages')
        .update({ read_at: new Date().toISOString() })
        .eq('match_id', matchId)
        .neq('sender_id', session.user.id)
        .is('read_at', null);
    })();

    const channel = supabase
      .channel(`messages:${matchId}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'messages', filter: `match_id=eq.${matchId}` },
        (payload) => {
          const incoming = payload.new as Message;
          setMessages((prev) =>
            prev.some((m) => m.id === incoming.id) ? prev : [...prev, incoming]
          );
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [matchId, session?.user.id]);

  const send = async () => {
    if (!text.trim() || !session || !matchId) return;
    const content = text.trim();
    setText('');

    const optimistic: Message = {
      id: `local-${Date.now()}-${Math.random().toString(36).slice(2)}`,
      match_id: String(matchId),
      sender_id: session.user.id,
      type: 'text',
      content,
      created_at: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, optimistic]);

    const { data: inserted } = await supabase
      .from('messages')
      .insert({
        match_id: matchId,
        sender_id: session.user.id,
        type: 'text',
        content,
      })
      .select()
      .single();

    if (inserted) {
      setMessages((prev) =>
        prev.map((m) => (m.id === optimistic.id ? (inserted as Message) : m))
      );
    }
  };

  return (
    <View style={styles.container}>
      {otherPhotoUrl ? (
        <>
          <Image
            source={{ uri: otherPhotoUrl }}
            style={StyleSheet.absoluteFillObject}
            blurRadius={35}
          />
          <View style={styles.bgScrim} />
          <BlurView intensity={20} tint="dark" style={StyleSheet.absoluteFillObject} />
        </>
      ) : (
        <LinearGradient colors={['#0E0A0C', '#1A0A0D']} style={StyleSheet.absoluteFillObject} />
      )}
      <BlurView intensity={40} tint="dark" style={[styles.header, { paddingTop: insets.top + 8 }]}>
        <Pressable style={styles.backButton} onPress={() => router.back()}>
          <MaterialIcons name="chevron-left" size={26} color="#fff" />
        </Pressable>
        <View style={styles.headerAvatarWrap}>
          {otherPhotoUrl ? (
            <Image source={{ uri: otherPhotoUrl }} style={styles.headerAvatar} />
          ) : (
            <View style={[styles.headerAvatar, styles.headerAvatarPlaceholder]} />
          )}
          {isOnline(otherLastActive) && <View style={styles.headerOnlineDot} />}
        </View>
        <View style={styles.headerTextWrap}>
          <Text style={styles.headerName} numberOfLines={1}>
            {otherName || 'Чат'}
          </Text>
          <Text style={[styles.headerStatus, isOnline(otherLastActive) && styles.headerStatusOnline]}>
            {formatLastSeen(otherLastActive)}
          </Text>
        </View>
      </BlurView>
      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
      >
        <FlatList
          ref={listRef}
          data={messages}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.list}
          onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: true })}
          renderItem={({ item }) => {
            const mine = item.sender_id === session?.user.id;
            return mine ? (
              <LinearGradient
                colors={['#A78BFA', '#8B5CF6']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={[styles.bubble, styles.bubbleMine]}
              >
                <Text style={styles.bubbleTextMine}>{item.content}</Text>
              </LinearGradient>
            ) : (
              <View style={[styles.bubble, styles.bubbleTheirs]}>
                <Text style={styles.bubbleTextTheirs}>{item.content}</Text>
              </View>
            );
          }}
        />
        <View style={[styles.inputRow, { paddingBottom: Math.max(insets.bottom, 12) }]}>
          <TextInput
            style={styles.input}
            placeholder="Сообщение"
            placeholderTextColor="#6b6b70"
            value={text}
            onChangeText={setText}
          />
          <Pressable
            style={[styles.sendButton, !text.trim() && styles.sendButtonDisabled]}
            onPress={send}
            disabled={!text.trim()}
          >
            <MaterialIcons name="arrow-upward" size={20} color="#fff" />
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0E0A0C' },
  bgScrim: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(14,10,12,0.55)' },
  flex: { flex: 1 },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 12,
    paddingBottom: 10,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: BORDER,
  },
  backButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerAvatarWrap: { position: 'relative' },
  headerAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: 'rgba(139,92,246,0.6)',
  },
  headerAvatarPlaceholder: { backgroundColor: 'rgba(255,255,255,0.1)' },
  headerOnlineDot: {
    position: 'absolute',
    right: -1,
    bottom: -1,
    width: 11,
    height: 11,
    borderRadius: 6,
    backgroundColor: '#2ecc71',
    borderWidth: 2,
    borderColor: '#1A0A0D',
  },
  headerTextWrap: { flex: 1, minWidth: 0 },
  headerName: { color: '#fff', fontSize: 16, fontWeight: '700' },
  headerStatus: { color: '#9a9aa0', fontSize: 12, marginTop: 1 },
  headerStatusOnline: { color: '#8ee6a8' },
  list: { padding: 16, gap: 8, flexGrow: 1 },
  bubble: { maxWidth: '75%', borderRadius: 18, paddingVertical: 10, paddingHorizontal: 14, marginBottom: 8 },
  bubbleMine: { alignSelf: 'flex-end', borderBottomRightRadius: 4 },
  bubbleTheirs: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(30,25,28,0.55)',
    borderWidth: 1,
    borderColor: BORDER,
    borderBottomLeftRadius: 4,
  },
  bubbleTextMine: { color: '#fff', fontSize: 15 },
  bubbleTextTheirs: { color: '#f0f0f2', fontSize: 15 },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 12,
    gap: 10,
    backgroundColor: 'rgba(14,10,12,0.35)',
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: BORDER,
  },
  input: {
    flex: 1,
    backgroundColor: 'rgba(20,15,17,0.6)',
    borderWidth: 1,
    borderColor: BORDER,
    borderRadius: 20,
    paddingHorizontal: 16,
    paddingVertical: 10,
    color: '#fff',
    fontSize: 15,
  },
  sendButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: ACCENT,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: ACCENT,
    shadowOpacity: 0.5,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 0 },
    elevation: 6,
  },
  sendButtonDisabled: { opacity: 0.4 },
});
