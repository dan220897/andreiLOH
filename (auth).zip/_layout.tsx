import { Stack } from 'expo-router';
import { Platform } from 'react-native';
import { GestureHandlerRootView } from 'react-native-gesture-handler';
import ErrorBoundary from '../components/ErrorBoundary';
import { AuthProvider } from '../lib/auth-context';

if (Platform.OS === 'web' && typeof document !== 'undefined') {
  const fontLink = document.createElement('link');
  fontLink.rel = 'stylesheet';
  fontLink.href =
    'https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700;800;900&display=swap';
  document.head.appendChild(fontLink);

  const style = document.createElement('style');
  style.textContent = `
    html, body, #root, * {
      scrollbar-width: none;
      -ms-overflow-style: none;
    }
    *::-webkit-scrollbar {
      display: none;
      width: 0;
      height: 0;
    }
    html, body, #root {
      font-family: 'Montserrat', sans-serif;
    }
    div[style*="font-family"]:not([style*="icon" i]):not([style*="awesome" i]):not([style*="material" i]):not([style*="ionicons" i]):not([style*="feather" i]):not([style*="entypo" i]):not([style*="glyph" i]) {
      font-family: 'Montserrat', sans-serif !important;
    }
  `;
  document.head.appendChild(style);
}

export default function RootLayout() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <ErrorBoundary>
        <AuthProvider>
          <Stack screenOptions={{ headerShown: false }} />
        </AuthProvider>
      </ErrorBoundary>
    </GestureHandlerRootView>
  );
}
